import {
  r as P,
  j as C,
  a as Vn,
  B as Mo,
  P as Do,
  L as Ce,
  t as Eo,
} from "./index-emD-E0jN.js";
import { L as Ro } from "./loader-circle-_7XAmGM6.js";
const Ws = P.createContext({});
function Lo(t) {
  const e = P.useRef(null);
  return e.current === null && (e.current = t()), e.current;
}
const ko = typeof window < "u",
  Bo = ko ? P.useLayoutEffect : P.useEffect,
  Qe = P.createContext(null);
function tn(t, e) {
  t.indexOf(e) === -1 && t.push(e);
}
function Zt(t, e) {
  const n = t.indexOf(e);
  n > -1 && t.splice(n, 1);
}
const tt = (t, e, n) => (n > e ? e : n < t ? t : n);
let en = () => {};
const it = {},
  Ks = (t) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t),
  $s = (t) => typeof t == "object" && t !== null,
  Hs = (t) => /^0[^.\s]+$/u.test(t);
function zs(t) {
  let e;
  return () => (e === void 0 && (e = t()), e);
}
const z = (t) => t,
  Ft = (...t) => t.reduce((e, n) => (s) => n(e(s))),
  Rt = (t, e, n) => {
    const s = e - t;
    return s ? (n - t) / s : 1;
  };
class nn {
  constructor() {
    this.subscriptions = [];
  }
  add(e) {
    return tn(this.subscriptions, e), () => Zt(this.subscriptions, e);
  }
  notify(e, n, s) {
    const i = this.subscriptions.length;
    if (i)
      if (i === 1) this.subscriptions[0](e, n, s);
      else
        for (let r = 0; r < i; r++) {
          const o = this.subscriptions[r];
          o && o(e, n, s);
        }
  }
  getSize() {
    return this.subscriptions.length;
  }
  clear() {
    this.subscriptions.length = 0;
  }
}
const K = (t) => t * 1e3,
  H = (t) => t / 1e3,
  Gs = (t, e) => (e ? t * (1e3 / e) : 0),
  _s = (t, e, n) =>
    (((1 - 3 * n + 3 * e) * t + (3 * n - 6 * e)) * t + 3 * e) * t,
  Fo = 1e-7,
  Io = 12;
function jo(t, e, n, s, i) {
  let r,
    o,
    a = 0;
  do (o = e + (n - e) / 2), (r = _s(o, s, i) - t), r > 0 ? (n = o) : (e = o);
  while (Math.abs(r) > Fo && ++a < Io);
  return o;
}
function It(t, e, n, s) {
  if (t === e && n === s) return z;
  const i = (r) => jo(r, 0, 1, t, n);
  return (r) => (r === 0 || r === 1 ? r : _s(i(r), e, s));
}
const Xs = (t) => (e) => e <= 0.5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2,
  Ys = (t) => (e) => 1 - t(1 - e),
  qs = It(0.33, 1.53, 0.69, 0.99),
  sn = Ys(qs),
  Zs = Xs(sn),
  Js = (t) =>
    t >= 1
      ? 1
      : (t *= 2) < 1
      ? 0.5 * sn(t)
      : 0.5 * (2 - Math.pow(2, -10 * (t - 1))),
  on = (t) => 1 - Math.sin(Math.acos(t)),
  Qs = Ys(on),
  ti = Xs(on),
  Oo = It(0.42, 0, 1, 1),
  No = It(0, 0, 0.58, 1),
  ei = It(0.42, 0, 0.58, 1),
  Uo = (t) => Array.isArray(t) && typeof t[0] != "number",
  ni = (t) => Array.isArray(t) && typeof t[0] == "number",
  Wo = {
    linear: z,
    easeIn: Oo,
    easeInOut: ei,
    easeOut: No,
    circIn: on,
    circInOut: ti,
    circOut: Qs,
    backIn: sn,
    backInOut: Zs,
    backOut: qs,
    anticipate: Js,
  },
  Ko = (t) => typeof t == "string",
  Cn = (t) => {
    if (ni(t)) {
      en(t.length === 4);
      const [e, n, s, i] = t;
      return It(e, n, s, i);
    } else if (Ko(t)) return Wo[t];
    return t;
  },
  Nt = [
    "setup",
    "read",
    "resolveKeyframes",
    "preUpdate",
    "update",
    "preRender",
    "render",
    "postRender",
  ];
function $o(t, e) {
  let n = new Set(),
    s = new Set(),
    i = !1,
    r = !1;
  const o = new WeakSet();
  let a = { delta: 0, timestamp: 0, isProcessing: !1 };
  function c(l) {
    o.has(l) && (u.schedule(l), t()), l(a);
  }
  const u = {
    schedule: (l, h = !1, f = !1) => {
      const p = f && i ? n : s;
      return h && o.add(l), p.add(l), l;
    },
    cancel: (l) => {
      s.delete(l), o.delete(l);
    },
    process: (l) => {
      if (((a = l), i)) {
        r = !0;
        return;
      }
      i = !0;
      const h = n;
      (n = s),
        (s = h),
        n.forEach(c),
        n.clear(),
        (i = !1),
        r && ((r = !1), u.process(l));
    },
  };
  return u;
}
const Ho = 40;
function si(t, e) {
  let n = !1,
    s = !0;
  const i = { delta: 0, timestamp: 0, isProcessing: !1 },
    r = () => (n = !0),
    o = Nt.reduce((x, w) => ((x[w] = $o(r)), x), {}),
    {
      setup: a,
      read: c,
      resolveKeyframes: u,
      preUpdate: l,
      update: h,
      preRender: f,
      render: d,
      postRender: p,
    } = o,
    m = () => {
      const x = it.useManualTiming,
        w = x ? i.timestamp : performance.now();
      (n = !1),
        x ||
          (i.delta = s ? 1e3 / 60 : Math.max(Math.min(w - i.timestamp, Ho), 1)),
        (i.timestamp = w),
        (i.isProcessing = !0),
        a.process(i),
        c.process(i),
        u.process(i),
        l.process(i),
        h.process(i),
        f.process(i),
        d.process(i),
        p.process(i),
        (i.isProcessing = !1),
        n && e && ((s = !1), t(m));
    },
    g = () => {
      (n = !0), (s = !0), i.isProcessing || t(m);
    };
  return {
    schedule: Nt.reduce((x, w) => {
      const A = o[w];
      return (x[w] = (E, V = !1, b = !1) => (n || g(), A.schedule(E, V, b))), x;
    }, {}),
    cancel: (x) => {
      for (let w = 0; w < Nt.length; w++) o[Nt[w]].cancel(x);
    },
    state: i,
    steps: o,
  };
}
const {
  schedule: D,
  cancel: ot,
  state: j,
  steps: he,
} = si(typeof requestAnimationFrame < "u" ? requestAnimationFrame : z, !0);
let $t;
function zo() {
  $t = void 0;
}
const N = {
    now: () => (
      $t === void 0 &&
        N.set(
          j.isProcessing || it.useManualTiming ? j.timestamp : performance.now()
        ),
      $t
    ),
    set: (t) => {
      ($t = t), queueMicrotask(zo);
    },
  },
  ii = (t) => (e) => typeof e == "string" && e.startsWith(t),
  oi = ii("--"),
  Go = ii("var(--"),
  rn = (t) => (Go(t) ? _o.test(t.split("/*")[0].trim()) : !1),
  _o =
    /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
function Mn(t) {
  return typeof t != "string" ? !1 : t.split("/*")[0].includes("var(--");
}
const Pt = {
    test: (t) => typeof t == "number",
    parse: parseFloat,
    transform: (t) => t,
  },
  Lt = { ...Pt, transform: (t) => tt(0, 1, t) },
  Ut = { ...Pt, default: 1 },
  Ct = (t) => Math.round(t * 1e5) / 1e5,
  an = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
function Xo(t) {
  return t == null;
}
const Yo =
    /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
  ln = (t, e) => (n) =>
    !!(
      (typeof n == "string" && Yo.test(n) && n.startsWith(t)) ||
      (e && !Xo(n) && Object.prototype.hasOwnProperty.call(n, e))
    ),
  ri = (t, e, n) => (s) => {
    if (typeof s != "string") return s;
    const [i, r, o, a] = s.match(an);
    return {
      [t]: parseFloat(i),
      [e]: parseFloat(r),
      [n]: parseFloat(o),
      alpha: a !== void 0 ? parseFloat(a) : 1,
    };
  },
  qo = (t) => tt(0, 255, t),
  fe = { ...Pt, transform: (t) => Math.round(qo(t)) },
  ht = {
    test: ln("rgb", "red"),
    parse: ri("red", "green", "blue"),
    transform: ({ red: t, green: e, blue: n, alpha: s = 1 }) =>
      "rgba(" +
      fe.transform(t) +
      ", " +
      fe.transform(e) +
      ", " +
      fe.transform(n) +
      ", " +
      Ct(Lt.transform(s)) +
      ")",
  };
function Zo(t) {
  let e = "",
    n = "",
    s = "",
    i = "";
  return (
    t.length > 5
      ? ((e = t.substring(1, 3)),
        (n = t.substring(3, 5)),
        (s = t.substring(5, 7)),
        (i = t.substring(7, 9)))
      : ((e = t.substring(1, 2)),
        (n = t.substring(2, 3)),
        (s = t.substring(3, 4)),
        (i = t.substring(4, 5)),
        (e += e),
        (n += n),
        (s += s),
        (i += i)),
    {
      red: parseInt(e, 16),
      green: parseInt(n, 16),
      blue: parseInt(s, 16),
      alpha: i ? parseInt(i, 16) / 255 : 1,
    }
  );
}
const Me = { test: ln("#"), parse: Zo, transform: ht.transform },
  jt = (t) => ({
    test: (e) =>
      typeof e == "string" && e.endsWith(t) && e.split(" ").length === 1,
    parse: parseFloat,
    transform: (e) => `${e}${t}`,
  }),
  nt = jt("deg"),
  Q = jt("%"),
  T = jt("px"),
  Jo = jt("vh"),
  Qo = jt("vw"),
  Dn = {
    ...Q,
    parse: (t) => Q.parse(t) / 100,
    transform: (t) => Q.transform(t * 100),
  },
  yt = {
    test: ln("hsl", "hue"),
    parse: ri("hue", "saturation", "lightness"),
    transform: ({ hue: t, saturation: e, lightness: n, alpha: s = 1 }) =>
      "hsla(" +
      Math.round(t) +
      ", " +
      Q.transform(Ct(e)) +
      ", " +
      Q.transform(Ct(n)) +
      ", " +
      Ct(Lt.transform(s)) +
      ")",
  },
  k = {
    test: (t) => ht.test(t) || Me.test(t) || yt.test(t),
    parse: (t) =>
      ht.test(t) ? ht.parse(t) : yt.test(t) ? yt.parse(t) : Me.parse(t),
    transform: (t) =>
      typeof t == "string"
        ? t
        : t.hasOwnProperty("red")
        ? ht.transform(t)
        : yt.transform(t),
    getAnimatableNone: (t) => {
      const e = k.parse(t);
      return (e.alpha = 0), k.transform(e);
    },
  },
  tr =
    /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
function er(t) {
  return (
    isNaN(t) &&
    typeof t == "string" &&
    (t.match(an)?.length || 0) + (t.match(tr)?.length || 0) > 0
  );
}
const ai = "number",
  li = "color",
  nr = "var",
  sr = "var(",
  En = "${}",
  ir =
    /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function Tt(t) {
  const e = t.toString(),
    n = [],
    s = { color: [], number: [], var: [] },
    i = [];
  let r = 0;
  const a = e
    .replace(
      ir,
      (c) => (
        k.test(c)
          ? (s.color.push(r), i.push(li), n.push(k.parse(c)))
          : c.startsWith(sr)
          ? (s.var.push(r), i.push(nr), n.push(c))
          : (s.number.push(r), i.push(ai), n.push(parseFloat(c))),
        ++r,
        En
      )
    )
    .split(En);
  return { values: n, split: a, indexes: s, types: i };
}
function or(t) {
  return Tt(t).values;
}
function ci({ split: t, types: e }) {
  const n = t.length;
  return (s) => {
    let i = "";
    for (let r = 0; r < n; r++)
      if (((i += t[r]), s[r] !== void 0)) {
        const o = e[r];
        o === ai
          ? (i += Ct(s[r]))
          : o === li
          ? (i += k.transform(s[r]))
          : (i += s[r]);
      }
    return i;
  };
}
function rr(t) {
  return ci(Tt(t));
}
const ar = (t) =>
    typeof t == "number" ? 0 : k.test(t) ? k.getAnimatableNone(t) : t,
  lr = (t, e) =>
    typeof t == "number" ? (e?.trim().endsWith("/") ? t : 0) : ar(t);
function cr(t) {
  const e = Tt(t);
  return ci(e)(e.values.map((s, i) => lr(s, e.split[i])));
}
const X = { test: er, parse: or, createTransformer: rr, getAnimatableNone: cr };
function de(t, e, n) {
  return (
    n < 0 && (n += 1),
    n > 1 && (n -= 1),
    n < 1 / 6
      ? t + (e - t) * 6 * n
      : n < 1 / 2
      ? e
      : n < 2 / 3
      ? t + (e - t) * (2 / 3 - n) * 6
      : t
  );
}
function ur({ hue: t, saturation: e, lightness: n, alpha: s }) {
  (t /= 360), (e /= 100), (n /= 100);
  let i = 0,
    r = 0,
    o = 0;
  if (!e) i = r = o = n;
  else {
    const a = n < 0.5 ? n * (1 + e) : n + e - n * e,
      c = 2 * n - a;
    (i = de(c, a, t + 1 / 3)), (r = de(c, a, t)), (o = de(c, a, t - 1 / 3));
  }
  return {
    red: Math.round(i * 255),
    green: Math.round(r * 255),
    blue: Math.round(o * 255),
    alpha: s,
  };
}
function Jt(t, e) {
  return (n) => (n > 0 ? e : t);
}
const M = (t, e, n) => t + (e - t) * n,
  pe = (t, e, n) => {
    const s = t * t,
      i = n * (e * e - s) + s;
    return i < 0 ? 0 : Math.sqrt(i);
  },
  hr = [Me, ht, yt],
  fr = (t) => hr.find((e) => e.test(t));
function Rn(t) {
  const e = fr(t);
  if (!e) return !1;
  let n = e.parse(t);
  return e === yt && (n = ur(n)), n;
}
const Ln = (t, e) => {
    const n = Rn(t),
      s = Rn(e);
    if (!n || !s) return Jt(t, e);
    const i = { ...n };
    return (r) => (
      (i.red = pe(n.red, s.red, r)),
      (i.green = pe(n.green, s.green, r)),
      (i.blue = pe(n.blue, s.blue, r)),
      (i.alpha = M(n.alpha, s.alpha, r)),
      ht.transform(i)
    );
  },
  De = new Set(["none", "hidden"]);
function dr(t, e) {
  return De.has(t) ? (n) => (n <= 0 ? t : e) : (n) => (n >= 1 ? e : t);
}
function pr(t, e) {
  return (n) => M(t, e, n);
}
function cn(t) {
  return typeof t == "number"
    ? pr
    : typeof t == "string"
    ? rn(t)
      ? Jt
      : k.test(t)
      ? Ln
      : yr
    : Array.isArray(t)
    ? ui
    : typeof t == "object"
    ? k.test(t)
      ? Ln
      : mr
    : Jt;
}
function ui(t, e) {
  const n = [...t],
    s = n.length,
    i = t.map((r, o) => cn(r)(r, e[o]));
  return (r) => {
    for (let o = 0; o < s; o++) n[o] = i[o](r);
    return n;
  };
}
function mr(t, e) {
  const n = { ...t, ...e },
    s = {};
  for (const i in n)
    t[i] !== void 0 && e[i] !== void 0 && (s[i] = cn(t[i])(t[i], e[i]));
  return (i) => {
    for (const r in s) n[r] = s[r](i);
    return n;
  };
}
function gr(t, e) {
  const n = [],
    s = { color: 0, var: 0, number: 0 };
  for (let i = 0; i < e.values.length; i++) {
    const r = e.types[i],
      o = t.indexes[r][s[r]],
      a = t.values[o] ?? 0;
    (n[i] = a), s[r]++;
  }
  return n;
}
const yr = (t, e) => {
  const n = X.createTransformer(e),
    s = Tt(t),
    i = Tt(e);
  return s.indexes.var.length === i.indexes.var.length &&
    s.indexes.color.length === i.indexes.color.length &&
    s.indexes.number.length >= i.indexes.number.length
    ? (De.has(t) && !i.values.length) || (De.has(e) && !s.values.length)
      ? dr(t, e)
      : Ft(ui(gr(s, i), i.values), n)
    : Jt(t, e);
};
function hi(t, e, n) {
  return typeof t == "number" && typeof e == "number" && typeof n == "number"
    ? M(t, e, n)
    : cn(t)(t, e);
}
const vr = (t) => {
    const e = ({ timestamp: n }) => t(n);
    return {
      start: (n = !0) => D.update(e, n),
      stop: () => ot(e),
      now: () => (j.isProcessing ? j.timestamp : N.now()),
    };
  },
  fi = (t, e, n = 10) => {
    let s = "";
    const i = Math.max(Math.round(e / n), 2);
    for (let r = 0; r < i; r++)
      s += Math.round(t(r / (i - 1)) * 1e4) / 1e4 + ", ";
    return `linear(${s.substring(0, s.length - 2)})`;
  },
  Qt = 2e4;
function un(t) {
  let e = 0;
  const n = 50;
  let s = t.next(e);
  for (; !s.done && e < Qt; ) (e += n), (s = t.next(e));
  return e >= Qt ? 1 / 0 : e;
}
function xr(t, e = 100, n) {
  const s = n({ ...t, keyframes: [0, e] }),
    i = Math.min(un(s), Qt);
  return {
    type: "keyframes",
    ease: (r) => s.next(i * r).value / e,
    duration: H(i),
  };
}
const R = {
  stiffness: 100,
  damping: 10,
  mass: 1,
  velocity: 0,
  duration: 800,
  bounce: 0.3,
  visualDuration: 0.3,
  restSpeed: { granular: 0.01, default: 2 },
  restDelta: { granular: 0.005, default: 0.5 },
  minDuration: 0.01,
  maxDuration: 10,
  minDamping: 0.05,
  maxDamping: 1,
};
function Ee(t, e) {
  return t * Math.sqrt(1 - e * e);
}
const Tr = 12;
function wr(t, e, n) {
  let s = n;
  for (let i = 1; i < Tr; i++) s = s - t(s) / e(s);
  return s;
}
const me = 0.001;
function Pr({
  duration: t = R.duration,
  bounce: e = R.bounce,
  velocity: n = R.velocity,
  mass: s = R.mass,
}) {
  let i,
    r,
    o = 1 - e;
  (o = tt(R.minDamping, R.maxDamping, o)),
    (t = tt(R.minDuration, R.maxDuration, H(t))),
    o < 1
      ? ((i = (u) => {
          const l = u * o,
            h = l * t,
            f = l - n,
            d = Ee(u, o),
            p = Math.exp(-h);
          return me - (f / d) * p;
        }),
        (r = (u) => {
          const h = u * o * t,
            f = h * n + n,
            d = Math.pow(o, 2) * Math.pow(u, 2) * t,
            p = Math.exp(-h),
            m = Ee(Math.pow(u, 2), o);
          return ((-i(u) + me > 0 ? -1 : 1) * ((f - d) * p)) / m;
        }))
      : ((i = (u) => {
          const l = Math.exp(-u * t),
            h = (u - n) * t + 1;
          return -me + l * h;
        }),
        (r = (u) => {
          const l = Math.exp(-u * t),
            h = (n - u) * (t * t);
          return l * h;
        }));
  const a = 5 / t,
    c = wr(i, r, a);
  if (((t = K(t)), isNaN(c)))
    return { stiffness: R.stiffness, damping: R.damping, duration: t };
  {
    const u = Math.pow(c, 2) * s;
    return { stiffness: u, damping: o * 2 * Math.sqrt(s * u), duration: t };
  }
}
const Sr = ["duration", "bounce"],
  br = ["stiffness", "damping", "mass"];
function kn(t, e) {
  return e.some((n) => t[n] !== void 0);
}
function Ar(t) {
  let e = {
    velocity: R.velocity,
    stiffness: R.stiffness,
    damping: R.damping,
    mass: R.mass,
    isResolvedFromDuration: !1,
    ...t,
  };
  if (!kn(t, br) && kn(t, Sr))
    if (((e.velocity = 0), t.visualDuration)) {
      const n = t.visualDuration,
        s = (2 * Math.PI) / (n * 1.2),
        i = s * s,
        r = 2 * tt(0.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(i);
      e = { ...e, mass: R.mass, stiffness: i, damping: r };
    } else {
      const n = Pr({ ...t, velocity: 0 });
      (e = { ...e, ...n, mass: R.mass }), (e.isResolvedFromDuration = !0);
    }
  return e;
}
function te(t = R.visualDuration, e = R.bounce) {
  const n =
    typeof t != "object"
      ? { visualDuration: t, keyframes: [0, 1], bounce: e }
      : t;
  let { restSpeed: s, restDelta: i } = n;
  const r = n.keyframes[0],
    o = n.keyframes[n.keyframes.length - 1],
    a = { done: !1, value: r },
    {
      stiffness: c,
      damping: u,
      mass: l,
      duration: h,
      velocity: f,
      isResolvedFromDuration: d,
    } = Ar({ ...n, velocity: -H(n.velocity || 0) }),
    p = f || 0,
    m = u / (2 * Math.sqrt(c * l)),
    g = o - r,
    y = H(Math.sqrt(c / l)),
    v = Math.abs(g) < 5;
  s || (s = v ? R.restSpeed.granular : R.restSpeed.default),
    i || (i = v ? R.restDelta.granular : R.restDelta.default);
  let x, w, A, E, V, b;
  if (m < 1)
    (A = Ee(y, m)),
      (E = (p + m * y * g) / A),
      (x = (S) => {
        const L = Math.exp(-m * y * S);
        return o - L * (E * Math.sin(A * S) + g * Math.cos(A * S));
      }),
      (V = m * y * E + g * A),
      (b = m * y * g - E * A),
      (w = (S) =>
        Math.exp(-m * y * S) * (V * Math.sin(A * S) + b * Math.cos(A * S)));
  else if (m === 1) {
    x = (L) => o - Math.exp(-y * L) * (g + (p + y * g) * L);
    const S = p + y * g;
    w = (L) => Math.exp(-y * L) * (y * S * L - p);
  } else {
    const S = y * Math.sqrt(m * m - 1);
    x = (Y) => {
      const et = Math.exp(-m * y * Y),
        q = Math.min(S * Y, 300);
      return (
        o - (et * ((p + m * y * g) * Math.sinh(q) + S * g * Math.cosh(q))) / S
      );
    };
    const L = (p + m * y * g) / S,
      W = m * y * L - g * S,
      at = m * y * g - L * S;
    w = (Y) => {
      const et = Math.exp(-m * y * Y),
        q = Math.min(S * Y, 300);
      return et * (W * Math.sinh(q) + at * Math.cosh(q));
    };
  }
  const F = {
    calculatedDuration: (d && h) || null,
    velocity: (S) => K(w(S)),
    next: (S) => {
      if (!d && m < 1) {
        const W = Math.exp(-m * y * S),
          at = Math.sin(A * S),
          Y = Math.cos(A * S),
          et = o - W * (E * at + g * Y),
          q = K(W * (V * at + b * Y));
        return (
          (a.done = Math.abs(q) <= s && Math.abs(o - et) <= i),
          (a.value = a.done ? o : et),
          a
        );
      }
      const L = x(S);
      if (d) a.done = S >= h;
      else {
        const W = K(w(S));
        a.done = Math.abs(W) <= s && Math.abs(o - L) <= i;
      }
      return (a.value = a.done ? o : L), a;
    },
    toString: () => {
      const S = Math.min(un(F), Qt),
        L = fi((W) => F.next(S * W).value, S, 30);
      return S + "ms " + L;
    },
    toTransition: () => {},
  };
  return F;
}
te.applyToOptions = (t) => {
  const e = xr(t, 100, te);
  return (
    (t.ease = e.ease), (t.duration = K(e.duration)), (t.type = "keyframes"), t
  );
};
const Vr = 5;
function di(t, e, n) {
  const s = Math.max(e - Vr, 0);
  return Gs(n - t(s), e - s);
}
function Re({
  keyframes: t,
  velocity: e = 0,
  power: n = 0.8,
  timeConstant: s = 325,
  bounceDamping: i = 10,
  bounceStiffness: r = 500,
  modifyTarget: o,
  min: a,
  max: c,
  restDelta: u = 0.5,
  restSpeed: l,
}) {
  const h = t[0],
    f = { done: !1, value: h },
    d = (b) => (a !== void 0 && b < a) || (c !== void 0 && b > c),
    p = (b) =>
      a === void 0
        ? c
        : c === void 0 || Math.abs(a - b) < Math.abs(c - b)
        ? a
        : c;
  let m = n * e;
  const g = h + m,
    y = o === void 0 ? g : o(g);
  y !== g && (m = y - h);
  const v = (b) => -m * Math.exp(-b / s),
    x = (b) => y + v(b),
    w = (b) => {
      const F = v(b),
        S = x(b);
      (f.done = Math.abs(F) <= u), (f.value = f.done ? y : S);
    };
  let A, E;
  const V = (b) => {
    d(f.value) &&
      ((A = b),
      (E = te({
        keyframes: [f.value, p(f.value)],
        velocity: di(x, b, f.value),
        damping: i,
        stiffness: r,
        restDelta: u,
        restSpeed: l,
      })));
  };
  return (
    V(0),
    {
      calculatedDuration: null,
      next: (b) => {
        let F = !1;
        return (
          !E && A === void 0 && ((F = !0), w(b), V(b)),
          A !== void 0 && b >= A ? E.next(b - A) : (!F && w(b), f)
        );
      },
    }
  );
}
function Cr(t, e, n) {
  const s = [],
    i = n || it.mix || hi,
    r = t.length - 1;
  for (let o = 0; o < r; o++) {
    let a = i(t[o], t[o + 1]);
    if (e) {
      const c = Array.isArray(e) ? e[o] || z : e;
      a = Ft(c, a);
    }
    s.push(a);
  }
  return s;
}
function Mr(t, e, { clamp: n = !0, ease: s, mixer: i } = {}) {
  const r = t.length;
  if ((en(r === e.length), r === 1)) return () => e[0];
  if (r === 2 && e[0] === e[1]) return () => e[1];
  const o = t[0] === t[1];
  t[0] > t[r - 1] && ((t = [...t].reverse()), (e = [...e].reverse()));
  const a = Cr(e, s, i),
    c = a.length,
    u = (l) => {
      if (o && l < t[0]) return e[0];
      let h = 0;
      if (c > 1) for (; h < t.length - 2 && !(l < t[h + 1]); h++);
      const f = Rt(t[h], t[h + 1], l);
      return a[h](f);
    };
  return n ? (l) => u(tt(t[0], t[r - 1], l)) : u;
}
function Dr(t, e) {
  const n = t[t.length - 1];
  for (let s = 1; s <= e; s++) {
    const i = Rt(0, e, s);
    t.push(M(n, 1, i));
  }
}
function Er(t) {
  const e = [0];
  return Dr(e, t.length - 1), e;
}
function Rr(t, e) {
  return t.map((n) => n * e);
}
function Lr(t, e) {
  return t.map(() => e || ei).splice(0, t.length - 1);
}
function Mt({
  duration: t = 300,
  keyframes: e,
  times: n,
  ease: s = "easeInOut",
}) {
  const i = Uo(s) ? s.map(Cn) : Cn(s),
    r = { done: !1, value: e[0] },
    o = Rr(n && n.length === e.length ? n : Er(e), t),
    a = Mr(o, e, { ease: Array.isArray(i) ? i : Lr(e, i) });
  return {
    calculatedDuration: t,
    next: (c) => ((r.value = a(c)), (r.done = c >= t), r),
  };
}
const kr = (t) => t !== null;
function ae(t, { repeat: e, repeatType: n = "loop" }, s, i = 1) {
  const r = t.filter(kr),
    a = i < 0 || (e && n !== "loop" && e % 2 === 1) ? 0 : r.length - 1;
  return !a || s === void 0 ? r[a] : s;
}
const Br = { decay: Re, inertia: Re, tween: Mt, keyframes: Mt, spring: te };
function pi(t) {
  typeof t.type == "string" && (t.type = Br[t.type]);
}
class hn {
  constructor() {
    this.updateFinished();
  }
  get finished() {
    return this._finished;
  }
  updateFinished() {
    this._finished = new Promise((e) => {
      this.resolve = e;
    });
  }
  notifyFinished() {
    this.resolve();
  }
  then(e, n) {
    return this.finished.then(e, n);
  }
}
const Fr = (t) => t / 100;
class ee extends hn {
  constructor(e) {
    super(),
      (this.state = "idle"),
      (this.startTime = null),
      (this.isStopped = !1),
      (this.currentTime = 0),
      (this.holdTime = null),
      (this.playbackSpeed = 1),
      (this.delayState = { done: !1, value: void 0 }),
      (this.stop = () => {
        const { motionValue: n } = this.options;
        n && n.updatedAt !== N.now() && this.tick(N.now()),
          (this.isStopped = !0),
          this.state !== "idle" && (this.teardown(), this.options.onStop?.());
      }),
      (this.options = e),
      this.initAnimation(),
      this.play(),
      e.autoplay === !1 && this.pause();
  }
  initAnimation() {
    const { options: e } = this;
    pi(e);
    const {
      type: n = Mt,
      repeat: s = 0,
      repeatDelay: i = 0,
      repeatType: r,
      velocity: o = 0,
    } = e;
    let { keyframes: a } = e;
    const c = n || Mt;
    c !== Mt &&
      typeof a[0] != "number" &&
      ((this.mixKeyframes = Ft(Fr, hi(a[0], a[1]))), (a = [0, 100]));
    const u = c({ ...e, keyframes: a });
    r === "mirror" &&
      (this.mirroredGenerator = c({
        ...e,
        keyframes: [...a].reverse(),
        velocity: -o,
      })),
      u.calculatedDuration === null && (u.calculatedDuration = un(u));
    const { calculatedDuration: l } = u;
    (this.calculatedDuration = l),
      (this.resolvedDuration = l + i),
      (this.totalDuration = this.resolvedDuration * (s + 1) - i),
      (this.generator = u);
  }
  updateTime(e) {
    const n = Math.round(e - this.startTime) * this.playbackSpeed;
    this.holdTime !== null
      ? (this.currentTime = this.holdTime)
      : (this.currentTime = n);
  }
  tick(e, n = !1) {
    const {
      generator: s,
      totalDuration: i,
      mixKeyframes: r,
      mirroredGenerator: o,
      resolvedDuration: a,
      calculatedDuration: c,
    } = this;
    if (this.startTime === null) return s.next(0);
    const {
      delay: u = 0,
      keyframes: l,
      repeat: h,
      repeatType: f,
      repeatDelay: d,
      type: p,
      onUpdate: m,
      finalKeyframe: g,
    } = this.options;
    this.speed > 0
      ? (this.startTime = Math.min(this.startTime, e))
      : this.speed < 0 &&
        (this.startTime = Math.min(e - i / this.speed, this.startTime)),
      n ? (this.currentTime = e) : this.updateTime(e);
    const y = this.currentTime - u * (this.playbackSpeed >= 0 ? 1 : -1),
      v = this.playbackSpeed >= 0 ? y < 0 : y > i;
    (this.currentTime = Math.max(y, 0)),
      this.state === "finished" &&
        this.holdTime === null &&
        (this.currentTime = i);
    let x = this.currentTime,
      w = s;
    if (h) {
      const b = Math.min(this.currentTime, i) / a;
      let F = Math.floor(b),
        S = b % 1;
      !S && b >= 1 && (S = 1),
        S === 1 && F--,
        (F = Math.min(F, h + 1)),
        F % 2 &&
          (f === "reverse"
            ? ((S = 1 - S), d && (S -= d / a))
            : f === "mirror" && (w = o)),
        (x = tt(0, 1, S) * a);
    }
    let A;
    v
      ? ((this.delayState.value = l[0]), (A = this.delayState))
      : (A = w.next(x)),
      r && !v && (A.value = r(A.value));
    let { done: E } = A;
    !v &&
      c !== null &&
      (E =
        this.playbackSpeed >= 0
          ? this.currentTime >= i
          : this.currentTime <= 0);
    const V =
      this.holdTime === null &&
      (this.state === "finished" || (this.state === "running" && E));
    return (
      V && p !== Re && (A.value = ae(l, this.options, g, this.speed)),
      m && m(A.value),
      V && this.finish(),
      A
    );
  }
  then(e, n) {
    return this.finished.then(e, n);
  }
  get duration() {
    return H(this.calculatedDuration);
  }
  get iterationDuration() {
    const { delay: e = 0 } = this.options || {};
    return this.duration + H(e);
  }
  get time() {
    return H(this.currentTime);
  }
  set time(e) {
    (e = K(e)),
      (this.currentTime = e),
      this.startTime === null ||
      this.holdTime !== null ||
      this.playbackSpeed === 0
        ? (this.holdTime = e)
        : this.driver &&
          (this.startTime = this.driver.now() - e / this.playbackSpeed),
      this.driver
        ? this.driver.start(!1)
        : ((this.startTime = 0),
          (this.state = "paused"),
          (this.holdTime = e),
          this.tick(e));
  }
  getGeneratorVelocity() {
    const e = this.currentTime;
    if (e <= 0) return this.options.velocity || 0;
    if (this.generator.velocity) return this.generator.velocity(e);
    const n = this.generator.next(e).value;
    return di((s) => this.generator.next(s).value, e, n);
  }
  get speed() {
    return this.playbackSpeed;
  }
  set speed(e) {
    const n = this.playbackSpeed !== e;
    n && this.driver && this.updateTime(N.now()),
      (this.playbackSpeed = e),
      n && this.driver && (this.time = H(this.currentTime));
  }
  play() {
    if (this.isStopped) return;
    const { driver: e = vr, startTime: n } = this.options;
    this.driver || (this.driver = e((i) => this.tick(i))),
      this.options.onPlay?.();
    const s = this.driver.now();
    this.state === "finished"
      ? (this.updateFinished(), (this.startTime = s))
      : this.holdTime !== null
      ? (this.startTime = s - this.holdTime)
      : this.startTime || (this.startTime = n ?? s),
      this.state === "finished" &&
        this.speed < 0 &&
        (this.startTime += this.calculatedDuration),
      (this.holdTime = null),
      (this.state = "running"),
      this.driver.start();
  }
  pause() {
    (this.state = "paused"),
      this.updateTime(N.now()),
      (this.holdTime = this.currentTime);
  }
  complete() {
    this.state !== "running" && this.play(),
      (this.state = "finished"),
      (this.holdTime = null);
  }
  finish() {
    this.notifyFinished(),
      this.teardown(),
      (this.state = "finished"),
      this.options.onComplete?.();
  }
  cancel() {
    (this.holdTime = null),
      (this.startTime = 0),
      this.tick(0),
      this.teardown(),
      this.options.onCancel?.();
  }
  teardown() {
    (this.state = "idle"),
      this.stopDriver(),
      (this.startTime = this.holdTime = null);
  }
  stopDriver() {
    this.driver && (this.driver.stop(), (this.driver = void 0));
  }
  sample(e) {
    return (this.startTime = 0), this.tick(e, !0);
  }
  attachTimeline(e) {
    return (
      this.options.allowFlatten &&
        ((this.options.type = "keyframes"),
        (this.options.ease = "linear"),
        this.initAnimation()),
      this.driver?.stop(),
      e.observe(this)
    );
  }
}
function Ir(t) {
  for (let e = 1; e < t.length; e++) t[e] ?? (t[e] = t[e - 1]);
}
const ft = (t) => (t * 180) / Math.PI,
  Le = (t) => {
    const e = ft(Math.atan2(t[1], t[0]));
    return ke(e);
  },
  jr = {
    x: 4,
    y: 5,
    translateX: 4,
    translateY: 5,
    scaleX: 0,
    scaleY: 3,
    scale: (t) => (Math.abs(t[0]) + Math.abs(t[3])) / 2,
    rotate: Le,
    rotateZ: Le,
    skewX: (t) => ft(Math.atan(t[1])),
    skewY: (t) => ft(Math.atan(t[2])),
    skew: (t) => (Math.abs(t[1]) + Math.abs(t[2])) / 2,
  },
  ke = (t) => ((t = t % 360), t < 0 && (t += 360), t),
  Bn = Le,
  Fn = (t) => Math.sqrt(t[0] * t[0] + t[1] * t[1]),
  In = (t) => Math.sqrt(t[4] * t[4] + t[5] * t[5]),
  Or = {
    x: 12,
    y: 13,
    z: 14,
    translateX: 12,
    translateY: 13,
    translateZ: 14,
    scaleX: Fn,
    scaleY: In,
    scale: (t) => (Fn(t) + In(t)) / 2,
    rotateX: (t) => ke(ft(Math.atan2(t[6], t[5]))),
    rotateY: (t) => ke(ft(Math.atan2(-t[2], t[0]))),
    rotateZ: Bn,
    rotate: Bn,
    skewX: (t) => ft(Math.atan(t[4])),
    skewY: (t) => ft(Math.atan(t[1])),
    skew: (t) => (Math.abs(t[1]) + Math.abs(t[4])) / 2,
  };
function Be(t) {
  return t.includes("scale") ? 1 : 0;
}
function Fe(t, e) {
  if (!t || t === "none") return Be(e);
  const n = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
  let s, i;
  if (n) (s = Or), (i = n);
  else {
    const a = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
    (s = jr), (i = a);
  }
  if (!i) return Be(e);
  const r = s[e],
    o = i[1].split(",").map(Ur);
  return typeof r == "function" ? r(o) : o[r];
}
const Nr = (t, e) => {
  const { transform: n = "none" } = getComputedStyle(t);
  return Fe(n, e);
};
function Ur(t) {
  return parseFloat(t.trim());
}
const St = [
    "transformPerspective",
    "x",
    "y",
    "z",
    "translateX",
    "translateY",
    "translateZ",
    "scale",
    "scaleX",
    "scaleY",
    "rotate",
    "rotateX",
    "rotateY",
    "rotateZ",
    "skew",
    "skewX",
    "skewY",
  ],
  bt = new Set([...St, "pathRotation"]),
  jn = (t) => t === Pt || t === T,
  Wr = new Set(["x", "y", "z"]),
  Kr = St.filter((t) => !Wr.has(t));
function $r(t) {
  const e = [];
  return (
    Kr.forEach((n) => {
      const s = t.getValue(n);
      s !== void 0 &&
        (e.push([n, s.get()]), s.set(n.startsWith("scale") ? 1 : 0));
    }),
    e
  );
}
const st = {
  width: (
    { x: t },
    { paddingLeft: e = "0", paddingRight: n = "0", boxSizing: s }
  ) => {
    const i = t.max - t.min;
    return s === "border-box" ? i : i - parseFloat(e) - parseFloat(n);
  },
  height: (
    { y: t },
    { paddingTop: e = "0", paddingBottom: n = "0", boxSizing: s }
  ) => {
    const i = t.max - t.min;
    return s === "border-box" ? i : i - parseFloat(e) - parseFloat(n);
  },
  top: (t, { top: e }) => parseFloat(e),
  left: (t, { left: e }) => parseFloat(e),
  bottom: ({ y: t }, { top: e }) => parseFloat(e) + (t.max - t.min),
  right: ({ x: t }, { left: e }) => parseFloat(e) + (t.max - t.min),
  x: (t, { transform: e }) => Fe(e, "x"),
  y: (t, { transform: e }) => Fe(e, "y"),
};
st.translateX = st.x;
st.translateY = st.y;
const dt = new Set();
let Ie = !1,
  je = !1,
  Oe = !1;
function mi() {
  if (je) {
    const t = Array.from(dt).filter((s) => s.needsMeasurement),
      e = new Set(t.map((s) => s.element)),
      n = new Map();
    e.forEach((s) => {
      const i = $r(s);
      i.length && (n.set(s, i), s.render());
    }),
      t.forEach((s) => s.measureInitialState()),
      e.forEach((s) => {
        s.render();
        const i = n.get(s);
        i &&
          i.forEach(([r, o]) => {
            s.getValue(r)?.set(o);
          });
      }),
      t.forEach((s) => s.measureEndState()),
      t.forEach((s) => {
        s.suspendedScrollY !== void 0 && window.scrollTo(0, s.suspendedScrollY);
      });
  }
  (je = !1), (Ie = !1), dt.forEach((t) => t.complete(Oe)), dt.clear();
}
function gi() {
  dt.forEach((t) => {
    t.readKeyframes(), t.needsMeasurement && (je = !0);
  });
}
function Hr() {
  (Oe = !0), gi(), mi(), (Oe = !1);
}
class fn {
  constructor(e, n, s, i, r, o = !1) {
    (this.state = "pending"),
      (this.isAsync = !1),
      (this.needsMeasurement = !1),
      (this.unresolvedKeyframes = [...e]),
      (this.onComplete = n),
      (this.name = s),
      (this.motionValue = i),
      (this.element = r),
      (this.isAsync = o);
  }
  scheduleResolve() {
    (this.state = "scheduled"),
      this.isAsync
        ? (dt.add(this), Ie || ((Ie = !0), D.read(gi), D.resolveKeyframes(mi)))
        : (this.readKeyframes(), this.complete());
  }
  readKeyframes() {
    const {
      unresolvedKeyframes: e,
      name: n,
      element: s,
      motionValue: i,
    } = this;
    if (e[0] === null) {
      const r = i?.get(),
        o = e[e.length - 1];
      if (r !== void 0) e[0] = r;
      else if (s && n) {
        const a = s.readValue(n, o);
        a != null && (e[0] = a);
      }
      e[0] === void 0 && (e[0] = o), i && r === void 0 && i.set(e[0]);
    }
    Ir(e);
  }
  setFinalKeyframe() {}
  measureInitialState() {}
  renderEndStyles() {}
  measureEndState() {}
  complete(e = !1) {
    (this.state = "complete"),
      this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e),
      dt.delete(this);
  }
  cancel() {
    this.state === "scheduled" && (dt.delete(this), (this.state = "pending"));
  }
  resume() {
    this.state === "pending" && this.scheduleResolve();
  }
}
const zr = (t) => t.startsWith("--");
function yi(t, e, n) {
  zr(e) ? t.style.setProperty(e, n) : (t.style[e] = n);
}
const Gr = {};
function vi(t, e) {
  const n = zs(t);
  return () => Gr[e] ?? n();
}
const _r = vi(() => window.ScrollTimeline !== void 0, "scrollTimeline"),
  xi = vi(() => {
    try {
      document
        .createElement("div")
        .animate({ opacity: 0 }, { easing: "linear(0, 1)" });
    } catch {
      return !1;
    }
    return !0;
  }, "linearEasing"),
  Vt = ([t, e, n, s]) => `cubic-bezier(${t}, ${e}, ${n}, ${s})`,
  On = {
    linear: "linear",
    ease: "ease",
    easeIn: "ease-in",
    easeOut: "ease-out",
    easeInOut: "ease-in-out",
    circIn: Vt([0, 0.65, 0.55, 1]),
    circOut: Vt([0.55, 0, 1, 0.45]),
    backIn: Vt([0.31, 0.01, 0.66, -0.59]),
    backOut: Vt([0.33, 1.53, 0.69, 0.99]),
  };
function Ti(t, e) {
  if (t)
    return typeof t == "function"
      ? xi()
        ? fi(t, e)
        : "ease-out"
      : ni(t)
      ? Vt(t)
      : Array.isArray(t)
      ? t.map((n) => Ti(n, e) || On.easeOut)
      : On[t];
}
function Xr(
  t,
  e,
  n,
  {
    delay: s = 0,
    duration: i = 300,
    repeat: r = 0,
    repeatType: o = "loop",
    ease: a = "easeOut",
    times: c,
  } = {},
  u = void 0
) {
  const l = { [e]: n };
  c && (l.offset = c);
  const h = Ti(a, i);
  Array.isArray(h) && (l.easing = h);
  const f = {
    delay: s,
    duration: i,
    easing: Array.isArray(h) ? "linear" : h,
    fill: "both",
    iterations: r + 1,
    direction: o === "reverse" ? "alternate" : "normal",
  };
  return u && (f.pseudoElement = u), t.animate(l, f);
}
function wi(t) {
  return typeof t == "function" && "applyToOptions" in t;
}
function Yr({ type: t, ...e }) {
  return wi(t) && xi()
    ? t.applyToOptions(e)
    : (e.duration ?? (e.duration = 300), e.ease ?? (e.ease = "easeOut"), e);
}
class Pi extends hn {
  constructor(e) {
    if (
      (super(),
      (this.finishedTime = null),
      (this.isStopped = !1),
      (this.manualStartTime = null),
      !e)
    )
      return;
    const {
      element: n,
      name: s,
      keyframes: i,
      pseudoElement: r,
      allowFlatten: o = !1,
      finalKeyframe: a,
      onComplete: c,
    } = e;
    (this.isPseudoElement = !!r),
      (this.allowFlatten = o),
      (this.options = e),
      en(typeof e.type != "string");
    const u = Yr(e);
    (this.animation = Xr(n, s, i, u, r)),
      u.autoplay === !1 && this.animation.pause(),
      (this.animation.onfinish = () => {
        if (((this.finishedTime = this.time), !r)) {
          const l = ae(i, this.options, a, this.speed);
          this.updateMotionValue && this.updateMotionValue(l),
            yi(n, s, l),
            this.animation.cancel();
        }
        c?.(), this.notifyFinished();
      });
  }
  play() {
    this.isStopped ||
      ((this.manualStartTime = null),
      this.animation.play(),
      this.state === "finished" && this.updateFinished());
  }
  pause() {
    this.animation.pause();
  }
  complete() {
    this.animation.finish?.();
  }
  cancel() {
    try {
      this.animation.cancel();
    } catch {}
  }
  stop() {
    if (this.isStopped) return;
    this.isStopped = !0;
    const { state: e } = this;
    e === "idle" ||
      e === "finished" ||
      (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(),
      this.isPseudoElement || this.cancel());
  }
  commitStyles() {
    const e = this.options?.element;
    !this.isPseudoElement && e?.isConnected && this.animation.commitStyles?.();
  }
  get duration() {
    const e = this.animation.effect?.getComputedTiming?.().duration || 0;
    return H(Number(e));
  }
  get iterationDuration() {
    const { delay: e = 0 } = this.options || {};
    return this.duration + H(e);
  }
  get time() {
    return H(Number(this.animation.currentTime) || 0);
  }
  set time(e) {
    const n = this.finishedTime !== null;
    (this.manualStartTime = null),
      (this.finishedTime = null),
      (this.animation.currentTime = K(e)),
      n && this.animation.pause();
  }
  get speed() {
    return this.animation.playbackRate;
  }
  set speed(e) {
    e < 0 && (this.finishedTime = null), (this.animation.playbackRate = e);
  }
  get state() {
    return this.finishedTime !== null ? "finished" : this.animation.playState;
  }
  get startTime() {
    return this.manualStartTime ?? Number(this.animation.startTime);
  }
  set startTime(e) {
    this.manualStartTime = this.animation.startTime = e;
  }
  attachTimeline({ timeline: e, rangeStart: n, rangeEnd: s, observe: i }) {
    return (
      this.allowFlatten &&
        this.animation.effect?.updateTiming({ easing: "linear" }),
      (this.animation.onfinish = null),
      e && _r()
        ? ((this.animation.timeline = e),
          n && (this.animation.rangeStart = n),
          s && (this.animation.rangeEnd = s),
          z)
        : i(this)
    );
  }
}
const Si = { anticipate: Js, backInOut: Zs, circInOut: ti };
function qr(t) {
  return t in Si;
}
function Zr(t) {
  typeof t.ease == "string" && qr(t.ease) && (t.ease = Si[t.ease]);
}
const ge = 10;
class Jr extends Pi {
  constructor(e) {
    Zr(e),
      pi(e),
      super(e),
      e.startTime !== void 0 &&
        e.autoplay !== !1 &&
        (this.startTime = e.startTime),
      (this.options = e);
  }
  updateMotionValue(e) {
    const {
      motionValue: n,
      onUpdate: s,
      onComplete: i,
      element: r,
      ...o
    } = this.options;
    if (!n) return;
    if (e !== void 0) {
      n.set(e);
      return;
    }
    const a = new ee({ ...o, autoplay: !1 }),
      c = Math.max(ge, N.now() - this.startTime),
      u = tt(0, ge, c - ge),
      l = a.sample(c).value,
      { name: h } = this.options;
    r && h && yi(r, h, l),
      n.setWithVelocity(a.sample(Math.max(0, c - u)).value, l, u),
      a.stop();
  }
}
const Nn = (t, e) =>
  e === "zIndex"
    ? !1
    : !!(
        typeof t == "number" ||
        Array.isArray(t) ||
        (typeof t == "string" &&
          (X.test(t) || t === "0") &&
          !t.startsWith("url("))
      );
function Qr(t) {
  const e = t[0];
  if (t.length === 1) return !0;
  for (let n = 0; n < t.length; n++) if (t[n] !== e) return !0;
}
function ta(t, e, n, s) {
  const i = t[0];
  if (i === null) return !1;
  if (e === "display" || e === "visibility") return !0;
  const r = t[t.length - 1],
    o = Nn(i, e),
    a = Nn(r, e);
  return !o || !a ? !1 : Qr(t) || ((n === "spring" || wi(n)) && s);
}
function Ne(t) {
  (t.duration = 0), (t.type = "keyframes");
}
const bi = new Set(["opacity", "clipPath", "filter", "transform"]),
  ea = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;
function na(t) {
  for (let e = 0; e < t.length; e++)
    if (typeof t[e] == "string" && ea.test(t[e])) return !0;
  return !1;
}
const sa = new Set([
    "color",
    "backgroundColor",
    "outlineColor",
    "fill",
    "stroke",
    "borderColor",
    "borderTopColor",
    "borderRightColor",
    "borderBottomColor",
    "borderLeftColor",
  ]),
  ia = zs(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
function oa(t) {
  const {
    motionValue: e,
    name: n,
    repeatDelay: s,
    repeatType: i,
    damping: r,
    type: o,
    keyframes: a,
  } = t;
  if (!(e?.owner?.current instanceof HTMLElement)) return !1;
  const { onUpdate: u, transformTemplate: l } = e.owner.getProps();
  return (
    ia() &&
    n &&
    (bi.has(n) || (sa.has(n) && na(a))) &&
    (n !== "transform" || !l) &&
    !u &&
    !s &&
    i !== "mirror" &&
    r !== 0 &&
    o !== "inertia"
  );
}
const ra = 40;
class aa extends hn {
  constructor({
    autoplay: e = !0,
    delay: n = 0,
    type: s = "keyframes",
    repeat: i = 0,
    repeatDelay: r = 0,
    repeatType: o = "loop",
    keyframes: a,
    name: c,
    motionValue: u,
    element: l,
    ...h
  }) {
    super(),
      (this.stop = () => {
        this._animation && (this._animation.stop(), this.stopTimeline?.()),
          this.keyframeResolver?.cancel();
      }),
      (this.createdAt = N.now());
    const f = {
        autoplay: e,
        delay: n,
        type: s,
        repeat: i,
        repeatDelay: r,
        repeatType: o,
        name: c,
        motionValue: u,
        element: l,
        ...h,
      },
      d = l?.KeyframeResolver || fn;
    (this.keyframeResolver = new d(
      a,
      (p, m, g) => this.onKeyframesResolved(p, m, f, !g),
      c,
      u,
      l
    )),
      this.keyframeResolver?.scheduleResolve();
  }
  onKeyframesResolved(e, n, s, i) {
    this.keyframeResolver = void 0;
    const {
      name: r,
      type: o,
      velocity: a,
      delay: c,
      isHandoff: u,
      onUpdate: l,
    } = s;
    this.resolvedAt = N.now();
    let h = !0;
    ta(e, r, o, a) ||
      ((h = !1),
      (it.instantAnimations || !c) && l?.(ae(e, s, n)),
      (e[0] = e[e.length - 1]),
      Ne(s),
      (s.repeat = 0));
    const d = {
        startTime: i
          ? this.resolvedAt
            ? this.resolvedAt - this.createdAt > ra
              ? this.resolvedAt
              : this.createdAt
            : this.createdAt
          : void 0,
        finalKeyframe: n,
        ...s,
        keyframes: e,
      },
      p = h && !u && oa(d),
      m = d.motionValue?.owner?.current;
    let g;
    if (p)
      try {
        g = new Jr({ ...d, element: m });
      } catch {
        g = new ee(d);
      }
    else g = new ee(d);
    g.finished
      .then(() => {
        this.notifyFinished();
      })
      .catch(z),
      this.pendingTimeline &&
        ((this.stopTimeline = g.attachTimeline(this.pendingTimeline)),
        (this.pendingTimeline = void 0)),
      (this._animation = g);
  }
  get finished() {
    return this._animation ? this.animation.finished : this._finished;
  }
  then(e, n) {
    return this.finished.finally(e).then(() => {});
  }
  get animation() {
    return (
      this._animation || (this.keyframeResolver?.resume(), Hr()),
      this._animation
    );
  }
  get duration() {
    return this.animation.duration;
  }
  get iterationDuration() {
    return this.animation.iterationDuration;
  }
  get time() {
    return this.animation.time;
  }
  set time(e) {
    this.animation.time = e;
  }
  get speed() {
    return this.animation.speed;
  }
  get state() {
    return this.animation.state;
  }
  set speed(e) {
    this.animation.speed = e;
  }
  get startTime() {
    return this.animation.startTime;
  }
  attachTimeline(e) {
    return (
      this._animation
        ? (this.stopTimeline = this.animation.attachTimeline(e))
        : (this.pendingTimeline = e),
      () => this.stop()
    );
  }
  play() {
    this.animation.play();
  }
  pause() {
    this.animation.pause();
  }
  complete() {
    this.animation.complete();
  }
  cancel() {
    this._animation && this.animation.cancel(), this.keyframeResolver?.cancel();
  }
}
function Ai(t, e, n, s = 0, i = 1) {
  const r = Array.from(t)
      .sort((u, l) => u.sortNodePosition(l))
      .indexOf(e),
    o = t.size,
    a = (o - 1) * s;
  return typeof n == "function" ? n(r, o) : i === 1 ? r * s : a - r * s;
}
const Un = 30,
  la = (t) => !isNaN(parseFloat(t));
class ca {
  constructor(e, n = {}) {
    (this.canTrackVelocity = null),
      (this.events = {}),
      (this.updateAndNotify = (s) => {
        const i = N.now();
        if (
          (this.updatedAt !== i && this.setPrevFrameValue(),
          (this.prev = this.current),
          this.setCurrent(s),
          this.current !== this.prev &&
            (this.events.change?.notify(this.current), this.dependents))
        )
          for (const r of this.dependents) r.dirty();
      }),
      (this.hasAnimated = !1),
      this.setCurrent(e),
      (this.owner = n.owner);
  }
  setCurrent(e) {
    (this.current = e),
      (this.updatedAt = N.now()),
      this.canTrackVelocity === null &&
        e !== void 0 &&
        (this.canTrackVelocity = la(this.current));
  }
  setPrevFrameValue(e = this.current) {
    (this.prevFrameValue = e), (this.prevUpdatedAt = this.updatedAt);
  }
  onChange(e) {
    return this.on("change", e);
  }
  on(e, n) {
    this.events[e] || (this.events[e] = new nn());
    const s = this.events[e].add(n);
    return e === "change"
      ? () => {
          s(),
            D.read(() => {
              this.events.change.getSize() || this.stop();
            });
        }
      : s;
  }
  clearListeners() {
    for (const e in this.events) this.events[e].clear();
  }
  attach(e, n) {
    (this.passiveEffect = e), (this.stopPassiveEffect = n);
  }
  set(e) {
    this.passiveEffect
      ? this.passiveEffect(e, this.updateAndNotify)
      : this.updateAndNotify(e);
  }
  setWithVelocity(e, n, s) {
    this.set(n),
      (this.prev = void 0),
      (this.prevFrameValue = e),
      (this.prevUpdatedAt = this.updatedAt - s);
  }
  jump(e, n = !0) {
    this.updateAndNotify(e),
      (this.prev = e),
      (this.prevUpdatedAt = this.prevFrameValue = void 0),
      n && this.stop(),
      this.stopPassiveEffect && this.stopPassiveEffect();
  }
  dirty() {
    this.events.change?.notify(this.current);
  }
  addDependent(e) {
    this.dependents || (this.dependents = new Set()), this.dependents.add(e);
  }
  removeDependent(e) {
    this.dependents && this.dependents.delete(e);
  }
  get() {
    return this.current;
  }
  getPrevious() {
    return this.prev;
  }
  getVelocity() {
    const e = N.now();
    if (
      !this.canTrackVelocity ||
      this.prevFrameValue === void 0 ||
      e - this.updatedAt > Un
    )
      return 0;
    const n = Math.min(this.updatedAt - this.prevUpdatedAt, Un);
    return Gs(parseFloat(this.current) - parseFloat(this.prevFrameValue), n);
  }
  start(e) {
    return (
      this.stop(),
      new Promise((n) => {
        (this.hasAnimated = !0),
          (this.animation = e(n)),
          this.events.animationStart && this.events.animationStart.notify();
      }).then(() => {
        this.events.animationComplete && this.events.animationComplete.notify(),
          this.clearAnimation();
      })
    );
  }
  stop() {
    this.animation &&
      (this.animation.stop(),
      this.events.animationCancel && this.events.animationCancel.notify()),
      this.clearAnimation();
  }
  isAnimating() {
    return !!this.animation;
  }
  clearAnimation() {
    delete this.animation;
  }
  destroy() {
    this.dependents?.clear(),
      this.events.destroy?.notify(),
      this.clearListeners(),
      this.stop(),
      this.stopPassiveEffect && this.stopPassiveEffect();
  }
}
function wt(t, e) {
  return new ca(t, e);
}
function Vi(t, e) {
  if (t?.inherit && e) {
    const { inherit: n, ...s } = t;
    return { ...e, ...s };
  }
  return t;
}
function dn(t, e) {
  const n = t?.[e] ?? t?.default ?? t;
  return n !== t ? Vi(n, t) : n;
}
const ua = { type: "spring", stiffness: 500, damping: 25, restSpeed: 10 },
  ha = (t) => ({
    type: "spring",
    stiffness: 550,
    damping: t === 0 ? 2 * Math.sqrt(550) : 30,
    restSpeed: 10,
  }),
  fa = { type: "keyframes", duration: 0.8 },
  da = { type: "keyframes", ease: [0.25, 0.1, 0.35, 1], duration: 0.3 },
  pa = (t, { keyframes: e }) =>
    e.length > 2
      ? fa
      : bt.has(t)
      ? t.startsWith("scale")
        ? ha(e[1])
        : ua
      : da,
  ma = new Set([
    "when",
    "delay",
    "delayChildren",
    "staggerChildren",
    "staggerDirection",
    "repeat",
    "repeatType",
    "repeatDelay",
    "from",
    "elapsed",
  ]);
function ga(t) {
  for (const e in t) if (!ma.has(e)) return !0;
  return !1;
}
const pn =
    (t, e, n, s = {}, i, r) =>
    (o) => {
      const a = dn(s, t) || {},
        c = a.delay || s.delay || 0;
      let { elapsed: u = 0 } = s;
      u = u - K(c);
      const l = {
        keyframes: Array.isArray(n) ? n : [null, n],
        ease: "easeOut",
        velocity: e.getVelocity(),
        ...a,
        delay: -u,
        onUpdate: (f) => {
          e.set(f), a.onUpdate && a.onUpdate(f);
        },
        onComplete: () => {
          o(), a.onComplete && a.onComplete();
        },
        name: t,
        motionValue: e,
        element: r ? void 0 : i,
      };
      ga(a) || Object.assign(l, pa(t, l)),
        l.duration && (l.duration = K(l.duration)),
        l.repeatDelay && (l.repeatDelay = K(l.repeatDelay)),
        l.from !== void 0 && (l.keyframes[0] = l.from);
      let h = !1;
      if (
        ((l.type === !1 || (l.duration === 0 && !l.repeatDelay)) &&
          (Ne(l), l.delay === 0 && (h = !0)),
        (it.instantAnimations ||
          it.skipAnimations ||
          i?.shouldSkipAnimations ||
          a.skipAnimations) &&
          ((h = !0), Ne(l), (l.delay = 0)),
        (l.allowFlatten = !a.type && !a.ease),
        h && !r && e.get() !== void 0)
      ) {
        const f = ae(l.keyframes, a);
        if (f !== void 0) {
          D.update(() => {
            l.onUpdate(f), l.onComplete();
          });
          return;
        }
      }
      return a.isSync ? new ee(l) : new aa(l);
    },
  ya = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function va(t) {
  const e = ya.exec(t);
  if (!e) return [,];
  const [, n, s, i] = e;
  return [`--${n ?? s}`, i];
}
function Ci(t, e, n = 1) {
  const [s, i] = va(t);
  if (!s) return;
  const r = window.getComputedStyle(e).getPropertyValue(s);
  if (r) {
    const o = r.trim();
    return Ks(o) ? parseFloat(o) : o;
  }
  return rn(i) ? Ci(i, e, n + 1) : i;
}
function Wn(t) {
  const e = [{}, {}];
  return (
    t?.values.forEach((n, s) => {
      (e[0][s] = n.get()), (e[1][s] = n.getVelocity());
    }),
    e
  );
}
function mn(t, e, n, s) {
  if (typeof e == "function") {
    const [i, r] = Wn(s);
    e = e(n !== void 0 ? n : t.custom, i, r);
  }
  if (
    (typeof e == "string" && (e = t.variants && t.variants[e]),
    typeof e == "function")
  ) {
    const [i, r] = Wn(s);
    e = e(n !== void 0 ? n : t.custom, i, r);
  }
  return e;
}
function pt(t, e, n) {
  const s = t.getProps();
  return mn(s, e, n !== void 0 ? n : s.custom, t);
}
const Mi = new Set([
    "width",
    "height",
    "top",
    "left",
    "right",
    "bottom",
    ...St,
  ]),
  Ue = (t) => Array.isArray(t);
function xa(t, e, n) {
  t.hasValue(e) ? t.getValue(e).set(n) : t.addValue(e, wt(n));
}
function Ta(t) {
  return Ue(t) ? t[t.length - 1] || 0 : t;
}
function wa(t, e) {
  const n = pt(t, e);
  let { transitionEnd: s = {}, transition: i = {}, ...r } = n || {};
  r = { ...r, ...s };
  for (const o in r) {
    const a = Ta(r[o]);
    xa(t, o, a);
  }
}
const O = (t) => !!(t && t.getVelocity);
function Pa(t) {
  return !!(O(t) && t.add);
}
function We(t, e) {
  const n = t.getValue("willChange");
  if (Pa(n)) return n.add(e);
  if (!n && it.WillChange) {
    const s = new it.WillChange("auto");
    t.addValue("willChange", s), s.add(e);
  }
}
function gn(t) {
  return t.replace(/([A-Z])/g, (e) => `-${e.toLowerCase()}`);
}
const Sa = "framerAppearId",
  Di = "data-" + gn(Sa);
function Ei(t) {
  return t.props[Di];
}
function ba({ protectedKeys: t, needsAnimating: e }, n) {
  const s = t.hasOwnProperty(n) && e[n] !== !0;
  return (e[n] = !1), s;
}
function Ri(t, e, { delay: n = 0, transitionOverride: s, type: i } = {}) {
  let { transition: r, transitionEnd: o, ...a } = e;
  const c = t.getDefaultTransition();
  r = r ? Vi(r, c) : c;
  const u = r?.reduceMotion,
    l = r?.skipAnimations;
  s && (r = s);
  const h = [],
    f = i && t.animationState && t.animationState.getState()[i],
    d = r?.path;
  d && d.animateVisualElement(t, a, r, n, h);
  for (const p in a) {
    const m = t.getValue(p, t.latestValues[p] ?? null),
      g = a[p];
    if (g === void 0 || (f && ba(f, p))) continue;
    const y = { delay: n, ...dn(r || {}, p) };
    l && (y.skipAnimations = !0);
    const v = m.get();
    if (
      v !== void 0 &&
      !m.isAnimating() &&
      !Array.isArray(g) &&
      g === v &&
      !y.velocity
    ) {
      D.update(() => m.set(g));
      continue;
    }
    let x = !1;
    if (window.MotionHandoffAnimation) {
      const E = Ei(t);
      if (E) {
        const V = window.MotionHandoffAnimation(E, p, D);
        V !== null && ((y.startTime = V), (x = !0));
      }
    }
    We(t, p);
    const w = u ?? t.shouldReduceMotion;
    m.start(pn(p, m, g, w && Mi.has(p) ? { type: !1 } : y, t, x));
    const A = m.animation;
    A && h.push(A);
  }
  if (o) {
    const p = () =>
      D.update(() => {
        o && wa(t, o);
      });
    h.length ? Promise.all(h).then(p) : p();
  }
  return h;
}
function Ke(t, e, n = {}) {
  const s = pt(t, e, n.type === "exit" ? t.presenceContext?.custom : void 0);
  let { transition: i = t.getDefaultTransition() || {} } = s || {};
  n.transitionOverride && (i = n.transitionOverride);
  const r = s ? () => Promise.all(Ri(t, s, n)) : () => Promise.resolve(),
    o =
      t.variantChildren && t.variantChildren.size
        ? (c = 0) => {
            const {
              delayChildren: u = 0,
              staggerChildren: l,
              staggerDirection: h,
            } = i;
            return Aa(t, e, c, u, l, h, n);
          }
        : () => Promise.resolve(),
    { when: a } = i;
  if (a) {
    const [c, u] = a === "beforeChildren" ? [r, o] : [o, r];
    return c().then(() => u());
  } else return Promise.all([r(), o(n.delay)]);
}
function Aa(t, e, n = 0, s = 0, i = 0, r = 1, o) {
  const a = [];
  for (const c of t.variantChildren)
    c.notify("AnimationStart", e),
      a.push(
        Ke(c, e, {
          ...o,
          delay:
            n +
            (typeof s == "function" ? 0 : s) +
            Ai(t.variantChildren, c, s, i, r),
        }).then(() => c.notify("AnimationComplete", e))
      );
  return Promise.all(a);
}
function Va(t, e, n = {}) {
  t.notify("AnimationStart", e);
  let s;
  if (Array.isArray(e)) {
    const i = e.map((r) => Ke(t, r, n));
    s = Promise.all(i);
  } else if (typeof e == "string") s = Ke(t, e, n);
  else {
    const i = typeof e == "function" ? pt(t, e, n.custom) : e;
    s = Promise.all(Ri(t, i, n));
  }
  return s.then(() => {
    t.notify("AnimationComplete", e);
  });
}
const Ca = { test: (t) => t === "auto", parse: (t) => t },
  Li = (t) => (e) => e.test(t),
  ki = [Pt, T, Q, nt, Qo, Jo, Ca],
  Kn = (t) => ki.find(Li(t));
function Ma(t) {
  return typeof t == "number"
    ? t === 0
    : t !== null
    ? t === "none" || t === "0" || Hs(t)
    : !0;
}
const Da = new Set(["brightness", "contrast", "saturate", "opacity"]);
function Ea(t) {
  const [e, n] = t.slice(0, -1).split("(");
  if (e === "drop-shadow") return t;
  const [s] = n.match(an) || [];
  if (!s) return t;
  const i = n.replace(s, "");
  let r = Da.has(e) ? 1 : 0;
  return s !== n && (r *= 100), e + "(" + r + i + ")";
}
const Ra = /\b([a-z-]*)\(.*?\)/gu,
  $e = {
    ...X,
    getAnimatableNone: (t) => {
      const e = t.match(Ra);
      return e ? e.map(Ea).join(" ") : t;
    },
  },
  He = {
    ...X,
    getAnimatableNone: (t) => {
      const e = X.parse(t);
      return X.createTransformer(t)(
        e.map((s) =>
          typeof s == "number"
            ? 0
            : typeof s == "object"
            ? { ...s, alpha: 1 }
            : s
        )
      );
    },
  },
  $n = { ...Pt, transform: Math.round },
  La = {
    rotate: nt,
    pathRotation: nt,
    rotateX: nt,
    rotateY: nt,
    rotateZ: nt,
    scale: Ut,
    scaleX: Ut,
    scaleY: Ut,
    scaleZ: Ut,
    skew: nt,
    skewX: nt,
    skewY: nt,
    distance: T,
    translateX: T,
    translateY: T,
    translateZ: T,
    x: T,
    y: T,
    z: T,
    perspective: T,
    transformPerspective: T,
    opacity: Lt,
    originX: Dn,
    originY: Dn,
    originZ: T,
  },
  ne = {
    borderWidth: T,
    borderTopWidth: T,
    borderRightWidth: T,
    borderBottomWidth: T,
    borderLeftWidth: T,
    borderRadius: T,
    borderTopLeftRadius: T,
    borderTopRightRadius: T,
    borderBottomRightRadius: T,
    borderBottomLeftRadius: T,
    width: T,
    maxWidth: T,
    height: T,
    maxHeight: T,
    top: T,
    right: T,
    bottom: T,
    left: T,
    inset: T,
    insetBlock: T,
    insetBlockStart: T,
    insetBlockEnd: T,
    insetInline: T,
    insetInlineStart: T,
    insetInlineEnd: T,
    padding: T,
    paddingTop: T,
    paddingRight: T,
    paddingBottom: T,
    paddingLeft: T,
    paddingBlock: T,
    paddingBlockStart: T,
    paddingBlockEnd: T,
    paddingInline: T,
    paddingInlineStart: T,
    paddingInlineEnd: T,
    margin: T,
    marginTop: T,
    marginRight: T,
    marginBottom: T,
    marginLeft: T,
    marginBlock: T,
    marginBlockStart: T,
    marginBlockEnd: T,
    marginInline: T,
    marginInlineStart: T,
    marginInlineEnd: T,
    fontSize: T,
    backgroundPositionX: T,
    backgroundPositionY: T,
    ...La,
    zIndex: $n,
    fillOpacity: Lt,
    strokeOpacity: Lt,
    numOctaves: $n,
  },
  ka = {
    ...ne,
    color: k,
    backgroundColor: k,
    outlineColor: k,
    fill: k,
    stroke: k,
    borderColor: k,
    borderTopColor: k,
    borderRightColor: k,
    borderBottomColor: k,
    borderLeftColor: k,
    filter: $e,
    WebkitFilter: $e,
    mask: He,
    WebkitMask: He,
  },
  Bi = (t) => ka[t],
  Ba = new Set([$e, He]);
function Fi(t, e) {
  let n = Bi(t);
  return (
    Ba.has(n) || (n = X), n.getAnimatableNone ? n.getAnimatableNone(e) : void 0
  );
}
const Fa = new Set(["auto", "none", "0"]);
function Ia(t, e, n) {
  let s = 0,
    i;
  for (; s < t.length && !i; ) {
    const r = t[s];
    typeof r == "string" && !Fa.has(r) && Tt(r).values.length && (i = t[s]),
      s++;
  }
  if (i && n) for (const r of e) t[r] = Fi(n, i);
}
class ja extends fn {
  constructor(e, n, s, i, r) {
    super(e, n, s, i, r, !0);
  }
  readKeyframes() {
    const { unresolvedKeyframes: e, element: n, name: s } = this;
    if (!n || !n.current) return;
    super.readKeyframes();
    for (let l = 0; l < e.length; l++) {
      let h = e[l];
      if (typeof h == "string" && ((h = h.trim()), rn(h))) {
        const f = Ci(h, n.current);
        f !== void 0 && (e[l] = f),
          l === e.length - 1 && (this.finalKeyframe = h);
      }
    }
    if ((this.resolveNoneKeyframes(), !Mi.has(s) || e.length !== 2)) return;
    const [i, r] = e,
      o = Kn(i),
      a = Kn(r),
      c = Mn(i),
      u = Mn(r);
    if (c !== u && st[s]) {
      this.needsMeasurement = !0;
      return;
    }
    if (o !== a)
      if (jn(o) && jn(a))
        for (let l = 0; l < e.length; l++) {
          const h = e[l];
          typeof h == "string" && (e[l] = parseFloat(h));
        }
      else st[s] && (this.needsMeasurement = !0);
  }
  resolveNoneKeyframes() {
    const { unresolvedKeyframes: e, name: n } = this,
      s = [];
    for (let i = 0; i < e.length; i++) (e[i] === null || Ma(e[i])) && s.push(i);
    s.length && Ia(e, s, n);
  }
  measureInitialState() {
    const { element: e, unresolvedKeyframes: n, name: s } = this;
    if (!e || !e.current) return;
    s === "height" && (this.suspendedScrollY = window.pageYOffset),
      (this.measuredOrigin = st[s](
        e.measureViewportBox(),
        window.getComputedStyle(e.current)
      )),
      (n[0] = this.measuredOrigin);
    const i = n[n.length - 1];
    i !== void 0 && e.getValue(s, i).jump(i, !1);
  }
  measureEndState() {
    const { element: e, name: n, unresolvedKeyframes: s } = this;
    if (!e || !e.current) return;
    const i = e.getValue(n);
    i && i.jump(this.measuredOrigin, !1);
    const r = s.length - 1,
      o = s[r];
    (s[r] = st[n](e.measureViewportBox(), window.getComputedStyle(e.current))),
      o !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = o),
      this.removedTransforms?.length &&
        this.removedTransforms.forEach(([a, c]) => {
          e.getValue(a).set(c);
        }),
      this.resolveNoneKeyframes();
  }
}
function Ii(t, e, n) {
  if (t == null) return [];
  if (t instanceof EventTarget) return [t];
  if (typeof t == "string") {
    let s = document;
    const i = n?.[t] ?? s.querySelectorAll(t);
    return i ? Array.from(i) : [];
  }
  return Array.from(t).filter((s) => s != null);
}
const ze = (t, e) => (e && typeof t == "number" ? e.transform(t) : t);
function Oa(t) {
  return $s(t) && "offsetHeight" in t && !("ownerSVGElement" in t);
}
const { schedule: yn } = si(queueMicrotask, !1),
  _ = { x: !1, y: !1 };
function ji() {
  return _.x || _.y;
}
function Na(t) {
  return t === "x" || t === "y"
    ? _[t]
      ? null
      : ((_[t] = !0),
        () => {
          _[t] = !1;
        })
    : _.x || _.y
    ? null
    : ((_.x = _.y = !0),
      () => {
        _.x = _.y = !1;
      });
}
function Oi(t, e) {
  const n = Ii(t),
    s = new AbortController(),
    i = { passive: !0, ...e, signal: s.signal };
  return [n, i, () => s.abort()];
}
function Ua(t) {
  return !(t.pointerType === "touch" || ji());
}
function Wa(t, e, n = {}) {
  const [s, i, r] = Oi(t, n);
  return (
    s.forEach((o) => {
      let a = !1,
        c = !1,
        u;
      const l = () => {
          o.removeEventListener("pointerleave", p);
        },
        h = (g) => {
          u && (u(g), (u = void 0)), l();
        },
        f = (g) => {
          (a = !1),
            window.removeEventListener("pointerup", f),
            window.removeEventListener("pointercancel", f),
            c && ((c = !1), h(g));
        },
        d = () => {
          (a = !0),
            window.addEventListener("pointerup", f, i),
            window.addEventListener("pointercancel", f, i);
        },
        p = (g) => {
          if (g.pointerType !== "touch") {
            if (a) {
              c = !0;
              return;
            }
            h(g);
          }
        },
        m = (g) => {
          if (!Ua(g)) return;
          c = !1;
          const y = e(o, g);
          typeof y == "function" &&
            ((u = y), o.addEventListener("pointerleave", p, i));
        };
      o.addEventListener("pointerenter", m, i),
        o.addEventListener("pointerdown", d, i);
    }),
    r
  );
}
const Ni = (t, e) => (e ? (t === e ? !0 : Ni(t, e.parentElement)) : !1),
  vn = (t) =>
    t.pointerType === "mouse"
      ? typeof t.button != "number" || t.button <= 0
      : t.isPrimary !== !1,
  Ka = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
function $a(t) {
  return Ka.has(t.tagName) || t.isContentEditable === !0;
}
const Ha = new Set(["INPUT", "SELECT", "TEXTAREA"]);
function za(t) {
  return Ha.has(t.tagName) || t.isContentEditable === !0;
}
const Ht = new WeakSet();
function Hn(t) {
  return (e) => {
    e.key === "Enter" && t(e);
  };
}
function ye(t, e) {
  t.dispatchEvent(
    new PointerEvent("pointer" + e, { isPrimary: !0, bubbles: !0 })
  );
}
const Ga = (t, e) => {
  const n = t.currentTarget;
  if (!n) return;
  const s = Hn(() => {
    if (Ht.has(n)) return;
    ye(n, "down");
    const i = Hn(() => {
        ye(n, "up");
      }),
      r = () => ye(n, "cancel");
    n.addEventListener("keyup", i, e), n.addEventListener("blur", r, e);
  });
  n.addEventListener("keydown", s, e),
    n.addEventListener("blur", () => n.removeEventListener("keydown", s), e);
};
function zn(t) {
  return vn(t) && !ji();
}
const Gn = new WeakSet();
function _a(t, e, n = {}) {
  const [s, i, r] = Oi(t, n),
    o = (a) => {
      const c = a.currentTarget;
      if (!zn(a) || Gn.has(a)) return;
      Ht.add(c), n.stopPropagation && Gn.add(a);
      const u = e(c, a),
        l = (d, p) => {
          window.removeEventListener("pointerup", h),
            window.removeEventListener("pointercancel", f),
            Ht.has(c) && Ht.delete(c),
            zn(d) && typeof u == "function" && u(d, { success: p });
        },
        h = (d) => {
          l(
            d,
            c === window ||
              c === document ||
              n.useGlobalTarget ||
              Ni(c, d.target)
          );
        },
        f = (d) => {
          l(d, !1);
        };
      window.addEventListener("pointerup", h, i),
        window.addEventListener("pointercancel", f, i);
    };
  return (
    s.forEach((a) => {
      (n.useGlobalTarget ? window : a).addEventListener("pointerdown", o, i),
        Oa(a) &&
          (a.addEventListener("focus", (u) => Ga(u, i)),
          !$a(a) && !a.hasAttribute("tabindex") && (a.tabIndex = 0));
    }),
    r
  );
}
function xn(t) {
  return $s(t) && "ownerSVGElement" in t;
}
const zt = new WeakMap();
let Gt;
const Ui = (t, e, n) => (s, i) =>
    i && i[0]
      ? i[0][t + "Size"]
      : xn(s) && "getBBox" in s
      ? s.getBBox()[e]
      : s[n],
  Xa = Ui("inline", "width", "offsetWidth"),
  Ya = Ui("block", "height", "offsetHeight");
function qa({ target: t, borderBoxSize: e }) {
  zt.get(t)?.forEach((n) => {
    n(t, {
      get width() {
        return Xa(t, e);
      },
      get height() {
        return Ya(t, e);
      },
    });
  });
}
function Za(t) {
  t.forEach(qa);
}
function Ja() {
  typeof ResizeObserver > "u" || (Gt = new ResizeObserver(Za));
}
function Qa(t, e) {
  Gt || Ja();
  const n = Ii(t);
  return (
    n.forEach((s) => {
      let i = zt.get(s);
      i || ((i = new Set()), zt.set(s, i)), i.add(e), Gt?.observe(s);
    }),
    () => {
      n.forEach((s) => {
        const i = zt.get(s);
        i?.delete(e), i?.size || Gt?.unobserve(s);
      });
    }
  );
}
const _t = new Set();
let vt;
function tl() {
  (vt = () => {
    const t = {
      get width() {
        return window.innerWidth;
      },
      get height() {
        return window.innerHeight;
      },
    };
    _t.forEach((e) => e(t));
  }),
    window.addEventListener("resize", vt);
}
function el(t) {
  return (
    _t.add(t),
    vt || tl(),
    () => {
      _t.delete(t),
        !_t.size &&
          typeof vt == "function" &&
          (window.removeEventListener("resize", vt), (vt = void 0));
    }
  );
}
function _n(t, e) {
  return typeof t == "function" ? el(t) : Qa(t, e);
}
function nl(t) {
  return xn(t) && t.tagName === "svg";
}
const sl = [...ki, k, X],
  il = (t) => sl.find(Li(t)),
  Xn = () => ({ translate: 0, scale: 1, origin: 0, originPoint: 0 }),
  xt = () => ({ x: Xn(), y: Xn() }),
  Yn = () => ({ min: 0, max: 0 }),
  B = () => ({ x: Yn(), y: Yn() }),
  ol = new WeakMap();
function le(t) {
  return t !== null && typeof t == "object" && typeof t.start == "function";
}
function kt(t) {
  return typeof t == "string" || Array.isArray(t);
}
const Tn = [
    "animate",
    "whileInView",
    "whileFocus",
    "whileHover",
    "whileTap",
    "whileDrag",
    "exit",
  ],
  wn = ["initial", ...Tn];
function ce(t) {
  return le(t.animate) || wn.some((e) => kt(t[e]));
}
function Wi(t) {
  return !!(ce(t) || t.variants);
}
function rl(t, e, n) {
  for (const s in e) {
    const i = e[s],
      r = n[s];
    if (O(i)) t.addValue(s, i);
    else if (O(r)) t.addValue(s, wt(i, { owner: t }));
    else if (r !== i)
      if (t.hasValue(s)) {
        const o = t.getValue(s);
        o.liveStyle === !0 ? o.jump(i) : o.hasAnimated || o.set(i);
      } else {
        const o = t.getStaticValue(s);
        t.addValue(s, wt(o !== void 0 ? o : i, { owner: t }));
      }
  }
  for (const s in n) e[s] === void 0 && t.removeValue(s);
  return e;
}
const Ge = { current: null },
  Ki = { current: !1 },
  al = typeof window < "u";
function ll() {
  if (((Ki.current = !0), !!al))
    if (window.matchMedia) {
      const t = window.matchMedia("(prefers-reduced-motion)"),
        e = () => (Ge.current = t.matches);
      t.addEventListener("change", e), e();
    } else Ge.current = !1;
}
const qn = [
  "AnimationStart",
  "AnimationComplete",
  "Update",
  "BeforeLayoutMeasure",
  "LayoutMeasure",
  "LayoutAnimationStart",
  "LayoutAnimationComplete",
];
let se = {};
function $i(t) {
  se = t;
}
function cl() {
  return se;
}
class ul {
  scrapeMotionValuesFromProps(e, n, s) {
    return {};
  }
  constructor(
    {
      parent: e,
      props: n,
      presenceContext: s,
      reducedMotionConfig: i,
      skipAnimations: r,
      blockInitialAnimation: o,
      visualState: a,
    },
    c = {}
  ) {
    (this.current = null),
      (this.children = new Set()),
      (this.isVariantNode = !1),
      (this.isControllingVariants = !1),
      (this.shouldReduceMotion = null),
      (this.shouldSkipAnimations = !1),
      (this.values = new Map()),
      (this.KeyframeResolver = fn),
      (this.features = {}),
      (this.valueSubscriptions = new Map()),
      (this.prevMotionValues = {}),
      (this.hasBeenMounted = !1),
      (this.events = {}),
      (this.propEventSubscriptions = {}),
      (this.notifyUpdate = () => this.notify("Update", this.latestValues)),
      (this.render = () => {
        this.current &&
          (this.triggerBuild(),
          this.renderInstance(
            this.current,
            this.renderState,
            this.props.style,
            this.projection
          ));
      }),
      (this.renderScheduledAt = 0),
      (this.scheduleRender = () => {
        const d = N.now();
        this.renderScheduledAt < d &&
          ((this.renderScheduledAt = d), D.render(this.render, !1, !0));
      });
    const { latestValues: u, renderState: l } = a;
    (this.latestValues = u),
      (this.baseTarget = { ...u }),
      (this.initialValues = n.initial ? { ...u } : {}),
      (this.renderState = l),
      (this.parent = e),
      (this.props = n),
      (this.presenceContext = s),
      (this.depth = e ? e.depth + 1 : 0),
      (this.reducedMotionConfig = i),
      (this.skipAnimationsConfig = r),
      (this.options = c),
      (this.blockInitialAnimation = !!o),
      (this.isControllingVariants = ce(n)),
      (this.isVariantNode = Wi(n)),
      this.isVariantNode && (this.variantChildren = new Set()),
      (this.manuallyAnimateOnMount = !!(e && e.current));
    const { willChange: h, ...f } = this.scrapeMotionValuesFromProps(
      n,
      {},
      this
    );
    for (const d in f) {
      const p = f[d];
      u[d] !== void 0 && O(p) && p.set(u[d]);
    }
  }
  mount(e) {
    if (this.hasBeenMounted)
      for (const n in this.initialValues)
        this.values.get(n)?.jump(this.initialValues[n]),
          (this.latestValues[n] = this.initialValues[n]);
    (this.current = e),
      ol.set(e, this),
      this.projection && !this.projection.instance && this.projection.mount(e),
      this.parent &&
        this.isVariantNode &&
        !this.isControllingVariants &&
        (this.removeFromVariantTree = this.parent.addVariantChild(this)),
      this.values.forEach((n, s) => this.bindToMotionValue(s, n)),
      this.reducedMotionConfig === "never"
        ? (this.shouldReduceMotion = !1)
        : this.reducedMotionConfig === "always"
        ? (this.shouldReduceMotion = !0)
        : (Ki.current || ll(), (this.shouldReduceMotion = Ge.current)),
      (this.shouldSkipAnimations = this.skipAnimationsConfig ?? !1),
      this.parent?.addChild(this),
      this.update(this.props, this.presenceContext),
      (this.hasBeenMounted = !0);
  }
  unmount() {
    this.projection && this.projection.unmount(),
      ot(this.notifyUpdate),
      ot(this.render),
      this.valueSubscriptions.forEach((e) => e()),
      this.valueSubscriptions.clear(),
      this.removeFromVariantTree && this.removeFromVariantTree(),
      this.parent?.removeChild(this);
    for (const e in this.events) this.events[e].clear();
    for (const e in this.features) {
      const n = this.features[e];
      n && (n.unmount(), (n.isMounted = !1));
    }
    this.current = null;
  }
  addChild(e) {
    this.children.add(e),
      this.enteringChildren ?? (this.enteringChildren = new Set()),
      this.enteringChildren.add(e);
  }
  removeChild(e) {
    this.children.delete(e),
      this.enteringChildren && this.enteringChildren.delete(e);
  }
  bindToMotionValue(e, n) {
    if (
      (this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)(),
      n.accelerate && bi.has(e) && this.current instanceof HTMLElement)
    ) {
      const {
          factory: o,
          keyframes: a,
          times: c,
          ease: u,
          duration: l,
        } = n.accelerate,
        h = new Pi({
          element: this.current,
          name: e,
          keyframes: a,
          times: c,
          ease: u,
          duration: K(l),
        }),
        f = o(h);
      this.valueSubscriptions.set(e, () => {
        f(), h.cancel();
      });
      return;
    }
    const s = bt.has(e);
    s && this.onBindTransform && this.onBindTransform();
    const i = n.on("change", (o) => {
      (this.latestValues[e] = o),
        this.props.onUpdate && D.preRender(this.notifyUpdate),
        s && this.projection && (this.projection.isTransformDirty = !0),
        this.scheduleRender();
    });
    let r;
    typeof window < "u" &&
      window.MotionCheckAppearSync &&
      (r = window.MotionCheckAppearSync(this, e, n)),
      this.valueSubscriptions.set(e, () => {
        i(), r && r();
      });
  }
  sortNodePosition(e) {
    return !this.current ||
      !this.sortInstanceNodePosition ||
      this.type !== e.type
      ? 0
      : this.sortInstanceNodePosition(this.current, e.current);
  }
  updateFeatures() {
    let e = "animation";
    for (e in se) {
      const n = se[e];
      if (!n) continue;
      const { isEnabled: s, Feature: i } = n;
      if (
        (!this.features[e] &&
          i &&
          s(this.props) &&
          (this.features[e] = new i(this)),
        this.features[e])
      ) {
        const r = this.features[e];
        r.isMounted ? r.update() : (r.mount(), (r.isMounted = !0));
      }
    }
  }
  triggerBuild() {
    this.build(this.renderState, this.latestValues, this.props);
  }
  measureViewportBox() {
    return this.current
      ? this.measureInstanceViewportBox(this.current, this.props)
      : B();
  }
  getStaticValue(e) {
    return this.latestValues[e];
  }
  setStaticValue(e, n) {
    this.latestValues[e] = n;
  }
  update(e, n) {
    (e.transformTemplate || this.props.transformTemplate) &&
      this.scheduleRender(),
      (this.prevProps = this.props),
      (this.props = e),
      (this.prevPresenceContext = this.presenceContext),
      (this.presenceContext = n);
    for (let s = 0; s < qn.length; s++) {
      const i = qn[s];
      this.propEventSubscriptions[i] &&
        (this.propEventSubscriptions[i](),
        delete this.propEventSubscriptions[i]);
      const r = "on" + i,
        o = e[r];
      o && (this.propEventSubscriptions[i] = this.on(i, o));
    }
    (this.prevMotionValues = rl(
      this,
      this.scrapeMotionValuesFromProps(e, this.prevProps || {}, this),
      this.prevMotionValues
    )),
      this.handleChildMotionValue && this.handleChildMotionValue();
  }
  getProps() {
    return this.props;
  }
  getVariant(e) {
    return this.props.variants ? this.props.variants[e] : void 0;
  }
  getDefaultTransition() {
    return this.props.transition;
  }
  getTransformPagePoint() {
    return this.props.transformPagePoint;
  }
  getClosestVariantNode() {
    return this.isVariantNode
      ? this
      : this.parent
      ? this.parent.getClosestVariantNode()
      : void 0;
  }
  addVariantChild(e) {
    const n = this.getClosestVariantNode();
    if (n)
      return (
        n.variantChildren && n.variantChildren.add(e),
        () => n.variantChildren.delete(e)
      );
  }
  addValue(e, n) {
    const s = this.values.get(e);
    n !== s &&
      (s && this.removeValue(e),
      this.bindToMotionValue(e, n),
      this.values.set(e, n),
      (this.latestValues[e] = n.get()));
  }
  removeValue(e) {
    this.values.delete(e);
    const n = this.valueSubscriptions.get(e);
    n && (n(), this.valueSubscriptions.delete(e)),
      delete this.latestValues[e],
      this.removeValueFromRenderState(e, this.renderState);
  }
  hasValue(e) {
    return this.values.has(e);
  }
  getValue(e, n) {
    if (this.props.values && this.props.values[e]) return this.props.values[e];
    let s = this.values.get(e);
    return (
      s === void 0 &&
        n !== void 0 &&
        ((s = wt(n === null ? void 0 : n, { owner: this })),
        this.addValue(e, s)),
      s
    );
  }
  readValue(e, n) {
    let s =
      this.latestValues[e] !== void 0 || !this.current
        ? this.latestValues[e]
        : this.getBaseTargetFromProps(this.props, e) ??
          this.readValueFromInstance(this.current, e, this.options);
    return (
      s != null &&
        (typeof s == "string" && (Ks(s) || Hs(s))
          ? (s = parseFloat(s))
          : !il(s) && X.test(n) && (s = Fi(e, n)),
        this.setBaseTarget(e, O(s) ? s.get() : s)),
      O(s) ? s.get() : s
    );
  }
  setBaseTarget(e, n) {
    this.baseTarget[e] = n;
  }
  getBaseTarget(e) {
    const { initial: n } = this.props;
    let s;
    if (typeof n == "string" || typeof n == "object") {
      const r = mn(this.props, n, this.presenceContext?.custom);
      r && (s = r[e]);
    }
    if (n && s !== void 0) return s;
    const i = this.getBaseTargetFromProps(this.props, e);
    return i !== void 0 && !O(i)
      ? i
      : this.initialValues[e] !== void 0 && s === void 0
      ? void 0
      : this.baseTarget[e];
  }
  on(e, n) {
    return this.events[e] || (this.events[e] = new nn()), this.events[e].add(n);
  }
  notify(e, ...n) {
    this.events[e] && this.events[e].notify(...n);
  }
  scheduleRenderMicrotask() {
    yn.render(this.render);
  }
}
class Hi extends ul {
  constructor() {
    super(...arguments), (this.KeyframeResolver = ja);
  }
  sortInstanceNodePosition(e, n) {
    return e.compareDocumentPosition(n) & 2 ? 1 : -1;
  }
  getBaseTargetFromProps(e, n) {
    const s = e.style;
    return s ? s[n] : void 0;
  }
  removeValueFromRenderState(e, { vars: n, style: s }) {
    delete n[e], delete s[e];
  }
  handleChildMotionValue() {
    this.childSubscription &&
      (this.childSubscription(), delete this.childSubscription);
    const { children: e } = this.props;
    O(e) &&
      (this.childSubscription = e.on("change", (n) => {
        this.current && (this.current.textContent = `${n}`);
      }));
  }
}
class rt {
  constructor(e) {
    (this.isMounted = !1), (this.node = e);
  }
  update() {}
}
function zi({ top: t, left: e, right: n, bottom: s }) {
  return { x: { min: e, max: n }, y: { min: t, max: s } };
}
function hl({ x: t, y: e }) {
  return { top: e.min, right: t.max, bottom: e.max, left: t.min };
}
function fl(t, e) {
  if (!e) return t;
  const n = e({ x: t.left, y: t.top }),
    s = e({ x: t.right, y: t.bottom });
  return { top: n.y, left: n.x, bottom: s.y, right: s.x };
}
function ve(t) {
  return t === void 0 || t === 1;
}
function _e({ scale: t, scaleX: e, scaleY: n }) {
  return !ve(t) || !ve(e) || !ve(n);
}
function ut(t) {
  return (
    _e(t) ||
    Gi(t) ||
    t.z ||
    t.rotate ||
    t.rotateX ||
    t.rotateY ||
    t.skewX ||
    t.skewY
  );
}
function Gi(t) {
  return Zn(t.x) || Zn(t.y);
}
function Zn(t) {
  return t && t !== "0%";
}
function ie(t, e, n) {
  const s = t - n,
    i = e * s;
  return n + i;
}
function Jn(t, e, n, s, i) {
  return i !== void 0 && (t = ie(t, i, s)), ie(t, n, s) + e;
}
function Xe(t, e = 0, n = 1, s, i) {
  (t.min = Jn(t.min, e, n, s, i)), (t.max = Jn(t.max, e, n, s, i));
}
function _i(t, { x: e, y: n }) {
  Xe(t.x, e.translate, e.scale, e.originPoint),
    Xe(t.y, n.translate, n.scale, n.originPoint);
}
const Qn = 0.999999999999,
  ts = 1.0000000000001;
function dl(t, e, n, s = !1) {
  const i = n.length;
  if (!i) return;
  e.x = e.y = 1;
  let r, o;
  for (let a = 0; a < i; a++) {
    (r = n[a]), (o = r.projectionDelta);
    const { visualElement: c } = r.options;
    (c && c.props.style && c.props.style.display === "contents") ||
      (s &&
        r.options.layoutScroll &&
        r.scroll &&
        r !== r.root &&
        (J(t.x, -r.scroll.offset.x), J(t.y, -r.scroll.offset.y)),
      o && ((e.x *= o.x.scale), (e.y *= o.y.scale), _i(t, o)),
      s && ut(r.latestValues) && Xt(t, r.latestValues, r.layout?.layoutBox));
  }
  e.x < ts && e.x > Qn && (e.x = 1), e.y < ts && e.y > Qn && (e.y = 1);
}
function J(t, e) {
  (t.min += e), (t.max += e);
}
function es(t, e, n, s, i = 0.5) {
  const r = M(t.min, t.max, i);
  Xe(t, e, n, r, s);
}
function ns(t, e) {
  return typeof t == "string" ? (parseFloat(t) / 100) * (e.max - e.min) : t;
}
function Xt(t, e, n) {
  const s = n ?? t;
  es(t.x, ns(e.x, s.x), e.scaleX, e.scale, e.originX),
    es(t.y, ns(e.y, s.y), e.scaleY, e.scale, e.originY);
}
function Xi(t, e) {
  return zi(fl(t.getBoundingClientRect(), e));
}
function pl(t, e, n) {
  const s = Xi(t, n),
    { scroll: i } = e;
  return i && (J(s.x, i.offset.x), J(s.y, i.offset.y)), s;
}
const ml = {
    x: "translateX",
    y: "translateY",
    z: "translateZ",
    transformPerspective: "perspective",
  },
  gl = St.length;
function yl(t, e, n) {
  let s = "",
    i = !0;
  for (let o = 0; o < gl; o++) {
    const a = St[o],
      c = t[a];
    if (c === void 0) continue;
    let u = !0;
    if (typeof c == "number") u = c === (a.startsWith("scale") ? 1 : 0);
    else {
      const l = parseFloat(c);
      u = a.startsWith("scale") ? l === 1 : l === 0;
    }
    if (!u || n) {
      const l = ze(c, ne[a]);
      if (!u) {
        i = !1;
        const h = ml[a] || a;
        s += `${h}(${l}) `;
      }
      n && (e[a] = l);
    }
  }
  const r = t.pathRotation;
  return (
    r && ((i = !1), (s += `rotate(${ze(r, ne.pathRotation)}) `)),
    (s = s.trim()),
    n ? (s = n(e, i ? "" : s)) : i && (s = "none"),
    s
  );
}
function Pn(t, e, n) {
  const { style: s, vars: i, transformOrigin: r } = t;
  let o = !1,
    a = !1;
  for (const c in e) {
    const u = e[c];
    if (bt.has(c)) {
      o = !0;
      continue;
    } else if (oi(c)) {
      i[c] = u;
      continue;
    } else {
      const l = ze(u, ne[c]);
      c.startsWith("origin") ? ((a = !0), (r[c] = l)) : (s[c] = l);
    }
  }
  if (
    (e.transform ||
      (o || n
        ? (s.transform = yl(e, t.transform, n))
        : s.transform && (s.transform = "none")),
    a)
  ) {
    const { originX: c = "50%", originY: u = "50%", originZ: l = 0 } = r;
    s.transformOrigin = `${c} ${u} ${l}`;
  }
}
function Yi(t, { style: e, vars: n }, s, i) {
  const r = t.style;
  let o;
  for (o in e) r[o] = e[o];
  i?.applyProjectionStyles(r, s);
  for (o in n) r.setProperty(o, n[o]);
}
function ss(t, e) {
  return e.max === e.min ? 0 : (t / (e.max - e.min)) * 100;
}
const At = {
    correct: (t, e) => {
      if (!e.target) return t;
      if (typeof t == "string")
        if (T.test(t)) t = parseFloat(t);
        else return t;
      const n = ss(t, e.target.x),
        s = ss(t, e.target.y);
      return `${n}% ${s}%`;
    },
  },
  vl = {
    correct: (t, { treeScale: e, projectionDelta: n }) => {
      const s = t,
        i = X.parse(t);
      if (i.length > 5) return s;
      const r = X.createTransformer(t),
        o = typeof i[0] != "number" ? 1 : 0,
        a = n.x.scale * e.x,
        c = n.y.scale * e.y;
      (i[0 + o] /= a), (i[1 + o] /= c);
      const u = M(a, c, 0.5);
      return (
        typeof i[2 + o] == "number" && (i[2 + o] /= u),
        typeof i[3 + o] == "number" && (i[3 + o] /= u),
        r(i)
      );
    },
  },
  Ye = {
    borderRadius: {
      ...At,
      applyTo: [
        "borderTopLeftRadius",
        "borderTopRightRadius",
        "borderBottomLeftRadius",
        "borderBottomRightRadius",
      ],
    },
    borderTopLeftRadius: At,
    borderTopRightRadius: At,
    borderBottomLeftRadius: At,
    borderBottomRightRadius: At,
    boxShadow: vl,
  };
function qi(t, { layout: e, layoutId: n }) {
  return (
    bt.has(t) ||
    t.startsWith("origin") ||
    ((e || n !== void 0) && (!!Ye[t] || t === "opacity"))
  );
}
function Sn(t, e, n) {
  const s = t.style,
    i = e?.style,
    r = {};
  if (!s) return r;
  for (const o in s)
    (O(s[o]) ||
      (i && O(i[o])) ||
      qi(o, t) ||
      n?.getValue(o)?.liveStyle !== void 0) &&
      (r[o] = s[o]);
  return r;
}
function xl(t) {
  return window.getComputedStyle(t);
}
class Tl extends Hi {
  constructor() {
    super(...arguments), (this.type = "html"), (this.renderInstance = Yi);
  }
  readValueFromInstance(e, n) {
    if (bt.has(n)) return this.projection?.isProjecting ? Be(n) : Nr(e, n);
    {
      const s = xl(e),
        i = (oi(n) ? s.getPropertyValue(n) : s[n]) || 0;
      return typeof i == "string" ? i.trim() : i;
    }
  }
  measureInstanceViewportBox(e, { transformPagePoint: n }) {
    return Xi(e, n);
  }
  build(e, n, s) {
    Pn(e, n, s.transformTemplate);
  }
  scrapeMotionValuesFromProps(e, n, s) {
    return Sn(e, n, s);
  }
}
const wl = { offset: "stroke-dashoffset", array: "stroke-dasharray" },
  Pl = { offset: "strokeDashoffset", array: "strokeDasharray" };
function Sl(t, e, n = 1, s = 0, i = !0) {
  t.pathLength = 1;
  const r = i ? wl : Pl;
  (t[r.offset] = `${-s}`), (t[r.array] = `${e} ${n}`);
}
const bl = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];
function Zi(
  t,
  {
    attrX: e,
    attrY: n,
    attrScale: s,
    pathLength: i,
    pathSpacing: r = 1,
    pathOffset: o = 0,
    ...a
  },
  c,
  u,
  l
) {
  if ((Pn(t, a, u), c)) {
    t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
    return;
  }
  (t.attrs = t.style), (t.style = {});
  const { attrs: h, style: f } = t;
  h.transform && ((f.transform = h.transform), delete h.transform),
    (f.transform || h.transformOrigin) &&
      ((f.transformOrigin = h.transformOrigin ?? "50% 50%"),
      delete h.transformOrigin),
    f.transform &&
      ((f.transformBox = l?.transformBox ?? "fill-box"), delete h.transformBox);
  for (const d of bl) h[d] !== void 0 && ((f[d] = h[d]), delete h[d]);
  e !== void 0 && (h.x = e),
    n !== void 0 && (h.y = n),
    s !== void 0 && (h.scale = s),
    i !== void 0 && Sl(h, i, r, o, !1);
}
const Ji = new Set([
    "baseFrequency",
    "diffuseConstant",
    "kernelMatrix",
    "kernelUnitLength",
    "keySplines",
    "keyTimes",
    "limitingConeAngle",
    "markerHeight",
    "markerWidth",
    "numOctaves",
    "targetX",
    "targetY",
    "surfaceScale",
    "specularConstant",
    "specularExponent",
    "stdDeviation",
    "tableValues",
    "viewBox",
    "gradientTransform",
    "pathLength",
    "startOffset",
    "textLength",
    "lengthAdjust",
  ]),
  Qi = (t) => typeof t == "string" && t.toLowerCase() === "svg";
function Al(t, e, n, s) {
  Yi(t, e, void 0, s);
  for (const i in e.attrs) t.setAttribute(Ji.has(i) ? i : gn(i), e.attrs[i]);
}
function to(t, e, n) {
  const s = Sn(t, e, n);
  for (const i in t)
    if (O(t[i]) || O(e[i])) {
      const r =
        St.indexOf(i) !== -1
          ? "attr" + i.charAt(0).toUpperCase() + i.substring(1)
          : i;
      s[r] = t[i];
    }
  return s;
}
class Vl extends Hi {
  constructor() {
    super(...arguments),
      (this.type = "svg"),
      (this.isSVGTag = !1),
      (this.measureInstanceViewportBox = B);
  }
  getBaseTargetFromProps(e, n) {
    return e[n];
  }
  readValueFromInstance(e, n) {
    if (bt.has(n)) {
      const s = Bi(n);
      return (s && s.default) || 0;
    }
    return (n = Ji.has(n) ? n : gn(n)), e.getAttribute(n);
  }
  scrapeMotionValuesFromProps(e, n, s) {
    return to(e, n, s);
  }
  build(e, n, s) {
    Zi(e, n, this.isSVGTag, s.transformTemplate, s.style);
  }
  renderInstance(e, n, s, i) {
    Al(e, n, s, i);
  }
  mount(e) {
    (this.isSVGTag = Qi(e.tagName)), super.mount(e);
  }
}
const Cl = wn.length;
function eo(t) {
  if (!t) return;
  if (!t.isControllingVariants) {
    const n = t.parent ? eo(t.parent) || {} : {};
    return t.props.initial !== void 0 && (n.initial = t.props.initial), n;
  }
  const e = {};
  for (let n = 0; n < Cl; n++) {
    const s = wn[n],
      i = t.props[s];
    (kt(i) || i === !1) && (e[s] = i);
  }
  return e;
}
function no(t, e) {
  if (!Array.isArray(e)) return !1;
  const n = e.length;
  if (n !== t.length) return !1;
  for (let s = 0; s < n; s++) if (e[s] !== t[s]) return !1;
  return !0;
}
const Ml = [...Tn].reverse(),
  Dl = Tn.length;
function El(t) {
  return (e) =>
    Promise.all(e.map(({ animation: n, options: s }) => Va(t, n, s)));
}
function Rl(t) {
  let e = El(t),
    n = is(),
    s = !0,
    i = !1;
  const r = (u) => (l, h) => {
    const f = pt(t, h, u === "exit" ? t.presenceContext?.custom : void 0);
    if (f) {
      const { transition: d, transitionEnd: p, ...m } = f;
      l = { ...l, ...m, ...p };
    }
    return l;
  };
  function o(u) {
    e = u(t);
  }
  function a(u) {
    const { props: l } = t,
      h = eo(t.parent) || {},
      f = [],
      d = new Set();
    let p = {},
      m = 1 / 0;
    for (let y = 0; y < Dl; y++) {
      const v = Ml[y],
        x = n[v],
        w = l[v] !== void 0 ? l[v] : h[v],
        A = kt(w),
        E = v === u ? x.isActive : null;
      E === !1 && (m = y);
      let V = w === h[v] && w !== l[v] && A;
      if (
        (V && (s || i) && t.manuallyAnimateOnMount && (V = !1),
        (x.protectedKeys = { ...p }),
        (!x.isActive && E === null) ||
          (!w && !x.prevProp) ||
          le(w) ||
          typeof w == "boolean")
      )
        continue;
      if (v === "exit" && x.isActive && E !== !0) {
        x.prevResolvedValues && (p = { ...p, ...x.prevResolvedValues });
        continue;
      }
      const b = Ll(x.prevProp, w);
      let F = b || (v === u && x.isActive && !V && A) || (y > m && A),
        S = !1;
      const L = Array.isArray(w) ? w : [w];
      let W = L.reduce(r(v), {});
      E === !1 && (W = {});
      const { prevResolvedValues: at = {} } = x,
        Y = { ...at, ...W },
        et = (I) => {
          (F = !0),
            d.has(I) && ((S = !0), d.delete(I)),
            (x.needsAnimating[I] = !0);
          const $ = t.getValue(I);
          $ && ($.liveStyle = !1);
        };
      for (const I in Y) {
        const $ = W[I],
          lt = at[I];
        if (p.hasOwnProperty(I)) continue;
        let mt = !1;
        Ue($) && Ue(lt) ? (mt = !no($, lt) || b) : (mt = $ !== lt),
          mt
            ? $ != null
              ? et(I)
              : d.add(I)
            : $ !== void 0 && d.has(I)
            ? et(I)
            : (x.protectedKeys[I] = !0);
      }
      (x.prevProp = w),
        (x.prevResolvedValues = W),
        x.isActive && (p = { ...p, ...W }),
        (s || i) && t.blockInitialAnimation && (F = !1);
      const q = V && b;
      F &&
        (!q || S) &&
        f.push(
          ...L.map((I) => {
            const $ = { type: v };
            if (
              typeof I == "string" &&
              (s || i) &&
              !q &&
              t.manuallyAnimateOnMount &&
              t.parent
            ) {
              const { parent: lt } = t,
                mt = pt(lt, I);
              if (lt.enteringChildren && mt) {
                const { delayChildren: Co } = mt.transition || {};
                $.delay = Ai(lt.enteringChildren, t, Co);
              }
            }
            return { animation: I, options: $ };
          })
        );
    }
    if (d.size) {
      const y = {};
      if (typeof l.initial != "boolean") {
        const v = pt(t, Array.isArray(l.initial) ? l.initial[0] : l.initial);
        v && v.transition && (y.transition = v.transition);
      }
      d.forEach((v) => {
        const x = t.getBaseTarget(v),
          w = t.getValue(v);
        w && (w.liveStyle = !0), (y[v] = x ?? null);
      }),
        f.push({ animation: y });
    }
    let g = !!f.length;
    return (
      s &&
        (l.initial === !1 || l.initial === l.animate) &&
        !t.manuallyAnimateOnMount &&
        (g = !1),
      (s = !1),
      (i = !1),
      g ? e(f) : Promise.resolve()
    );
  }
  function c(u, l) {
    if (n[u].isActive === l) return Promise.resolve();
    t.variantChildren?.forEach((f) => f.animationState?.setActive(u, l)),
      (n[u].isActive = l);
    const h = a(u);
    for (const f in n) n[f].protectedKeys = {};
    return h;
  }
  return {
    animateChanges: a,
    setActive: c,
    setAnimateFunction: o,
    getState: () => n,
    reset: () => {
      (n = is()), (i = !0);
    },
  };
}
function Ll(t, e) {
  return typeof e == "string" ? e !== t : Array.isArray(e) ? !no(e, t) : !1;
}
function ct(t = !1) {
  return {
    isActive: t,
    protectedKeys: {},
    needsAnimating: {},
    prevResolvedValues: {},
  };
}
function is() {
  return {
    animate: ct(!0),
    whileInView: ct(),
    whileHover: ct(),
    whileTap: ct(),
    whileDrag: ct(),
    whileFocus: ct(),
    exit: ct(),
  };
}
function qe(t, e) {
  (t.min = e.min), (t.max = e.max);
}
function G(t, e) {
  qe(t.x, e.x), qe(t.y, e.y);
}
function os(t, e) {
  (t.translate = e.translate),
    (t.scale = e.scale),
    (t.originPoint = e.originPoint),
    (t.origin = e.origin);
}
const so = 1e-4,
  kl = 1 - so,
  Bl = 1 + so,
  io = 0.01,
  Fl = 0 - io,
  Il = 0 + io;
function U(t) {
  return t.max - t.min;
}
function jl(t, e, n) {
  return Math.abs(t - e) <= n;
}
function rs(t, e, n, s = 0.5) {
  (t.origin = s),
    (t.originPoint = M(e.min, e.max, t.origin)),
    (t.scale = U(n) / U(e)),
    (t.translate = M(n.min, n.max, t.origin) - t.originPoint),
    ((t.scale >= kl && t.scale <= Bl) || isNaN(t.scale)) && (t.scale = 1),
    ((t.translate >= Fl && t.translate <= Il) || isNaN(t.translate)) &&
      (t.translate = 0);
}
function Dt(t, e, n, s) {
  rs(t.x, e.x, n.x, s ? s.originX : void 0),
    rs(t.y, e.y, n.y, s ? s.originY : void 0);
}
function as(t, e, n, s = 0) {
  const i = s ? M(n.min, n.max, s) : n.min;
  (t.min = i + e.min), (t.max = t.min + U(e));
}
function Ol(t, e, n, s) {
  as(t.x, e.x, n.x, s?.x), as(t.y, e.y, n.y, s?.y);
}
function ls(t, e, n, s = 0) {
  const i = s ? M(n.min, n.max, s) : n.min;
  (t.min = e.min - i), (t.max = t.min + U(e));
}
function oe(t, e, n, s) {
  ls(t.x, e.x, n.x, s?.x), ls(t.y, e.y, n.y, s?.y);
}
function cs(t, e, n, s, i) {
  return (
    (t -= e), (t = ie(t, 1 / n, s)), i !== void 0 && (t = ie(t, 1 / i, s)), t
  );
}
function Nl(t, e = 0, n = 1, s = 0.5, i, r = t, o = t) {
  if (
    (Q.test(e) && ((e = parseFloat(e)), (e = M(o.min, o.max, e / 100) - o.min)),
    typeof e != "number")
  )
    return;
  let a = M(r.min, r.max, s);
  t === r && (a -= e),
    (t.min = cs(t.min, e, n, a, i)),
    (t.max = cs(t.max, e, n, a, i));
}
function us(t, e, [n, s, i], r, o) {
  Nl(t, e[n], e[s], e[i], e.scale, r, o);
}
const Ul = ["x", "scaleX", "originX"],
  Wl = ["y", "scaleY", "originY"];
function hs(t, e, n, s) {
  us(t.x, e, Ul, n ? n.x : void 0, s ? s.x : void 0),
    us(t.y, e, Wl, n ? n.y : void 0, s ? s.y : void 0);
}
function fs(t) {
  return t.translate === 0 && t.scale === 1;
}
function oo(t) {
  return fs(t.x) && fs(t.y);
}
function ds(t, e) {
  return t.min === e.min && t.max === e.max;
}
function Kl(t, e) {
  return ds(t.x, e.x) && ds(t.y, e.y);
}
function ps(t, e) {
  return (
    Math.round(t.min) === Math.round(e.min) &&
    Math.round(t.max) === Math.round(e.max)
  );
}
function ro(t, e) {
  return ps(t.x, e.x) && ps(t.y, e.y);
}
function ms(t) {
  return U(t.x) / U(t.y);
}
function gs(t, e) {
  return (
    t.translate === e.translate &&
    t.scale === e.scale &&
    t.originPoint === e.originPoint
  );
}
function Z(t) {
  return [t("x"), t("y")];
}
function $l(t, e, n) {
  let s = "";
  const i = t.x.translate / e.x,
    r = t.y.translate / e.y,
    o = n?.z || 0;
  if (
    ((i || r || o) && (s = `translate3d(${i}px, ${r}px, ${o}px) `),
    (e.x !== 1 || e.y !== 1) && (s += `scale(${1 / e.x}, ${1 / e.y}) `),
    n)
  ) {
    const {
      transformPerspective: u,
      rotate: l,
      pathRotation: h,
      rotateX: f,
      rotateY: d,
      skewX: p,
      skewY: m,
    } = n;
    u && (s = `perspective(${u}px) ${s}`),
      l && (s += `rotate(${l}deg) `),
      h && (s += `rotate(${h}deg) `),
      f && (s += `rotateX(${f}deg) `),
      d && (s += `rotateY(${d}deg) `),
      p && (s += `skewX(${p}deg) `),
      m && (s += `skewY(${m}deg) `);
  }
  const a = t.x.scale * e.x,
    c = t.y.scale * e.y;
  return (a !== 1 || c !== 1) && (s += `scale(${a}, ${c})`), s || "none";
}
const ao = [
    "borderTopLeftRadius",
    "borderTopRightRadius",
    "borderBottomLeftRadius",
    "borderBottomRightRadius",
  ],
  Hl = ao.length,
  ys = (t) => (typeof t == "string" ? parseFloat(t) : t),
  vs = (t) => typeof t == "number" || T.test(t);
function zl(t, e, n, s, i, r) {
  i
    ? ((t.opacity = M(0, n.opacity ?? 1, Gl(s))),
      (t.opacityExit = M(e.opacity ?? 1, 0, _l(s))))
    : r && (t.opacity = M(e.opacity ?? 1, n.opacity ?? 1, s));
  for (let o = 0; o < Hl; o++) {
    const a = ao[o];
    let c = xs(e, a),
      u = xs(n, a);
    if (c === void 0 && u === void 0) continue;
    c || (c = 0),
      u || (u = 0),
      c === 0 || u === 0 || vs(c) === vs(u)
        ? ((t[a] = Math.max(M(ys(c), ys(u), s), 0)),
          (Q.test(u) || Q.test(c)) && (t[a] += "%"))
        : (t[a] = u);
  }
  (e.rotate || n.rotate) && (t.rotate = M(e.rotate || 0, n.rotate || 0, s));
}
function xs(t, e) {
  return t[e] !== void 0 ? t[e] : t.borderRadius;
}
const Gl = lo(0, 0.5, Qs),
  _l = lo(0.5, 0.95, z);
function lo(t, e, n) {
  return (s) => (s < t ? 0 : s > e ? 1 : n(Rt(t, e, s)));
}
function Xl(t, e, n) {
  const s = O(t) ? t : wt(t);
  return s.start(pn("", s, e, n)), s.animation;
}
function Bt(t, e, n, s = { passive: !0 }) {
  return t.addEventListener(e, n, s), () => t.removeEventListener(e, n);
}
const Yl = (t, e) => t.depth - e.depth;
class ql {
  constructor() {
    (this.children = []), (this.isDirty = !1);
  }
  add(e) {
    tn(this.children, e), (this.isDirty = !0);
  }
  remove(e) {
    Zt(this.children, e), (this.isDirty = !0);
  }
  forEach(e) {
    this.isDirty && this.children.sort(Yl),
      (this.isDirty = !1),
      this.children.forEach(e);
  }
}
function Zl(t, e) {
  const n = N.now(),
    s = ({ timestamp: i }) => {
      const r = i - n;
      r >= e && (ot(s), t(r - e));
    };
  return D.setup(s, !0), () => ot(s);
}
function Yt(t) {
  return O(t) ? t.get() : t;
}
class Jl {
  constructor() {
    this.members = [];
  }
  add(e) {
    tn(this.members, e);
    for (let n = this.members.length - 1; n >= 0; n--) {
      const s = this.members[n];
      if (s === e || s === this.lead || s === this.prevLead) continue;
      const i = s.instance;
      (!i || i.isConnected === !1) &&
        !s.snapshot &&
        (Zt(this.members, s), s.unmount());
    }
    e.scheduleRender();
  }
  remove(e) {
    if (
      (Zt(this.members, e),
      e === this.prevLead && (this.prevLead = void 0),
      e === this.lead)
    ) {
      const n = this.members[this.members.length - 1];
      n && this.promote(n);
    }
  }
  relegate(e) {
    for (let n = this.members.indexOf(e) - 1; n >= 0; n--) {
      const s = this.members[n];
      if (s.isPresent !== !1 && s.instance?.isConnected !== !1)
        return this.promote(s), !0;
    }
    return !1;
  }
  promote(e, n) {
    const s = this.lead;
    if (e !== s && ((this.prevLead = s), (this.lead = e), e.show(), s)) {
      s.updateSnapshot(), e.scheduleRender();
      const { layoutDependency: i } = s.options,
        { layoutDependency: r } = e.options;
      (i === void 0 || i !== r) &&
        ((e.resumeFrom = s),
        n && (s.preserveOpacity = !0),
        s.snapshot &&
          ((e.snapshot = s.snapshot),
          (e.snapshot.latestValues = s.animationValues || s.latestValues)),
        e.root?.isUpdating && (e.isLayoutDirty = !0)),
        e.options.crossfade === !1 && s.hide();
    }
  }
  exitAnimationComplete() {
    this.members.forEach((e) => {
      e.options.onExitComplete?.(), e.resumingFrom?.options.onExitComplete?.();
    });
  }
  scheduleRender() {
    this.members.forEach((e) => e.instance && e.scheduleRender(!1));
  }
  removeLeadSnapshot() {
    this.lead?.snapshot && (this.lead.snapshot = void 0);
  }
}
const qt = { hasAnimatedSinceResize: !0, hasEverUpdated: !1 },
  xe = ["", "X", "Y", "Z"],
  Ql = 1e3;
let tc = 0;
function Te(t, e, n, s) {
  const { latestValues: i } = e;
  i[t] && ((n[t] = i[t]), e.setStaticValue(t, 0), s && (s[t] = 0));
}
function co(t) {
  if (((t.hasCheckedOptimisedAppear = !0), t.root === t)) return;
  const { visualElement: e } = t.options;
  if (!e) return;
  const n = Ei(e);
  if (window.MotionHasOptimisedAnimation(n, "transform")) {
    const { layout: i, layoutId: r } = t.options;
    window.MotionCancelOptimisedAnimation(n, "transform", D, !(i || r));
  }
  const { parent: s } = t;
  s && !s.hasCheckedOptimisedAppear && co(s);
}
function uo({
  attachResizeListener: t,
  defaultParent: e,
  measureScroll: n,
  checkIsScrollRoot: s,
  resetTransform: i,
}) {
  return class {
    constructor(o = {}, a = e?.()) {
      (this.id = tc++),
        (this.animationId = 0),
        (this.animationCommitId = 0),
        (this.children = new Set()),
        (this.options = {}),
        (this.isTreeAnimating = !1),
        (this.isAnimationBlocked = !1),
        (this.isLayoutDirty = !1),
        (this.isProjectionDirty = !1),
        (this.isSharedProjectionDirty = !1),
        (this.isTransformDirty = !1),
        (this.updateManuallyBlocked = !1),
        (this.updateBlockedByResize = !1),
        (this.isUpdating = !1),
        (this.isSVG = !1),
        (this.needsReset = !1),
        (this.shouldResetTransform = !1),
        (this.hasCheckedOptimisedAppear = !1),
        (this.treeScale = { x: 1, y: 1 }),
        (this.eventHandlers = new Map()),
        (this.hasTreeAnimated = !1),
        (this.layoutVersion = 0),
        (this.updateScheduled = !1),
        (this.scheduleUpdate = () => this.update()),
        (this.projectionUpdateScheduled = !1),
        (this.checkUpdateFailed = () => {
          this.isUpdating && ((this.isUpdating = !1), this.clearAllSnapshots());
        }),
        (this.updateProjection = () => {
          (this.projectionUpdateScheduled = !1),
            this.nodes.forEach(sc),
            this.nodes.forEach(cc),
            this.nodes.forEach(uc),
            this.nodes.forEach(ic);
        }),
        (this.resolvedRelativeTargetAt = 0),
        (this.linkedParentVersion = 0),
        (this.hasProjected = !1),
        (this.isVisible = !0),
        (this.animationProgress = 0),
        (this.sharedNodes = new Map()),
        (this.latestValues = o),
        (this.root = a ? a.root || a : this),
        (this.path = a ? [...a.path, a] : []),
        (this.parent = a),
        (this.depth = a ? a.depth + 1 : 0);
      for (let c = 0; c < this.path.length; c++)
        this.path[c].shouldResetTransform = !0;
      this.root === this && (this.nodes = new ql());
    }
    addEventListener(o, a) {
      return (
        this.eventHandlers.has(o) || this.eventHandlers.set(o, new nn()),
        this.eventHandlers.get(o).add(a)
      );
    }
    notifyListeners(o, ...a) {
      const c = this.eventHandlers.get(o);
      c && c.notify(...a);
    }
    hasListeners(o) {
      return this.eventHandlers.has(o);
    }
    mount(o) {
      if (this.instance) return;
      (this.isSVG = xn(o) && !nl(o)), (this.instance = o);
      const { layoutId: a, layout: c, visualElement: u } = this.options;
      if (
        (u && !u.current && u.mount(o),
        this.root.nodes.add(this),
        this.parent && this.parent.children.add(this),
        this.root.hasTreeAnimated && (c || a) && (this.isLayoutDirty = !0),
        t)
      ) {
        let l,
          h = 0;
        const f = () => (this.root.updateBlockedByResize = !1);
        D.read(() => {
          h = window.innerWidth;
        }),
          t(o, () => {
            const d = window.innerWidth;
            d !== h &&
              ((h = d),
              (this.root.updateBlockedByResize = !0),
              l && l(),
              (l = Zl(f, 250)),
              qt.hasAnimatedSinceResize &&
                ((qt.hasAnimatedSinceResize = !1), this.nodes.forEach(Ps)));
          });
      }
      a && this.root.registerSharedNode(a, this),
        this.options.animate !== !1 &&
          u &&
          (a || c) &&
          this.addEventListener(
            "didUpdate",
            ({
              delta: l,
              hasLayoutChanged: h,
              hasRelativeLayoutChanged: f,
              layout: d,
            }) => {
              if (this.isTreeAnimationBlocked()) {
                (this.target = void 0), (this.relativeTarget = void 0);
                return;
              }
              const p =
                  this.options.transition || u.getDefaultTransition() || mc,
                { onLayoutAnimationStart: m, onLayoutAnimationComplete: g } =
                  u.getProps(),
                y = !this.targetLayout || !ro(this.targetLayout, d),
                v = !h && f;
              if (
                this.options.layoutRoot ||
                this.resumeFrom ||
                v ||
                (h && (y || !this.currentAnimation))
              ) {
                this.resumeFrom &&
                  ((this.resumingFrom = this.resumeFrom),
                  (this.resumingFrom.resumingFrom = void 0));
                const x = { ...dn(p, "layout"), onPlay: m, onComplete: g };
                (u.shouldReduceMotion || this.options.layoutRoot) &&
                  ((x.delay = 0), (x.type = !1)),
                  this.startAnimation(x),
                  this.setAnimationOrigin(l, v, x.path);
              } else
                h || Ps(this),
                  this.isLead() &&
                    this.options.onExitComplete &&
                    this.options.onExitComplete();
              this.targetLayout = d;
            }
          );
    }
    unmount() {
      this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
      const o = this.getStack();
      o && o.remove(this),
        this.parent && this.parent.children.delete(this),
        (this.instance = void 0),
        this.eventHandlers.clear(),
        ot(this.updateProjection);
    }
    blockUpdate() {
      this.updateManuallyBlocked = !0;
    }
    unblockUpdate() {
      this.updateManuallyBlocked = !1;
    }
    isUpdateBlocked() {
      return this.updateManuallyBlocked || this.updateBlockedByResize;
    }
    isTreeAnimationBlocked() {
      return (
        this.isAnimationBlocked ||
        (this.parent && this.parent.isTreeAnimationBlocked()) ||
        !1
      );
    }
    startUpdate() {
      this.isUpdateBlocked() ||
        ((this.isUpdating = !0),
        this.nodes && this.nodes.forEach(hc),
        this.animationId++);
    }
    getTransformTemplate() {
      const { visualElement: o } = this.options;
      return o && o.getProps().transformTemplate;
    }
    willUpdate(o = !0) {
      if (((this.root.hasTreeAnimated = !0), this.root.isUpdateBlocked())) {
        this.options.onExitComplete && this.options.onExitComplete();
        return;
      }
      if (
        (window.MotionCancelOptimisedAnimation &&
          !this.hasCheckedOptimisedAppear &&
          co(this),
        !this.root.isUpdating && this.root.startUpdate(),
        this.isLayoutDirty)
      )
        return;
      this.isLayoutDirty = !0;
      for (let l = 0; l < this.path.length; l++) {
        const h = this.path[l];
        (h.shouldResetTransform = !0),
          (typeof h.latestValues.x == "string" ||
            typeof h.latestValues.y == "string") &&
            (h.isLayoutDirty = !0),
          h.updateScroll("snapshot"),
          h.options.layoutRoot && h.willUpdate(!1);
      }
      const { layoutId: a, layout: c } = this.options;
      if (a === void 0 && !c) return;
      const u = this.getTransformTemplate();
      (this.prevTransformTemplateValue = u ? u(this.latestValues, "") : void 0),
        this.updateSnapshot(),
        o && this.notifyListeners("willUpdate");
    }
    update() {
      if (((this.updateScheduled = !1), this.isUpdateBlocked())) {
        const c = this.updateBlockedByResize;
        this.unblockUpdate(),
          (this.updateBlockedByResize = !1),
          this.clearAllSnapshots(),
          c && this.nodes.forEach(rc),
          this.nodes.forEach(Ts);
        return;
      }
      if (this.animationId <= this.animationCommitId) {
        this.nodes.forEach(ws);
        return;
      }
      (this.animationCommitId = this.animationId),
        this.isUpdating
          ? ((this.isUpdating = !1),
            this.nodes.forEach(ac),
            this.nodes.forEach(lc),
            this.nodes.forEach(ec),
            this.nodes.forEach(nc))
          : this.nodes.forEach(ws),
        this.clearAllSnapshots();
      const a = N.now();
      (j.delta = tt(0, 1e3 / 60, a - j.timestamp)),
        (j.timestamp = a),
        (j.isProcessing = !0),
        he.update.process(j),
        he.preRender.process(j),
        he.render.process(j),
        (j.isProcessing = !1);
    }
    didUpdate() {
      this.updateScheduled ||
        ((this.updateScheduled = !0), yn.read(this.scheduleUpdate));
    }
    clearAllSnapshots() {
      this.nodes.forEach(oc), this.sharedNodes.forEach(fc);
    }
    scheduleUpdateProjection() {
      this.projectionUpdateScheduled ||
        ((this.projectionUpdateScheduled = !0),
        D.preRender(this.updateProjection, !1, !0));
    }
    scheduleCheckAfterUnmount() {
      D.postRender(() => {
        this.isLayoutDirty
          ? this.root.didUpdate()
          : this.root.checkUpdateFailed();
      });
    }
    updateSnapshot() {
      this.snapshot ||
        !this.instance ||
        ((this.snapshot = this.measure()),
        this.snapshot &&
          !U(this.snapshot.measuredBox.x) &&
          !U(this.snapshot.measuredBox.y) &&
          (this.snapshot = void 0));
    }
    updateLayout() {
      if (
        !this.instance ||
        (this.updateScroll(),
        !(this.options.alwaysMeasureLayout && this.isLead()) &&
          !this.isLayoutDirty)
      )
        return;
      if (this.resumeFrom && !this.resumeFrom.instance)
        for (let c = 0; c < this.path.length; c++) this.path[c].updateScroll();
      const o = this.layout;
      (this.layout = this.measure(!1)),
        this.layoutVersion++,
        this.layoutCorrected || (this.layoutCorrected = B()),
        (this.isLayoutDirty = !1),
        (this.projectionDelta = void 0),
        this.notifyListeners("measure", this.layout.layoutBox);
      const { visualElement: a } = this.options;
      a &&
        a.notify(
          "LayoutMeasure",
          this.layout.layoutBox,
          o ? o.layoutBox : void 0
        );
    }
    updateScroll(o = "measure") {
      let a = !!(this.options.layoutScroll && this.instance);
      if (
        (this.scroll &&
          this.scroll.animationId === this.root.animationId &&
          this.scroll.phase === o &&
          (a = !1),
        a && this.instance)
      ) {
        const c = s(this.instance);
        this.scroll = {
          animationId: this.root.animationId,
          phase: o,
          isRoot: c,
          offset: n(this.instance),
          wasRoot: this.scroll ? this.scroll.isRoot : c,
        };
      }
    }
    resetTransform() {
      if (!i) return;
      const o =
          this.isLayoutDirty ||
          this.shouldResetTransform ||
          this.options.alwaysMeasureLayout,
        a = this.projectionDelta && !oo(this.projectionDelta),
        c = this.getTransformTemplate(),
        u = c ? c(this.latestValues, "") : void 0,
        l = u !== this.prevTransformTemplateValue;
      o &&
        this.instance &&
        (a || ut(this.latestValues) || l) &&
        (i(this.instance, u),
        (this.shouldResetTransform = !1),
        this.scheduleRender());
    }
    measure(o = !0) {
      const a = this.measurePageBox();
      let c = this.removeElementScroll(a);
      return (
        o && (c = this.removeTransform(c)),
        gc(c),
        {
          animationId: this.root.animationId,
          measuredBox: a,
          layoutBox: c,
          latestValues: {},
          source: this.id,
        }
      );
    }
    measurePageBox() {
      const { visualElement: o } = this.options;
      if (!o) return B();
      const a = o.measureViewportBox();
      if (!(this.scroll?.wasRoot || this.path.some(yc))) {
        const { scroll: u } = this.root;
        u && (J(a.x, u.offset.x), J(a.y, u.offset.y));
      }
      return a;
    }
    removeElementScroll(o) {
      const a = B();
      if ((G(a, o), this.scroll?.wasRoot)) return a;
      for (let c = 0; c < this.path.length; c++) {
        const u = this.path[c],
          { scroll: l, options: h } = u;
        u !== this.root &&
          l &&
          h.layoutScroll &&
          (l.wasRoot && G(a, o), J(a.x, l.offset.x), J(a.y, l.offset.y));
      }
      return a;
    }
    applyTransform(o, a = !1, c) {
      const u = c || B();
      G(u, o);
      for (let l = 0; l < this.path.length; l++) {
        const h = this.path[l];
        !a &&
          h.options.layoutScroll &&
          h.scroll &&
          h !== h.root &&
          (J(u.x, -h.scroll.offset.x), J(u.y, -h.scroll.offset.y)),
          ut(h.latestValues) && Xt(u, h.latestValues, h.layout?.layoutBox);
      }
      return (
        ut(this.latestValues) &&
          Xt(u, this.latestValues, this.layout?.layoutBox),
        u
      );
    }
    removeTransform(o) {
      const a = B();
      G(a, o);
      for (let c = 0; c < this.path.length; c++) {
        const u = this.path[c];
        if (!ut(u.latestValues)) continue;
        let l;
        u.instance &&
          (_e(u.latestValues) && u.updateSnapshot(),
          (l = B()),
          G(l, u.measurePageBox())),
          hs(a, u.latestValues, u.snapshot?.layoutBox, l);
      }
      return ut(this.latestValues) && hs(a, this.latestValues), a;
    }
    setTargetDelta(o) {
      (this.targetDelta = o),
        this.root.scheduleUpdateProjection(),
        (this.isProjectionDirty = !0);
    }
    setOptions(o) {
      this.options = {
        ...this.options,
        ...o,
        crossfade: o.crossfade !== void 0 ? o.crossfade : !0,
      };
    }
    clearMeasurements() {
      (this.scroll = void 0),
        (this.layout = void 0),
        (this.snapshot = void 0),
        (this.prevTransformTemplateValue = void 0),
        (this.targetDelta = void 0),
        (this.target = void 0),
        (this.isLayoutDirty = !1);
    }
    forceRelativeParentToResolveTarget() {
      this.relativeParent &&
        this.relativeParent.resolvedRelativeTargetAt !== j.timestamp &&
        this.relativeParent.resolveTargetDelta(!0);
    }
    resolveTargetDelta(o = !1) {
      const a = this.getLead();
      this.isProjectionDirty || (this.isProjectionDirty = a.isProjectionDirty),
        this.isTransformDirty || (this.isTransformDirty = a.isTransformDirty),
        this.isSharedProjectionDirty ||
          (this.isSharedProjectionDirty = a.isSharedProjectionDirty);
      const c = !!this.resumingFrom || this !== a;
      if (
        !(
          o ||
          (c && this.isSharedProjectionDirty) ||
          this.isProjectionDirty ||
          this.parent?.isProjectionDirty ||
          this.attemptToResolveRelativeTarget ||
          this.root.updateBlockedByResize
        )
      )
        return;
      const { layout: l, layoutId: h } = this.options;
      if (!this.layout || !(l || h)) return;
      this.resolvedRelativeTargetAt = j.timestamp;
      const f = this.getClosestProjectingParent();
      f &&
        this.linkedParentVersion !== f.layoutVersion &&
        !f.options.layoutRoot &&
        this.removeRelativeTarget(),
        !this.targetDelta &&
          !this.relativeTarget &&
          (this.options.layoutAnchor !== !1 && f && f.layout
            ? this.createRelativeTarget(
                f,
                this.layout.layoutBox,
                f.layout.layoutBox
              )
            : this.removeRelativeTarget()),
        !(!this.relativeTarget && !this.targetDelta) &&
          (this.target ||
            ((this.target = B()), (this.targetWithTransforms = B())),
          this.relativeTarget &&
          this.relativeTargetOrigin &&
          this.relativeParent &&
          this.relativeParent.target
            ? (this.forceRelativeParentToResolveTarget(),
              Ol(
                this.target,
                this.relativeTarget,
                this.relativeParent.target,
                this.options.layoutAnchor || void 0
              ))
            : this.targetDelta
            ? (this.resumingFrom
                ? this.applyTransform(this.layout.layoutBox, !1, this.target)
                : G(this.target, this.layout.layoutBox),
              _i(this.target, this.targetDelta))
            : G(this.target, this.layout.layoutBox),
          this.attemptToResolveRelativeTarget &&
            ((this.attemptToResolveRelativeTarget = !1),
            this.options.layoutAnchor !== !1 &&
            f &&
            !!f.resumingFrom == !!this.resumingFrom &&
            !f.options.layoutScroll &&
            f.target &&
            this.animationProgress !== 1
              ? this.createRelativeTarget(f, this.target, f.target)
              : (this.relativeParent = this.relativeTarget = void 0)));
    }
    getClosestProjectingParent() {
      if (
        !(
          !this.parent ||
          _e(this.parent.latestValues) ||
          Gi(this.parent.latestValues)
        )
      )
        return this.parent.isProjecting()
          ? this.parent
          : this.parent.getClosestProjectingParent();
    }
    isProjecting() {
      return !!(
        (this.relativeTarget || this.targetDelta || this.options.layoutRoot) &&
        this.layout
      );
    }
    createRelativeTarget(o, a, c) {
      (this.relativeParent = o),
        (this.linkedParentVersion = o.layoutVersion),
        this.forceRelativeParentToResolveTarget(),
        (this.relativeTarget = B()),
        (this.relativeTargetOrigin = B()),
        oe(
          this.relativeTargetOrigin,
          a,
          c,
          this.options.layoutAnchor || void 0
        ),
        G(this.relativeTarget, this.relativeTargetOrigin);
    }
    removeRelativeTarget() {
      this.relativeParent = this.relativeTarget = void 0;
    }
    calcProjection() {
      const o = this.getLead(),
        a = !!this.resumingFrom || this !== o;
      let c = !0;
      if (
        ((this.isProjectionDirty || this.parent?.isProjectionDirty) && (c = !1),
        a &&
          (this.isSharedProjectionDirty || this.isTransformDirty) &&
          (c = !1),
        this.resolvedRelativeTargetAt === j.timestamp && (c = !1),
        c)
      )
        return;
      const { layout: u, layoutId: l } = this.options;
      if (
        ((this.isTreeAnimating = !!(
          (this.parent && this.parent.isTreeAnimating) ||
          this.currentAnimation ||
          this.pendingAnimation
        )),
        this.isTreeAnimating ||
          (this.targetDelta = this.relativeTarget = void 0),
        !this.layout || !(u || l))
      )
        return;
      G(this.layoutCorrected, this.layout.layoutBox);
      const h = this.treeScale.x,
        f = this.treeScale.y;
      dl(this.layoutCorrected, this.treeScale, this.path, a),
        o.layout &&
          !o.target &&
          (this.treeScale.x !== 1 || this.treeScale.y !== 1) &&
          ((o.target = o.layout.layoutBox), (o.targetWithTransforms = B()));
      const { target: d } = o;
      if (!d) {
        this.prevProjectionDelta &&
          (this.createProjectionDeltas(), this.scheduleRender());
        return;
      }
      !this.projectionDelta || !this.prevProjectionDelta
        ? this.createProjectionDeltas()
        : (os(this.prevProjectionDelta.x, this.projectionDelta.x),
          os(this.prevProjectionDelta.y, this.projectionDelta.y)),
        Dt(this.projectionDelta, this.layoutCorrected, d, this.latestValues),
        (this.treeScale.x !== h ||
          this.treeScale.y !== f ||
          !gs(this.projectionDelta.x, this.prevProjectionDelta.x) ||
          !gs(this.projectionDelta.y, this.prevProjectionDelta.y)) &&
          ((this.hasProjected = !0),
          this.scheduleRender(),
          this.notifyListeners("projectionUpdate", d));
    }
    hide() {
      this.isVisible = !1;
    }
    show() {
      this.isVisible = !0;
    }
    scheduleRender(o = !0) {
      if ((this.options.visualElement?.scheduleRender(), o)) {
        const a = this.getStack();
        a && a.scheduleRender();
      }
      this.resumingFrom &&
        !this.resumingFrom.instance &&
        (this.resumingFrom = void 0);
    }
    createProjectionDeltas() {
      (this.prevProjectionDelta = xt()),
        (this.projectionDelta = xt()),
        (this.projectionDeltaWithTransform = xt());
    }
    setAnimationOrigin(o, a = !1, c) {
      const u = this.snapshot,
        l = u ? u.latestValues : {},
        h = { ...this.latestValues },
        f = xt();
      (!this.relativeParent || !this.relativeParent.options.layoutRoot) &&
        (this.relativeTarget = this.relativeTargetOrigin = void 0),
        (this.attemptToResolveRelativeTarget = !a);
      const d = B(),
        p = u ? u.source : void 0,
        m = this.layout ? this.layout.source : void 0,
        g = p !== m,
        y = this.getStack(),
        v = !y || y.members.length <= 1,
        x = !!(g && !v && this.options.crossfade === !0 && !this.path.some(pc));
      this.animationProgress = 0;
      let w;
      const A = c?.interpolateProjection(o);
      (this.mixTargetDelta = (E) => {
        const V = E / 1e3,
          b = A?.(V);
        b
          ? ((f.x.translate = b.x),
            (f.x.scale = M(o.x.scale, 1, V)),
            (f.x.origin = o.x.origin),
            (f.x.originPoint = o.x.originPoint),
            (f.y.translate = b.y),
            (f.y.scale = M(o.y.scale, 1, V)),
            (f.y.origin = o.y.origin),
            (f.y.originPoint = o.y.originPoint))
          : (Ss(f.x, o.x, V), Ss(f.y, o.y, V)),
          this.setTargetDelta(f),
          this.relativeTarget &&
            this.relativeTargetOrigin &&
            this.layout &&
            this.relativeParent &&
            this.relativeParent.layout &&
            (oe(
              d,
              this.layout.layoutBox,
              this.relativeParent.layout.layoutBox,
              this.options.layoutAnchor || void 0
            ),
            dc(this.relativeTarget, this.relativeTargetOrigin, d, V),
            w && Kl(this.relativeTarget, w) && (this.isProjectionDirty = !1),
            w || (w = B()),
            G(w, this.relativeTarget)),
          g &&
            ((this.animationValues = h), zl(h, l, this.latestValues, V, x, v)),
          b &&
            b.rotate !== void 0 &&
            (this.animationValues || (this.animationValues = h),
            (this.animationValues.pathRotation = b.rotate)),
          this.root.scheduleUpdateProjection(),
          this.scheduleRender(),
          (this.animationProgress = V);
      }),
        this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
    }
    startAnimation(o) {
      this.notifyListeners("animationStart"),
        this.currentAnimation?.stop(),
        this.resumingFrom?.currentAnimation?.stop(),
        this.pendingAnimation &&
          (ot(this.pendingAnimation), (this.pendingAnimation = void 0)),
        (this.pendingAnimation = D.update(() => {
          (qt.hasAnimatedSinceResize = !0),
            this.motionValue || (this.motionValue = wt(0)),
            this.motionValue.jump(0, !1),
            (this.currentAnimation = Xl(this.motionValue, [0, 1e3], {
              ...o,
              velocity: 0,
              isSync: !0,
              onUpdate: (a) => {
                this.mixTargetDelta(a), o.onUpdate && o.onUpdate(a);
              },
              onStop: () => {},
              onComplete: () => {
                o.onComplete && o.onComplete(), this.completeAnimation();
              },
            })),
            this.resumingFrom &&
              (this.resumingFrom.currentAnimation = this.currentAnimation),
            (this.pendingAnimation = void 0);
        }));
    }
    completeAnimation() {
      this.resumingFrom &&
        ((this.resumingFrom.currentAnimation = void 0),
        (this.resumingFrom.preserveOpacity = void 0));
      const o = this.getStack();
      o && o.exitAnimationComplete(),
        (this.resumingFrom =
          this.currentAnimation =
          this.animationValues =
            void 0),
        this.notifyListeners("animationComplete");
    }
    finishAnimation() {
      this.currentAnimation &&
        (this.mixTargetDelta && this.mixTargetDelta(Ql),
        this.currentAnimation.stop()),
        this.completeAnimation();
    }
    applyTransformsToTarget() {
      const o = this.getLead();
      let {
        targetWithTransforms: a,
        target: c,
        layout: u,
        latestValues: l,
      } = o;
      if (!(!a || !c || !u)) {
        if (
          this !== o &&
          this.layout &&
          u &&
          ho(this.options.animationType, this.layout.layoutBox, u.layoutBox)
        ) {
          c = this.target || B();
          const h = U(this.layout.layoutBox.x);
          (c.x.min = o.target.x.min), (c.x.max = c.x.min + h);
          const f = U(this.layout.layoutBox.y);
          (c.y.min = o.target.y.min), (c.y.max = c.y.min + f);
        }
        G(a, c),
          Xt(a, l),
          Dt(this.projectionDeltaWithTransform, this.layoutCorrected, a, l);
      }
    }
    registerSharedNode(o, a) {
      this.sharedNodes.has(o) || this.sharedNodes.set(o, new Jl()),
        this.sharedNodes.get(o).add(a);
      const u = a.options.initialPromotionConfig;
      a.promote({
        transition: u ? u.transition : void 0,
        preserveFollowOpacity:
          u && u.shouldPreserveFollowOpacity
            ? u.shouldPreserveFollowOpacity(a)
            : void 0,
      });
    }
    isLead() {
      const o = this.getStack();
      return o ? o.lead === this : !0;
    }
    getLead() {
      const { layoutId: o } = this.options;
      return o ? this.getStack()?.lead || this : this;
    }
    getPrevLead() {
      const { layoutId: o } = this.options;
      return o ? this.getStack()?.prevLead : void 0;
    }
    getStack() {
      const { layoutId: o } = this.options;
      if (o) return this.root.sharedNodes.get(o);
    }
    promote({ needsReset: o, transition: a, preserveFollowOpacity: c } = {}) {
      const u = this.getStack();
      u && u.promote(this, c),
        o && ((this.projectionDelta = void 0), (this.needsReset = !0)),
        a && this.setOptions({ transition: a });
    }
    relegate() {
      const o = this.getStack();
      return o ? o.relegate(this) : !1;
    }
    resetSkewAndRotation() {
      const { visualElement: o } = this.options;
      if (!o) return;
      let a = !1;
      const { latestValues: c } = o;
      if (
        ((c.z ||
          c.rotate ||
          c.rotateX ||
          c.rotateY ||
          c.rotateZ ||
          c.skewX ||
          c.skewY) &&
          (a = !0),
        !a)
      )
        return;
      const u = {};
      c.z && Te("z", o, u, this.animationValues);
      for (let l = 0; l < xe.length; l++)
        Te(`rotate${xe[l]}`, o, u, this.animationValues),
          Te(`skew${xe[l]}`, o, u, this.animationValues);
      o.render();
      for (const l in u)
        o.setStaticValue(l, u[l]),
          this.animationValues && (this.animationValues[l] = u[l]);
      o.scheduleRender();
    }
    applyProjectionStyles(o, a) {
      if (!this.instance || this.isSVG) return;
      if (!this.isVisible) {
        o.visibility = "hidden";
        return;
      }
      const c = this.getTransformTemplate();
      if (this.needsReset) {
        (this.needsReset = !1),
          (o.visibility = ""),
          (o.opacity = ""),
          (o.pointerEvents = Yt(a?.pointerEvents) || ""),
          (o.transform = c ? c(this.latestValues, "") : "none");
        return;
      }
      const u = this.getLead();
      if (!this.projectionDelta || !this.layout || !u.target) {
        this.options.layoutId &&
          ((o.opacity =
            this.latestValues.opacity !== void 0
              ? this.latestValues.opacity
              : 1),
          (o.pointerEvents = Yt(a?.pointerEvents) || "")),
          this.hasProjected &&
            !ut(this.latestValues) &&
            ((o.transform = c ? c({}, "") : "none"), (this.hasProjected = !1));
        return;
      }
      o.visibility = "";
      const l = u.animationValues || u.latestValues;
      this.applyTransformsToTarget();
      let h = $l(this.projectionDeltaWithTransform, this.treeScale, l);
      c && (h = c(l, h)), (o.transform = h);
      const { x: f, y: d } = this.projectionDelta;
      (o.transformOrigin = `${f.origin * 100}% ${d.origin * 100}% 0`),
        u.animationValues
          ? (o.opacity =
              u === this
                ? l.opacity ?? this.latestValues.opacity ?? 1
                : this.preserveOpacity
                ? this.latestValues.opacity
                : l.opacityExit)
          : (o.opacity =
              u === this
                ? l.opacity !== void 0
                  ? l.opacity
                  : ""
                : l.opacityExit !== void 0
                ? l.opacityExit
                : 0);
      for (const p in Ye) {
        if (l[p] === void 0) continue;
        const { correct: m, applyTo: g, isCSSVariable: y } = Ye[p],
          v = h === "none" ? l[p] : m(l[p], u);
        if (g) {
          const x = g.length;
          for (let w = 0; w < x; w++) o[g[w]] = v;
        } else
          y ? (this.options.visualElement.renderState.vars[p] = v) : (o[p] = v);
      }
      this.options.layoutId &&
        (o.pointerEvents = u === this ? Yt(a?.pointerEvents) || "" : "none");
    }
    clearSnapshot() {
      this.resumeFrom = this.snapshot = void 0;
    }
    resetTree() {
      this.root.nodes.forEach((o) => o.currentAnimation?.stop()),
        this.root.nodes.forEach(Ts),
        this.root.sharedNodes.clear();
    }
  };
}
function ec(t) {
  t.updateLayout();
}
function nc(t) {
  const e = t.resumeFrom?.snapshot || t.snapshot;
  if (t.isLead() && t.layout && e && t.hasListeners("didUpdate")) {
    const { layoutBox: n, measuredBox: s } = t.layout,
      { animationType: i } = t.options,
      r = e.source !== t.layout.source;
    if (i === "size")
      Z((l) => {
        const h = r ? e.measuredBox[l] : e.layoutBox[l],
          f = U(h);
        (h.min = n[l].min), (h.max = h.min + f);
      });
    else if (i === "x" || i === "y") {
      const l = i === "x" ? "y" : "x";
      qe(r ? e.measuredBox[l] : e.layoutBox[l], n[l]);
    } else
      ho(i, e.layoutBox, n) &&
        Z((l) => {
          const h = r ? e.measuredBox[l] : e.layoutBox[l],
            f = U(n[l]);
          (h.max = h.min + f),
            t.relativeTarget &&
              !t.currentAnimation &&
              ((t.isProjectionDirty = !0),
              (t.relativeTarget[l].max = t.relativeTarget[l].min + f));
        });
    const o = xt();
    Dt(o, n, e.layoutBox);
    const a = xt();
    r ? Dt(a, t.applyTransform(s, !0), e.measuredBox) : Dt(a, n, e.layoutBox);
    const c = !oo(o);
    let u = !1;
    if (!t.resumeFrom) {
      const l = t.getClosestProjectingParent();
      if (l && !l.resumeFrom) {
        const { snapshot: h, layout: f } = l;
        if (h && f) {
          const d = t.options.layoutAnchor || void 0,
            p = B();
          oe(p, e.layoutBox, h.layoutBox, d);
          const m = B();
          oe(m, n, f.layoutBox, d),
            ro(p, m) || (u = !0),
            l.options.layoutRoot &&
              ((t.relativeTarget = m),
              (t.relativeTargetOrigin = p),
              (t.relativeParent = l));
        }
      }
    }
    t.notifyListeners("didUpdate", {
      layout: n,
      snapshot: e,
      delta: a,
      layoutDelta: o,
      hasLayoutChanged: c,
      hasRelativeLayoutChanged: u,
    });
  } else if (t.isLead()) {
    const { onExitComplete: n } = t.options;
    n && n();
  }
  t.options.transition = void 0;
}
function sc(t) {
  t.parent &&
    (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty),
    t.isSharedProjectionDirty ||
      (t.isSharedProjectionDirty = !!(
        t.isProjectionDirty ||
        t.parent.isProjectionDirty ||
        t.parent.isSharedProjectionDirty
      )),
    t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty));
}
function ic(t) {
  t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = !1;
}
function oc(t) {
  t.clearSnapshot();
}
function Ts(t) {
  t.clearMeasurements();
}
function rc(t) {
  (t.isLayoutDirty = !0), t.updateLayout();
}
function ws(t) {
  t.isLayoutDirty = !1;
}
function ac(t) {
  t.isAnimationBlocked &&
    t.layout &&
    !t.isLayoutDirty &&
    ((t.snapshot = t.layout), (t.isLayoutDirty = !0));
}
function lc(t) {
  const { visualElement: e } = t.options;
  e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"),
    t.resetTransform();
}
function Ps(t) {
  t.finishAnimation(),
    (t.targetDelta = t.relativeTarget = t.target = void 0),
    (t.isProjectionDirty = !0);
}
function cc(t) {
  t.resolveTargetDelta();
}
function uc(t) {
  t.calcProjection();
}
function hc(t) {
  t.resetSkewAndRotation();
}
function fc(t) {
  t.removeLeadSnapshot();
}
function Ss(t, e, n) {
  (t.translate = M(e.translate, 0, n)),
    (t.scale = M(e.scale, 1, n)),
    (t.origin = e.origin),
    (t.originPoint = e.originPoint);
}
function bs(t, e, n, s) {
  (t.min = M(e.min, n.min, s)), (t.max = M(e.max, n.max, s));
}
function dc(t, e, n, s) {
  bs(t.x, e.x, n.x, s), bs(t.y, e.y, n.y, s);
}
function pc(t) {
  return t.animationValues && t.animationValues.opacityExit !== void 0;
}
const mc = { duration: 0.45, ease: [0.4, 0, 0.1, 1] },
  As = (t) =>
    typeof navigator < "u" &&
    navigator.userAgent &&
    navigator.userAgent.toLowerCase().includes(t),
  Vs = As("applewebkit/") && !As("chrome/") ? Math.round : z;
function Cs(t) {
  (t.min = Vs(t.min)), (t.max = Vs(t.max));
}
function gc(t) {
  Cs(t.x), Cs(t.y);
}
function ho(t, e, n) {
  return (
    t === "position" || (t === "preserve-aspect" && !jl(ms(e), ms(n), 0.2))
  );
}
function yc(t) {
  return t !== t.root && t.scroll?.wasRoot;
}
const vc = uo({
    attachResizeListener: (t, e) => Bt(t, "resize", e),
    measureScroll: () => ({
      x: document.documentElement.scrollLeft || document.body?.scrollLeft || 0,
      y: document.documentElement.scrollTop || document.body?.scrollTop || 0,
    }),
    checkIsScrollRoot: () => !0,
  }),
  we = { current: void 0 },
  fo = uo({
    measureScroll: (t) => ({ x: t.scrollLeft, y: t.scrollTop }),
    defaultParent: () => {
      if (!we.current) {
        const t = new vc({});
        t.mount(window), t.setOptions({ layoutScroll: !0 }), (we.current = t);
      }
      return we.current;
    },
    resetTransform: (t, e) => {
      t.style.transform = e !== void 0 ? e : "none";
    },
    checkIsScrollRoot: (t) => window.getComputedStyle(t).position === "fixed",
  }),
  po = P.createContext({
    transformPagePoint: (t) => t,
    isStatic: !1,
    reducedMotion: "never",
  });
function xc(t = !0) {
  const e = P.useContext(Qe);
  if (e === null) return [!0, null];
  const { isPresent: n, onExitComplete: s, register: i } = e,
    r = P.useId();
  P.useEffect(() => {
    if (t) return i(r);
  }, [t]);
  const o = P.useCallback(() => t && s && s(r), [r, s, t]);
  return !n && s ? [!1, o] : [!0];
}
const mo = P.createContext({ strict: !1 }),
  Ms = {
    animation: [
      "animate",
      "variants",
      "whileHover",
      "whileTap",
      "exit",
      "whileInView",
      "whileFocus",
      "whileDrag",
    ],
    exit: ["exit"],
    drag: ["drag", "dragControls"],
    focus: ["whileFocus"],
    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
    layout: ["layout", "layoutId"],
  };
let Ds = !1;
function Tc() {
  if (Ds) return;
  const t = {};
  for (const e in Ms) t[e] = { isEnabled: (n) => Ms[e].some((s) => !!n[s]) };
  $i(t), (Ds = !0);
}
function go() {
  return Tc(), cl();
}
function wc(t) {
  const e = go();
  for (const n in t) e[n] = { ...e[n], ...t[n] };
  $i(e);
}
const Pc = new Set([
  "animate",
  "exit",
  "variants",
  "initial",
  "style",
  "values",
  "variants",
  "transition",
  "transformTemplate",
  "custom",
  "inherit",
  "onBeforeLayoutMeasure",
  "onAnimationStart",
  "onAnimationComplete",
  "onUpdate",
  "onDragStart",
  "onDrag",
  "onDragEnd",
  "onMeasureDragConstraints",
  "onDirectionLock",
  "onDragTransitionEnd",
  "_dragX",
  "_dragY",
  "onHoverStart",
  "onHoverEnd",
  "onViewportEnter",
  "onViewportLeave",
  "globalTapTarget",
  "propagate",
  "ignoreStrict",
  "viewport",
]);
function re(t) {
  return (
    t.startsWith("while") ||
    (t.startsWith("drag") && t !== "draggable") ||
    t.startsWith("layout") ||
    t.startsWith("onTap") ||
    t.startsWith("onPan") ||
    t.startsWith("onLayout") ||
    Pc.has(t)
  );
}
let yo = (t) => !re(t);
function Sc(t) {
  typeof t == "function" && (yo = (e) => (e.startsWith("on") ? !re(e) : t(e)));
}
try {
  Sc(require("@emotion/is-prop-valid").default);
} catch {}
function bc(t, e, n) {
  const s = {};
  for (const i in t)
    (i === "values" && typeof t.values == "object") ||
      O(t[i]) ||
      ((yo(i) ||
        (n === !0 && re(i)) ||
        (!e && !re(i)) ||
        (t.draggable && i.startsWith("onDrag"))) &&
        (s[i] = t[i]));
  return s;
}
const ue = P.createContext({});
function Ac(t, e) {
  if (ce(t)) {
    const { initial: n, animate: s } = t;
    return {
      initial: n === !1 || kt(n) ? n : void 0,
      animate: kt(s) ? s : void 0,
    };
  }
  return t.inherit !== !1 ? e : {};
}
function Vc(t) {
  const { initial: e, animate: n } = Ac(t, P.useContext(ue));
  return P.useMemo(() => ({ initial: e, animate: n }), [Es(e), Es(n)]);
}
function Es(t) {
  return Array.isArray(t) ? t.join(" ") : t;
}
const bn = () => ({ style: {}, transform: {}, transformOrigin: {}, vars: {} });
function vo(t, e, n) {
  for (const s in e) !O(e[s]) && !qi(s, n) && (t[s] = e[s]);
}
function Cc({ transformTemplate: t }, e) {
  return P.useMemo(() => {
    const n = bn();
    return Pn(n, e, t), Object.assign({}, n.vars, n.style);
  }, [e]);
}
function Mc(t, e) {
  const n = t.style || {},
    s = {};
  return vo(s, n, t), Object.assign(s, Cc(t, e)), s;
}
function Dc(t, e) {
  const n = {},
    s = Mc(t, e);
  return (
    t.drag &&
      t.dragListener !== !1 &&
      ((n.draggable = !1),
      (s.userSelect = s.WebkitUserSelect = s.WebkitTouchCallout = "none"),
      (s.touchAction =
        t.drag === !0 ? "none" : `pan-${t.drag === "x" ? "y" : "x"}`)),
    t.tabIndex === void 0 &&
      (t.onTap || t.onTapStart || t.whileTap) &&
      (n.tabIndex = 0),
    (n.style = s),
    n
  );
}
const xo = () => ({ ...bn(), attrs: {} });
function Ec(t, e, n, s) {
  const i = P.useMemo(() => {
    const r = xo();
    return (
      Zi(r, e, Qi(s), t.transformTemplate, t.style),
      { ...r.attrs, style: { ...r.style } }
    );
  }, [e]);
  if (t.style) {
    const r = {};
    vo(r, t.style, t), (i.style = { ...r, ...i.style });
  }
  return i;
}
const Rc = [
  "animate",
  "circle",
  "defs",
  "desc",
  "ellipse",
  "g",
  "image",
  "line",
  "filter",
  "marker",
  "mask",
  "metadata",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "rect",
  "stop",
  "switch",
  "symbol",
  "svg",
  "text",
  "tspan",
  "use",
  "view",
];
function An(t) {
  return typeof t != "string" || t.includes("-")
    ? !1
    : !!(Rc.indexOf(t) > -1 || /[A-Z]/u.test(t));
}
function Lc(t, e, n, { latestValues: s }, i, r = !1, o) {
  const c = (o ?? An(t) ? Ec : Dc)(e, s, i, t),
    u = bc(e, typeof t == "string", r),
    l = t !== P.Fragment ? { ...u, ...c, ref: n } : {},
    { children: h } = e,
    f = P.useMemo(() => (O(h) ? h.get() : h), [h]);
  return P.createElement(t, { ...l, children: f });
}
function kc({ scrapeMotionValuesFromProps: t, createRenderState: e }, n, s, i) {
  return { latestValues: Bc(n, s, i, t), renderState: e() };
}
function Bc(t, e, n, s) {
  const i = {},
    r = s(t, {});
  for (const f in r) i[f] = Yt(r[f]);
  let { initial: o, animate: a } = t;
  const c = ce(t),
    u = Wi(t);
  e &&
    u &&
    !c &&
    t.inherit !== !1 &&
    (o === void 0 && (o = e.initial), a === void 0 && (a = e.animate));
  let l = n ? n.initial === !1 : !1;
  l = l || o === !1;
  const h = l ? a : o;
  if (h && typeof h != "boolean" && !le(h)) {
    const f = Array.isArray(h) ? h : [h];
    for (let d = 0; d < f.length; d++) {
      const p = mn(t, f[d]);
      if (p) {
        const { transitionEnd: m, transition: g, ...y } = p;
        for (const v in y) {
          let x = y[v];
          if (Array.isArray(x)) {
            const w = l ? x.length - 1 : 0;
            x = x[w];
          }
          x !== null && (i[v] = x);
        }
        for (const v in m) i[v] = m[v];
      }
    }
  }
  return i;
}
const To = (t) => (e, n) => {
    const s = P.useContext(ue),
      i = P.useContext(Qe),
      r = () => kc(t, e, s, i);
    return n ? r() : Lo(r);
  },
  Fc = To({ scrapeMotionValuesFromProps: Sn, createRenderState: bn }),
  Ic = To({ scrapeMotionValuesFromProps: to, createRenderState: xo }),
  jc = Symbol.for("motionComponentSymbol");
function Oc(t, e, n) {
  const s = P.useRef(n);
  P.useInsertionEffect(() => {
    s.current = n;
  });
  const i = P.useRef(null);
  return P.useCallback(
    (r) => {
      r && t.onMount?.(r), e && (r ? e.mount(r) : e.unmount());
      const o = s.current;
      if (typeof o == "function")
        if (r) {
          const a = o(r);
          typeof a == "function" && (i.current = a);
        } else i.current ? (i.current(), (i.current = null)) : o(r);
      else o && (o.current = r);
    },
    [e]
  );
}
const wo = P.createContext({});
function gt(t) {
  return (
    t &&
    typeof t == "object" &&
    Object.prototype.hasOwnProperty.call(t, "current")
  );
}
function Nc(t, e, n, s, i, r) {
  const { visualElement: o } = P.useContext(ue),
    a = P.useContext(mo),
    c = P.useContext(Qe),
    u = P.useContext(po),
    l = u.reducedMotion,
    h = u.skipAnimations,
    f = P.useRef(null),
    d = P.useRef(!1);
  (s = s || a.renderer),
    !f.current &&
      s &&
      ((f.current = s(t, {
        visualState: e,
        parent: o,
        props: n,
        presenceContext: c,
        blockInitialAnimation: c ? c.initial === !1 : !1,
        reducedMotionConfig: l,
        skipAnimations: h,
        isSVG: r,
      })),
      d.current && f.current && (f.current.manuallyAnimateOnMount = !0));
  const p = f.current,
    m = P.useContext(wo);
  p &&
    !p.projection &&
    i &&
    (p.type === "html" || p.type === "svg") &&
    Uc(f.current, n, i, m);
  const g = P.useRef(!1);
  P.useInsertionEffect(() => {
    p && g.current && p.update(n, c);
  });
  const y = n[Di],
    v = P.useRef(
      !!y &&
        typeof window < "u" &&
        !window.MotionHandoffIsComplete?.(y) &&
        window.MotionHasOptimisedAnimation?.(y)
    );
  return (
    Bo(() => {
      (d.current = !0),
        p &&
          ((g.current = !0),
          (window.MotionIsMounted = !0),
          p.updateFeatures(),
          p.scheduleRenderMicrotask(),
          v.current && p.animationState && p.animationState.animateChanges());
    }),
    P.useEffect(() => {
      p &&
        (!v.current && p.animationState && p.animationState.animateChanges(),
        v.current &&
          (queueMicrotask(() => {
            window.MotionHandoffMarkAsComplete?.(y);
          }),
          (v.current = !1)),
        (p.enteringChildren = void 0));
    }),
    p
  );
}
function Uc(t, e, n, s) {
  const {
    layoutId: i,
    layout: r,
    drag: o,
    dragConstraints: a,
    layoutScroll: c,
    layoutRoot: u,
    layoutAnchor: l,
    layoutCrossfade: h,
  } = e;
  (t.projection = new n(
    t.latestValues,
    e["data-framer-portal-id"] ? void 0 : Po(t.parent)
  )),
    t.projection.setOptions({
      layoutId: i,
      layout: r,
      alwaysMeasureLayout: !!o || (a && gt(a)),
      visualElement: t,
      animationType: typeof r == "string" ? r : "both",
      initialPromotionConfig: s,
      crossfade: h,
      layoutScroll: c,
      layoutRoot: u,
      layoutAnchor: l,
    });
}
function Po(t) {
  if (t) return t.options.allowProjection !== !1 ? t.projection : Po(t.parent);
}
function Pe(t, { forwardMotionProps: e = !1, type: n } = {}, s, i) {
  s && wc(s);
  const r = n ? n === "svg" : An(t),
    o = r ? Ic : Fc;
  function a(u, l) {
    let h;
    const f = { ...P.useContext(po), ...u, layoutId: Wc(u) },
      { isStatic: d } = f,
      p = Vc(u),
      m = o(u, d);
    if (!d && typeof window < "u") {
      Kc();
      const g = $c(f);
      (h = g.MeasureLayout),
        (p.visualElement = Nc(t, m, f, i, g.ProjectionNode, r));
    }
    return C.jsxs(ue.Provider, {
      value: p,
      children: [
        h && p.visualElement
          ? C.jsx(h, { visualElement: p.visualElement, ...f })
          : null,
        Lc(t, u, Oc(m, p.visualElement, l), m, d, e, r),
      ],
    });
  }
  a.displayName = `motion.${
    typeof t == "string" ? t : `create(${t.displayName ?? t.name ?? ""})`
  }`;
  const c = P.forwardRef(a);
  return (c[jc] = t), c;
}
function Wc({ layoutId: t }) {
  const e = P.useContext(Ws).id;
  return e && t !== void 0 ? e + "-" + t : t;
}
function Kc(t, e) {
  P.useContext(mo).strict;
}
function $c(t) {
  const e = go(),
    { drag: n, layout: s } = e;
  if (!n && !s) return {};
  const i = { ...n, ...s };
  return {
    MeasureLayout:
      n?.isEnabled(t) || s?.isEnabled(t) ? i.MeasureLayout : void 0,
    ProjectionNode: i.ProjectionNode,
  };
}
function Hc(t, e) {
  if (typeof Proxy > "u") return Pe;
  const n = new Map(),
    s = (r, o) => Pe(r, o, t, e),
    i = (r, o) => s(r, o);
  return new Proxy(i, {
    get: (r, o) =>
      o === "create"
        ? s
        : (n.has(o) || n.set(o, Pe(o, void 0, t, e)), n.get(o)),
  });
}
const zc = (t, e) =>
  e.isSVG ?? An(t)
    ? new Vl(e)
    : new Tl(e, { allowProjection: t !== P.Fragment });
class Gc extends rt {
  constructor(e) {
    super(e), e.animationState || (e.animationState = Rl(e));
  }
  updateAnimationControlsSubscription() {
    const { animate: e } = this.node.getProps();
    le(e) && (this.unmountControls = e.subscribe(this.node));
  }
  mount() {
    this.updateAnimationControlsSubscription();
  }
  update() {
    const { animate: e } = this.node.getProps(),
      { animate: n } = this.node.prevProps || {};
    e !== n && this.updateAnimationControlsSubscription();
  }
  unmount() {
    this.node.animationState.reset(), this.unmountControls?.();
  }
}
let _c = 0;
class Xc extends rt {
  constructor() {
    super(...arguments), (this.id = _c++), (this.isExitComplete = !1);
  }
  update() {
    if (!this.node.presenceContext) return;
    const { isPresent: e, onExitComplete: n } = this.node.presenceContext,
      { isPresent: s } = this.node.prevPresenceContext || {};
    if (!this.node.animationState || e === s) return;
    if (e && s === !1) {
      if (this.isExitComplete) {
        const { initial: r, custom: o } = this.node.getProps();
        if (
          typeof r == "string" ||
          (typeof r == "object" && r !== null && !Array.isArray(r))
        ) {
          const a = pt(this.node, r, o);
          if (a) {
            const { transition: c, transitionEnd: u, ...l } = a;
            for (const h in l) this.node.getValue(h)?.jump(l[h]);
          }
        }
        this.node.animationState.reset(),
          this.node.animationState.animateChanges();
      } else this.node.animationState.setActive("exit", !1);
      this.isExitComplete = !1;
      return;
    }
    const i = this.node.animationState.setActive("exit", !e);
    n &&
      !e &&
      i.then(() => {
        (this.isExitComplete = !0), n(this.id);
      });
  }
  mount() {
    const { register: e, onExitComplete: n } = this.node.presenceContext || {};
    n && n(this.id), e && (this.unmount = e(this.id));
  }
  unmount() {}
}
const Yc = { animation: { Feature: Gc }, exit: { Feature: Xc } };
function Ot(t) {
  return { point: { x: t.pageX, y: t.pageY } };
}
const qc = (t) => (e) => vn(e) && t(e, Ot(e));
function Et(t, e, n, s) {
  return Bt(t, e, qc(n), s);
}
const So = ({ current: t }) => (t ? t.ownerDocument.defaultView : null),
  Rs = (t, e) => Math.abs(t - e);
function Zc(t, e) {
  const n = Rs(t.x, e.x),
    s = Rs(t.y, e.y);
  return Math.sqrt(n ** 2 + s ** 2);
}
const Ls = new Set(["auto", "scroll"]);
class bo {
  constructor(
    e,
    n,
    {
      transformPagePoint: s,
      contextWindow: i = window,
      dragSnapToOrigin: r = !1,
      distanceThreshold: o = 3,
      element: a,
    } = {}
  ) {
    if (
      ((this.startEvent = null),
      (this.lastMoveEvent = null),
      (this.lastMoveEventInfo = null),
      (this.lastRawMoveEventInfo = null),
      (this.handlers = {}),
      (this.contextWindow = window),
      (this.scrollPositions = new Map()),
      (this.removeScrollListeners = null),
      (this.onElementScroll = (d) => {
        this.handleScroll(d.target);
      }),
      (this.onWindowScroll = () => {
        this.handleScroll(window);
      }),
      (this.updatePoint = () => {
        if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
        this.lastRawMoveEventInfo &&
          (this.lastMoveEventInfo = Wt(
            this.lastRawMoveEventInfo,
            this.transformPagePoint
          ));
        const d = Se(this.lastMoveEventInfo, this.history),
          p = this.startEvent !== null,
          m = Zc(d.offset, { x: 0, y: 0 }) >= this.distanceThreshold;
        if (!p && !m) return;
        const { point: g } = d,
          { timestamp: y } = j;
        this.history.push({ ...g, timestamp: y });
        const { onStart: v, onMove: x } = this.handlers;
        p ||
          (v && v(this.lastMoveEvent, d),
          (this.startEvent = this.lastMoveEvent)),
          x && x(this.lastMoveEvent, d);
      }),
      (this.handlePointerMove = (d, p) => {
        (this.lastMoveEvent = d),
          (this.lastRawMoveEventInfo = p),
          (this.lastMoveEventInfo = Wt(p, this.transformPagePoint)),
          D.update(this.updatePoint, !0);
      }),
      (this.handlePointerUp = (d, p) => {
        this.end();
        const { onEnd: m, onSessionEnd: g, resumeAnimation: y } = this.handlers;
        if (
          ((this.dragSnapToOrigin || !this.startEvent) && y && y(),
          !(this.lastMoveEvent && this.lastMoveEventInfo))
        )
          return;
        const v = Se(
          d.type === "pointercancel"
            ? this.lastMoveEventInfo
            : Wt(p, this.transformPagePoint),
          this.history
        );
        this.startEvent && m && m(d, v), g && g(d, v);
      }),
      !vn(e))
    )
      return;
    (this.dragSnapToOrigin = r),
      (this.handlers = n),
      (this.transformPagePoint = s),
      (this.distanceThreshold = o),
      (this.contextWindow = i || window);
    const c = Ot(e),
      u = Wt(c, this.transformPagePoint),
      { point: l } = u,
      { timestamp: h } = j;
    this.history = [{ ...l, timestamp: h }];
    const { onSessionStart: f } = n;
    f && f(e, Se(u, this.history)),
      (this.removeListeners = Ft(
        Et(this.contextWindow, "pointermove", this.handlePointerMove),
        Et(this.contextWindow, "pointerup", this.handlePointerUp),
        Et(this.contextWindow, "pointercancel", this.handlePointerUp)
      )),
      a && this.startScrollTracking(a);
  }
  startScrollTracking(e) {
    let n = e.parentElement;
    for (; n; ) {
      const s = getComputedStyle(n);
      (Ls.has(s.overflowX) || Ls.has(s.overflowY)) &&
        this.scrollPositions.set(n, { x: n.scrollLeft, y: n.scrollTop }),
        (n = n.parentElement);
    }
    this.scrollPositions.set(window, { x: window.scrollX, y: window.scrollY }),
      window.addEventListener("scroll", this.onElementScroll, { capture: !0 }),
      window.addEventListener("scroll", this.onWindowScroll),
      (this.removeScrollListeners = () => {
        window.removeEventListener("scroll", this.onElementScroll, {
          capture: !0,
        }),
          window.removeEventListener("scroll", this.onWindowScroll);
      });
  }
  handleScroll(e) {
    const n = this.scrollPositions.get(e);
    if (!n) return;
    const s = e === window,
      i = s
        ? { x: window.scrollX, y: window.scrollY }
        : { x: e.scrollLeft, y: e.scrollTop },
      r = { x: i.x - n.x, y: i.y - n.y };
    (r.x === 0 && r.y === 0) ||
      (s
        ? this.lastMoveEventInfo &&
          ((this.lastMoveEventInfo.point.x += r.x),
          (this.lastMoveEventInfo.point.y += r.y))
        : this.history.length > 0 &&
          ((this.history[0].x -= r.x), (this.history[0].y -= r.y)),
      this.scrollPositions.set(e, i),
      D.update(this.updatePoint, !0));
  }
  updateHandlers(e) {
    this.handlers = e;
  }
  end() {
    this.removeListeners && this.removeListeners(),
      this.removeScrollListeners && this.removeScrollListeners(),
      this.scrollPositions.clear(),
      ot(this.updatePoint);
  }
}
function Wt(t, e) {
  return e ? { point: e(t.point) } : t;
}
function ks(t, e) {
  return { x: t.x - e.x, y: t.y - e.y };
}
function Se({ point: t }, e) {
  return {
    point: t,
    delta: ks(t, Ao(e)),
    offset: ks(t, Jc(e)),
    velocity: Qc(e, 0.1),
  };
}
function Jc(t) {
  return t[0];
}
function Ao(t) {
  return t[t.length - 1];
}
function Qc(t, e) {
  if (t.length < 2) return { x: 0, y: 0 };
  let n = t.length - 1,
    s = null;
  const i = Ao(t);
  for (; n >= 0 && ((s = t[n]), !(i.timestamp - s.timestamp > K(e))); ) n--;
  if (!s) return { x: 0, y: 0 };
  s === t[0] &&
    t.length > 2 &&
    i.timestamp - s.timestamp > K(e) * 2 &&
    (s = t[1]);
  const r = H(i.timestamp - s.timestamp);
  if (r === 0) return { x: 0, y: 0 };
  const o = { x: (i.x - s.x) / r, y: (i.y - s.y) / r };
  return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o;
}
function tu(t, { min: e, max: n }, s) {
  return (
    e !== void 0 && t < e
      ? (t = s ? M(e, t, s.min) : Math.max(t, e))
      : n !== void 0 && t > n && (t = s ? M(n, t, s.max) : Math.min(t, n)),
    t
  );
}
function Bs(t, e, n) {
  return {
    min: e !== void 0 ? t.min + e : void 0,
    max: n !== void 0 ? t.max + n - (t.max - t.min) : void 0,
  };
}
function eu(t, { top: e, left: n, bottom: s, right: i }) {
  return { x: Bs(t.x, n, i), y: Bs(t.y, e, s) };
}
function Fs(t, e) {
  let n = e.min - t.min,
    s = e.max - t.max;
  return e.max - e.min < t.max - t.min && ([n, s] = [s, n]), { min: n, max: s };
}
function nu(t, e) {
  return { x: Fs(t.x, e.x), y: Fs(t.y, e.y) };
}
function su(t, e) {
  let n = 0.5;
  const s = U(t),
    i = U(e);
  return (
    i > s
      ? (n = Rt(e.min, e.max - s, t.min))
      : s > i && (n = Rt(t.min, t.max - i, e.min)),
    tt(0, 1, n)
  );
}
function iu(t, e) {
  const n = {};
  return (
    e.min !== void 0 && (n.min = e.min - t.min),
    e.max !== void 0 && (n.max = e.max - t.min),
    n
  );
}
const Ze = 0.35;
function ou(t = Ze) {
  return (
    t === !1 ? (t = 0) : t === !0 && (t = Ze),
    { x: Is(t, "left", "right"), y: Is(t, "top", "bottom") }
  );
}
function Is(t, e, n) {
  return { min: js(t, e), max: js(t, n) };
}
function js(t, e) {
  return typeof t == "number" ? t : t[e] || 0;
}
const ru = new WeakMap();
class au {
  constructor(e) {
    (this.openDragLock = null),
      (this.isDragging = !1),
      (this.currentDirection = null),
      (this.originPoint = { x: 0, y: 0 }),
      (this.constraints = !1),
      (this.hasMutatedConstraints = !1),
      (this.elastic = B()),
      (this.latestPointerEvent = null),
      (this.latestPanInfo = null),
      (this.visualElement = e);
  }
  start(e, { snapToCursor: n = !1, distanceThreshold: s } = {}) {
    const { presenceContext: i } = this.visualElement;
    if (i && i.isPresent === !1) return;
    const r = (h) => {
        n && this.snapToCursor(Ot(h).point), this.stopAnimation();
      },
      o = (h, f) => {
        const { drag: d, dragPropagation: p, onDragStart: m } = this.getProps();
        if (
          d &&
          !p &&
          (this.openDragLock && this.openDragLock(),
          (this.openDragLock = Na(d)),
          !this.openDragLock)
        )
          return;
        (this.latestPointerEvent = h),
          (this.latestPanInfo = f),
          (this.isDragging = !0),
          (this.currentDirection = null),
          this.resolveConstraints(),
          this.visualElement.projection &&
            ((this.visualElement.projection.isAnimationBlocked = !0),
            (this.visualElement.projection.target = void 0)),
          Z((y) => {
            let v = this.getAxisMotionValue(y).get() || 0;
            if (Q.test(v)) {
              const { projection: x } = this.visualElement;
              if (x && x.layout) {
                const w = x.layout.layoutBox[y];
                w && (v = U(w) * (parseFloat(v) / 100));
              }
            }
            this.originPoint[y] = v;
          }),
          m && D.update(() => m(h, f), !1, !0),
          We(this.visualElement, "transform");
        const { animationState: g } = this.visualElement;
        g && g.setActive("whileDrag", !0);
      },
      a = (h, f) => {
        (this.latestPointerEvent = h), (this.latestPanInfo = f);
        const {
          dragPropagation: d,
          dragDirectionLock: p,
          onDirectionLock: m,
          onDrag: g,
        } = this.getProps();
        if (!d && !this.openDragLock) return;
        const { offset: y } = f;
        if (p && this.currentDirection === null) {
          (this.currentDirection = cu(y)),
            this.currentDirection !== null && m && m(this.currentDirection);
          return;
        }
        this.updateAxis("x", f.point, y),
          this.updateAxis("y", f.point, y),
          this.visualElement.render(),
          g && D.update(() => g(h, f), !1, !0);
      },
      c = (h, f) => {
        (this.latestPointerEvent = h),
          (this.latestPanInfo = f),
          this.stop(h, f),
          (this.latestPointerEvent = null),
          (this.latestPanInfo = null);
      },
      u = () => {
        const { dragSnapToOrigin: h } = this.getProps();
        (h || this.constraints) && this.startAnimation({ x: 0, y: 0 });
      },
      { dragSnapToOrigin: l } = this.getProps();
    this.panSession = new bo(
      e,
      {
        onSessionStart: r,
        onStart: o,
        onMove: a,
        onSessionEnd: c,
        resumeAnimation: u,
      },
      {
        transformPagePoint: this.visualElement.getTransformPagePoint(),
        dragSnapToOrigin: l,
        distanceThreshold: s,
        contextWindow: So(this.visualElement),
        element: this.visualElement.current,
      }
    );
  }
  stop(e, n) {
    const s = e || this.latestPointerEvent,
      i = n || this.latestPanInfo,
      r = this.isDragging;
    if ((this.cancel(), !r || !i || !s)) return;
    const { velocity: o } = i;
    this.startAnimation(o);
    const { onDragEnd: a } = this.getProps();
    a && D.postRender(() => a(s, i));
  }
  cancel() {
    this.isDragging = !1;
    const { projection: e, animationState: n } = this.visualElement;
    e && (e.isAnimationBlocked = !1), this.endPanSession();
    const { dragPropagation: s } = this.getProps();
    !s &&
      this.openDragLock &&
      (this.openDragLock(), (this.openDragLock = null)),
      n && n.setActive("whileDrag", !1);
  }
  endPanSession() {
    this.panSession && this.panSession.end(), (this.panSession = void 0);
  }
  updateAxis(e, n, s) {
    const { drag: i } = this.getProps();
    if (!s || !Kt(e, i, this.currentDirection)) return;
    const r = this.getAxisMotionValue(e);
    let o = this.originPoint[e] + s[e];
    this.constraints &&
      this.constraints[e] &&
      (o = tu(o, this.constraints[e], this.elastic[e])),
      r.set(o);
  }
  resolveConstraints() {
    const { dragConstraints: e, dragElastic: n } = this.getProps(),
      s =
        this.visualElement.projection && !this.visualElement.projection.layout
          ? this.visualElement.projection.measure(!1)
          : this.visualElement.projection?.layout,
      i = this.constraints;
    e && gt(e)
      ? this.constraints || (this.constraints = this.resolveRefConstraints())
      : e && s
      ? (this.constraints = eu(s.layoutBox, e))
      : (this.constraints = !1),
      (this.elastic = ou(n)),
      i !== this.constraints &&
        !gt(e) &&
        s &&
        this.constraints &&
        !this.hasMutatedConstraints &&
        Z((r) => {
          this.constraints !== !1 &&
            this.getAxisMotionValue(r) &&
            (this.constraints[r] = iu(s.layoutBox[r], this.constraints[r]));
        });
  }
  resolveRefConstraints() {
    const { dragConstraints: e, onMeasureDragConstraints: n } = this.getProps();
    if (!e || !gt(e)) return !1;
    const s = e.current,
      { projection: i } = this.visualElement;
    if (!i || !i.layout) return !1;
    i.root && ((i.root.scroll = void 0), i.root.updateScroll());
    const r = pl(s, i.root, this.visualElement.getTransformPagePoint());
    let o = nu(i.layout.layoutBox, r);
    if (n) {
      const a = n(hl(o));
      (this.hasMutatedConstraints = !!a), a && (o = zi(a));
    }
    return o;
  }
  startAnimation(e) {
    const {
        drag: n,
        dragMomentum: s,
        dragElastic: i,
        dragTransition: r,
        dragSnapToOrigin: o,
        onDragTransitionEnd: a,
      } = this.getProps(),
      c = this.constraints || {},
      u = Z((l) => {
        if (!Kt(l, n, this.currentDirection)) return;
        let h = (c && c[l]) || {};
        (o === !0 || o === l) && (h = { min: 0, max: 0 });
        const f = i ? 200 : 1e6,
          d = i ? 40 : 1e7,
          p = {
            type: "inertia",
            velocity: s ? e[l] : 0,
            bounceStiffness: f,
            bounceDamping: d,
            timeConstant: 750,
            restDelta: 1,
            restSpeed: 10,
            ...r,
            ...h,
          };
        return this.startAxisValueAnimation(l, p);
      });
    return Promise.all(u).then(a);
  }
  startAxisValueAnimation(e, n) {
    const s = this.getAxisMotionValue(e);
    return (
      We(this.visualElement, e), s.start(pn(e, s, 0, n, this.visualElement, !1))
    );
  }
  stopAnimation() {
    Z((e) => this.getAxisMotionValue(e).stop());
  }
  getAxisMotionValue(e) {
    const n = `_drag${e.toUpperCase()}`,
      i = this.visualElement.getProps()[n];
    return (
      i ||
      this.visualElement.getValue(e, this.visualElement.latestValues[e] ?? 0)
    );
  }
  snapToCursor(e) {
    Z((n) => {
      const { drag: s } = this.getProps();
      if (!Kt(n, s, this.currentDirection)) return;
      const { projection: i } = this.visualElement,
        r = this.getAxisMotionValue(n);
      if (i && i.layout) {
        const { min: o, max: a } = i.layout.layoutBox[n],
          c = r.get() || 0;
        r.set(e[n] - M(o, a, 0.5) + c);
      }
    });
  }
  scalePositionWithinConstraints() {
    if (!this.visualElement.current) return;
    const { drag: e, dragConstraints: n } = this.getProps(),
      { projection: s } = this.visualElement;
    if (!gt(n) || !s || !this.constraints) return;
    this.stopAnimation();
    const i = { x: 0, y: 0 };
    Z((o) => {
      const a = this.getAxisMotionValue(o);
      if (a && this.constraints !== !1) {
        const c = a.get();
        i[o] = su({ min: c, max: c }, this.constraints[o]);
      }
    });
    const { transformTemplate: r } = this.visualElement.getProps();
    (this.visualElement.current.style.transform = r ? r({}, "") : "none"),
      s.root && s.root.updateScroll(),
      s.updateLayout(),
      (this.constraints = !1),
      this.resolveConstraints(),
      Z((o) => {
        if (!Kt(o, e, null)) return;
        const a = this.getAxisMotionValue(o),
          { min: c, max: u } = this.constraints[o];
        a.set(M(c, u, i[o]));
      }),
      this.visualElement.render();
  }
  addListeners() {
    if (!this.visualElement.current) return;
    ru.set(this.visualElement, this);
    const e = this.visualElement.current,
      n = Et(e, "pointerdown", (u) => {
        const { drag: l, dragListener: h = !0 } = this.getProps(),
          f = u.target,
          d = f !== e && za(f);
        l && h && !d && this.start(u);
      });
    let s;
    const i = () => {
        const { dragConstraints: u } = this.getProps();
        gt(u) &&
          u.current &&
          ((this.constraints = this.resolveRefConstraints()),
          s ||
            (s = lu(e, u.current, () =>
              this.scalePositionWithinConstraints()
            )));
      },
      { projection: r } = this.visualElement,
      o = r.addEventListener("measure", i);
    r && !r.layout && (r.root && r.root.updateScroll(), r.updateLayout()),
      D.read(i);
    const a = Bt(window, "resize", () => this.scalePositionWithinConstraints()),
      c = r.addEventListener(
        "didUpdate",
        ({ delta: u, hasLayoutChanged: l }) => {
          this.isDragging &&
            l &&
            (Z((h) => {
              const f = this.getAxisMotionValue(h);
              f &&
                ((this.originPoint[h] += u[h].translate),
                f.set(f.get() + u[h].translate));
            }),
            this.visualElement.render());
        }
      );
    return () => {
      a(), n(), o(), c && c(), s && s();
    };
  }
  getProps() {
    const e = this.visualElement.getProps(),
      {
        drag: n = !1,
        dragDirectionLock: s = !1,
        dragPropagation: i = !1,
        dragConstraints: r = !1,
        dragElastic: o = Ze,
        dragMomentum: a = !0,
      } = e;
    return {
      ...e,
      drag: n,
      dragDirectionLock: s,
      dragPropagation: i,
      dragConstraints: r,
      dragElastic: o,
      dragMomentum: a,
    };
  }
}
function Os(t) {
  let e = !0;
  return () => {
    if (e) {
      e = !1;
      return;
    }
    t();
  };
}
function lu(t, e, n) {
  const s = _n(t, Os(n)),
    i = _n(e, Os(n));
  return () => {
    s(), i();
  };
}
function Kt(t, e, n) {
  return (e === !0 || e === t) && (n === null || n === t);
}
function cu(t, e = 10) {
  let n = null;
  return Math.abs(t.y) > e ? (n = "y") : Math.abs(t.x) > e && (n = "x"), n;
}
class uu extends rt {
  constructor(e) {
    super(e),
      (this.removeGroupControls = z),
      (this.removeListeners = z),
      (this.controls = new au(e));
  }
  mount() {
    const { dragControls: e } = this.node.getProps();
    e && (this.removeGroupControls = e.subscribe(this.controls)),
      (this.removeListeners = this.controls.addListeners() || z);
  }
  update() {
    const { dragControls: e } = this.node.getProps(),
      { dragControls: n } = this.node.prevProps || {};
    e !== n &&
      (this.removeGroupControls(),
      e && (this.removeGroupControls = e.subscribe(this.controls)));
  }
  unmount() {
    this.removeGroupControls(),
      this.removeListeners(),
      this.controls.isDragging || this.controls.endPanSession();
  }
}
const be = (t) => (e, n) => {
  t && D.update(() => t(e, n), !1, !0);
};
class hu extends rt {
  constructor() {
    super(...arguments), (this.removePointerDownListener = z);
  }
  onPointerDown(e) {
    this.session = new bo(e, this.createPanHandlers(), {
      transformPagePoint: this.node.getTransformPagePoint(),
      contextWindow: So(this.node),
    });
  }
  createPanHandlers() {
    const {
      onPanSessionStart: e,
      onPanStart: n,
      onPan: s,
      onPanEnd: i,
    } = this.node.getProps();
    return {
      onSessionStart: be(e),
      onStart: be(n),
      onMove: be(s),
      onEnd: (r, o) => {
        delete this.session, i && D.postRender(() => i(r, o));
      },
    };
  }
  mount() {
    this.removePointerDownListener = Et(this.node.current, "pointerdown", (e) =>
      this.onPointerDown(e)
    );
  }
  update() {
    this.session && this.session.updateHandlers(this.createPanHandlers());
  }
  unmount() {
    this.removePointerDownListener(), this.session && this.session.end();
  }
}
let Ae = !1;
class fu extends P.Component {
  componentDidMount() {
    const {
        visualElement: e,
        layoutGroup: n,
        switchLayoutGroup: s,
        layoutId: i,
      } = this.props,
      { projection: r } = e;
    r &&
      (n.group && n.group.add(r),
      s && s.register && i && s.register(r),
      Ae && r.root.didUpdate(),
      r.addEventListener("animationComplete", () => {
        this.safeToRemove();
      }),
      r.setOptions({
        ...r.options,
        layoutDependency: this.props.layoutDependency,
        onExitComplete: () => this.safeToRemove(),
      })),
      (qt.hasEverUpdated = !0);
  }
  getSnapshotBeforeUpdate(e) {
    const {
        layoutDependency: n,
        visualElement: s,
        drag: i,
        isPresent: r,
      } = this.props,
      { projection: o } = s;
    return (
      o &&
        ((o.isPresent = r),
        e.layoutDependency !== n &&
          o.setOptions({ ...o.options, layoutDependency: n }),
        (Ae = !0),
        i || e.layoutDependency !== n || n === void 0 || e.isPresent !== r
          ? o.willUpdate()
          : this.safeToRemove(),
        e.isPresent !== r &&
          (r
            ? o.promote()
            : o.relegate() ||
              D.postRender(() => {
                const a = o.getStack();
                (!a || !a.members.length) && this.safeToRemove();
              }))),
      null
    );
  }
  componentDidUpdate() {
    const { visualElement: e, layoutAnchor: n } = this.props,
      { projection: s } = e;
    s &&
      ((s.options.layoutAnchor = n),
      s.root.didUpdate(),
      yn.postRender(() => {
        !s.currentAnimation && s.isLead() && this.safeToRemove();
      }));
  }
  componentWillUnmount() {
    const {
        visualElement: e,
        layoutGroup: n,
        switchLayoutGroup: s,
      } = this.props,
      { projection: i } = e;
    (Ae = !0),
      i &&
        (i.scheduleCheckAfterUnmount(),
        n && n.group && n.group.remove(i),
        s && s.deregister && s.deregister(i));
  }
  safeToRemove() {
    const { safeToRemove: e } = this.props;
    e && e();
  }
  render() {
    return null;
  }
}
function Vo(t) {
  const [e, n] = xc(),
    s = P.useContext(Ws);
  return C.jsx(fu, {
    ...t,
    layoutGroup: s,
    switchLayoutGroup: P.useContext(wo),
    isPresent: e,
    safeToRemove: n,
  });
}
const du = {
  pan: { Feature: hu },
  drag: { Feature: uu, ProjectionNode: fo, MeasureLayout: Vo },
};
function Ns(t, e, n) {
  const { props: s } = t;
  t.animationState &&
    s.whileHover &&
    t.animationState.setActive("whileHover", n === "Start");
  const i = "onHover" + n,
    r = s[i];
  r && D.postRender(() => r(e, Ot(e)));
}
class pu extends rt {
  mount() {
    const { current: e } = this.node;
    e &&
      (this.unmount = Wa(
        e,
        (n, s) => (Ns(this.node, s, "Start"), (i) => Ns(this.node, i, "End"))
      ));
  }
  unmount() {}
}
class mu extends rt {
  constructor() {
    super(...arguments), (this.isActive = !1);
  }
  onFocus() {
    let e = !1;
    try {
      e = this.node.current.matches(":focus-visible");
    } catch {
      e = !0;
    }
    !e ||
      !this.node.animationState ||
      (this.node.animationState.setActive("whileFocus", !0),
      (this.isActive = !0));
  }
  onBlur() {
    !this.isActive ||
      !this.node.animationState ||
      (this.node.animationState.setActive("whileFocus", !1),
      (this.isActive = !1));
  }
  mount() {
    this.unmount = Ft(
      Bt(this.node.current, "focus", () => this.onFocus()),
      Bt(this.node.current, "blur", () => this.onBlur())
    );
  }
  unmount() {}
}
function Us(t, e, n) {
  const { props: s } = t;
  if (t.current instanceof HTMLButtonElement && t.current.disabled) return;
  t.animationState &&
    s.whileTap &&
    t.animationState.setActive("whileTap", n === "Start");
  const i = "onTap" + (n === "End" ? "" : n),
    r = s[i];
  r && D.postRender(() => r(e, Ot(e)));
}
class gu extends rt {
  mount() {
    const { current: e } = this.node;
    if (!e) return;
    const { globalTapTarget: n, propagate: s } = this.node.props;
    this.unmount = _a(
      e,
      (i, r) => (
        Us(this.node, r, "Start"),
        (o, { success: a }) => Us(this.node, o, a ? "End" : "Cancel")
      ),
      { useGlobalTarget: n, stopPropagation: s?.tap === !1 }
    );
  }
  unmount() {}
}
const Je = new WeakMap(),
  Ve = new WeakMap(),
  yu = (t) => {
    const e = Je.get(t.target);
    e && e(t);
  },
  vu = (t) => {
    t.forEach(yu);
  };
function xu({ root: t, ...e }) {
  const n = t || document;
  Ve.has(n) || Ve.set(n, {});
  const s = Ve.get(n),
    i = JSON.stringify(e);
  return s[i] || (s[i] = new IntersectionObserver(vu, { root: t, ...e })), s[i];
}
function Tu(t, e, n) {
  const s = xu(e);
  return (
    Je.set(t, n),
    s.observe(t),
    () => {
      Je.delete(t), s.unobserve(t);
    }
  );
}
const wu = { some: 0, all: 1 };
class Pu extends rt {
  constructor() {
    super(...arguments), (this.hasEnteredView = !1), (this.isInView = !1);
  }
  startObserver() {
    this.stopObserver?.();
    const { viewport: e = {} } = this.node.getProps(),
      { root: n, margin: s, amount: i = "some", once: r } = e,
      o = {
        root: n ? n.current : void 0,
        rootMargin: s,
        threshold: typeof i == "number" ? i : wu[i],
      },
      a = (c) => {
        const { isIntersecting: u } = c;
        if (
          this.isInView === u ||
          ((this.isInView = u), r && !u && this.hasEnteredView)
        )
          return;
        u && (this.hasEnteredView = !0),
          this.node.animationState &&
            this.node.animationState.setActive("whileInView", u);
        const { onViewportEnter: l, onViewportLeave: h } = this.node.getProps(),
          f = u ? l : h;
        f && f(c);
      };
    this.stopObserver = Tu(this.node.current, o, a);
  }
  mount() {
    this.startObserver();
  }
  update() {
    if (typeof IntersectionObserver > "u") return;
    const { props: e, prevProps: n } = this.node;
    ["amount", "margin", "root"].some(Su(e, n)) && this.startObserver();
  }
  unmount() {
    this.stopObserver?.(), (this.hasEnteredView = !1), (this.isInView = !1);
  }
}
function Su({ viewport: t = {} }, { viewport: e = {} } = {}) {
  return (n) => t[n] !== e[n];
}
const bu = {
    inView: { Feature: Pu },
    tap: { Feature: gu },
    focus: { Feature: mu },
    hover: { Feature: pu },
  },
  Au = { layout: { ProjectionNode: fo, MeasureLayout: Vo } },
  Vu = { ...Yc, ...bu, ...du, ...Au },
  Cu = Hc(Vu, zc);
function Lu({ product: t, variantHandle: e }) {
  const n = Vn((l) => l.addItem),
    s = Vn((l) => l.isLoading),
    i = t.node,
    r = i.variants.edges[0]?.node,
    o = i.images.edges[0]?.node,
    a = i.priceRange.minVariantPrice,
    c = async (l) => {
      l.preventDefault(),
        l.stopPropagation(),
        r &&
          (await n({
            product: t,
            variantId: r.id,
            variantTitle: r.title,
            price: r.price,
            quantity: 1,
            selectedOptions: r.selectedOptions || [],
          }),
          Eo.success("Added to bag", {
            description: i.title,
            position: "top-center",
          }));
    },
    u = C.jsxs(C.Fragment, {
      children: [
        C.jsxs("div", {
          className:
            "relative aspect-[4/5] overflow-hidden bg-secondary rounded-sm",
          children: [
            o
              ? C.jsx("img", {
                  src: o.url,
                  alt: o.altText ?? i.title,
                  className:
                    "w-full h-full object-cover transition-transform duration-700 group-hover:scale-105",
                })
              : C.jsx("div", {
                  className:
                    "w-full h-full flex items-center justify-center text-muted-foreground text-xs uppercase tracking-widest",
                  children: "No image",
                }),
            C.jsx("div", {
              className:
                "absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500",
            }),
            C.jsx(Mo, {
              onClick: c,
              disabled: s || !r,
              size: "sm",
              className:
                "absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300 gradient-ember text-ember-foreground hover:opacity-90 font-display uppercase tracking-widest text-xs",
              children: s
                ? C.jsx(Ro, { className: "w-3 h-3 animate-spin" })
                : C.jsxs(C.Fragment, {
                    children: [C.jsx(Do, { className: "w-3 h-3 mr-1" }), "Add"],
                  }),
            }),
          ],
        }),
        C.jsxs("div", {
          className:
            "mt-3 sm:mt-4 flex items-start justify-between gap-2 sm:gap-4",
          children: [
            C.jsxs("div", {
              className: "min-w-0",
              children: [
                C.jsx("h3", {
                  className:
                    "font-display uppercase tracking-wider text-sm sm:text-base leading-tight truncate",
                  children: i.title,
                }),
                i.productType &&
                  C.jsx("p", {
                    className:
                      "text-[10px] sm:text-xs text-muted-foreground uppercase tracking-widest mt-1 truncate",
                    children: i.productType,
                  }),
              ],
            }),
            C.jsxs("p", {
              className:
                "text-sm sm:text-base font-semibold text-gold whitespace-nowrap",
              children: [a.currencyCode, " ", parseFloat(a.amount).toFixed(2)],
            }),
          ],
        }),
      ],
    });
  return C.jsx(Cu.div, {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: !0, margin: "-50px" },
    transition: { duration: 0.5, ease: "easeOut" },
    children: e
      ? C.jsx(Ce, {
          to: "/product/$handle/$variantHandle",
          params: { handle: i.handle, variantHandle: e },
          className: "group block",
          children: u,
        })
      : C.jsx(Ce, {
          to: "/product/$handle",
          params: { handle: i.handle },
          className: "group block",
          children: u,
        }),
  });
}
function ku({ message: t = "No products yet" }) {
  return C.jsxs("div", {
    className:
      "border border-dashed border-border rounded-md py-20 px-8 text-center bg-card/30",
    children: [
      C.jsx("div", {
        className:
          "font-display text-3xl uppercase tracking-widest text-muted-foreground",
        children: t,
      }),
      C.jsx("p", {
        className: "mt-4 text-sm text-muted-foreground max-w-md mx-auto",
        children:
          "Tell the chat what you'd like to sell and at what price — Elev8 will add it to the catalog instantly.",
      }),
      C.jsx("p", {
        className: "mt-2 text-xs text-muted-foreground/70 italic",
        children: 'e.g. "Add a luxury chronograph watch for $4,200"',
      }),
      C.jsx(Ce, {
        to: "/",
        className:
          "inline-block mt-6 text-xs uppercase tracking-widest text-ember hover:underline",
        children: "← Back home",
      }),
    ],
  });
}
export { ku as E, Lu as P, Cu as m };
