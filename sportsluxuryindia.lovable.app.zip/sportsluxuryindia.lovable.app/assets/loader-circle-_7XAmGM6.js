import {
  f as G,
  g as N,
  h as u,
  i as M,
  k as g,
  n as Q,
  l as _,
  m as B,
  o as J,
  q as C,
  v as X,
  w as Y,
  x as A,
  y as W,
  r as d,
  z as V,
  A as Z,
  c as $,
} from "./index-emD-E0jN.js";
var q = class extends G {
  constructor(t, e) {
    super(),
      (this.options = e),
      (this.#s = t),
      (this.#i = null),
      (this.#r = N()),
      this.bindMethods(),
      this.setOptions(e);
  }
  #s;
  #t = void 0;
  #p = void 0;
  #e = void 0;
  #a;
  #u;
  #r;
  #i;
  #v;
  #l;
  #d;
  #o;
  #h;
  #n;
  #f = new Set();
  bindMethods() {
    this.refetch = this.refetch.bind(this);
  }
  onSubscribe() {
    this.listeners.size === 1 &&
      (this.#t.addObserver(this),
      j(this.#t, this.options) ? this.#c() : this.updateResult(),
      this.#g());
  }
  onUnsubscribe() {
    this.hasListeners() || this.destroy();
  }
  shouldFetchOnReconnect() {
    return x(this.#t, this.options, this.options.refetchOnReconnect);
  }
  shouldFetchOnWindowFocus() {
    return x(this.#t, this.options, this.options.refetchOnWindowFocus);
  }
  destroy() {
    (this.listeners = new Set()),
      this.#y(),
      this.#S(),
      this.#t.removeObserver(this);
  }
  setOptions(t) {
    const e = this.options,
      s = this.#t;
    if (
      ((this.options = this.#s.defaultQueryOptions(t)),
      this.options.enabled !== void 0 &&
        typeof this.options.enabled != "boolean" &&
        typeof this.options.enabled != "function" &&
        typeof u(this.options.enabled, this.#t) != "boolean")
    )
      throw new Error(
        "Expected enabled to be a boolean or a callback that returns a boolean"
      );
    this.#O(),
      this.#t.setOptions(this.options),
      e._defaulted &&
        !M(this.options, e) &&
        this.#s
          .getQueryCache()
          .notify({
            type: "observerOptionsUpdated",
            query: this.#t,
            observer: this,
          });
    const r = this.hasListeners();
    r && z(this.#t, s, this.options, e) && this.#c(),
      this.updateResult(),
      r &&
        (this.#t !== s ||
          u(this.options.enabled, this.#t) !== u(e.enabled, this.#t) ||
          g(this.options.staleTime, this.#t) !== g(e.staleTime, this.#t)) &&
        this.#b();
    const i = this.#R();
    r &&
      (this.#t !== s ||
        u(this.options.enabled, this.#t) !== u(e.enabled, this.#t) ||
        i !== this.#n) &&
      this.#m(i);
  }
  getOptimisticResult(t) {
    const e = this.#s.getQueryCache().build(this.#s, t),
      s = this.createResult(e, t);
    return (
      et(this, s) &&
        ((this.#e = s), (this.#u = this.options), (this.#a = this.#t.state)),
      s
    );
  }
  getCurrentResult() {
    return this.#e;
  }
  trackResult(t, e) {
    return new Proxy(t, {
      get: (s, r) => (
        this.trackProp(r),
        e?.(r),
        r === "promise" &&
          (this.trackProp("data"),
          !this.options.experimental_prefetchInRender &&
            this.#r.status === "pending" &&
            this.#r.reject(
              new Error(
                "experimental_prefetchInRender feature flag is not enabled"
              )
            )),
        Reflect.get(s, r)
      ),
    });
  }
  trackProp(t) {
    this.#f.add(t);
  }
  getCurrentQuery() {
    return this.#t;
  }
  refetch({ ...t } = {}) {
    return this.fetch({ ...t });
  }
  fetchOptimistic(t) {
    const e = this.#s.defaultQueryOptions(t),
      s = this.#s.getQueryCache().build(this.#s, e);
    return s.fetch().then(() => this.createResult(s, e));
  }
  fetch(t) {
    return this.#c({ ...t, cancelRefetch: t.cancelRefetch ?? !0 }).then(
      () => (this.updateResult(), this.#e)
    );
  }
  #c(t) {
    this.#O();
    let e = this.#t.fetch(this.options, t);
    return t?.throwOnError || (e = e.catch(Q)), e;
  }
  #b() {
    this.#y();
    const t = g(this.options.staleTime, this.#t);
    if (_.isServer() || this.#e.isStale || !B(t)) return;
    const s = J(this.#e.dataUpdatedAt, t) + 1;
    this.#o = C.setTimeout(() => {
      this.#e.isStale || this.updateResult();
    }, s);
  }
  #R() {
    return (
      (typeof this.options.refetchInterval == "function"
        ? this.options.refetchInterval(this.#t)
        : this.options.refetchInterval) ?? !1
    );
  }
  #m(t) {
    this.#S(),
      (this.#n = t),
      !(
        _.isServer() ||
        u(this.options.enabled, this.#t) === !1 ||
        !B(this.#n) ||
        this.#n === 0
      ) &&
        (this.#h = C.setInterval(() => {
          (this.options.refetchIntervalInBackground || X.isFocused()) &&
            this.#c();
        }, this.#n));
  }
  #g() {
    this.#b(), this.#m(this.#R());
  }
  #y() {
    this.#o !== void 0 && (C.clearTimeout(this.#o), (this.#o = void 0));
  }
  #S() {
    this.#h !== void 0 && (C.clearInterval(this.#h), (this.#h = void 0));
  }
  createResult(t, e) {
    const s = this.#t,
      r = this.options,
      i = this.#e,
      l = this.#a,
      n = this.#u,
      b = t !== s ? t.state : this.#p,
      { state: h } = t;
    let a = { ...h },
      R = !1,
      o;
    if (e._optimisticResults) {
      const c = this.hasListeners(),
        m = !c && j(t, e),
        S = c && z(t, s, e, r);
      (m || S) && (a = { ...a, ...Y(h.data, t.options) }),
        e._optimisticResults === "isRestoring" && (a.fetchStatus = "idle");
    }
    let { error: y, errorUpdatedAt: D, status: v } = a;
    o = a.data;
    let F = !1;
    if (e.placeholderData !== void 0 && o === void 0 && v === "pending") {
      let c;
      i?.isPlaceholderData && e.placeholderData === n?.placeholderData
        ? ((c = i.data), (F = !0))
        : (c =
            typeof e.placeholderData == "function"
              ? e.placeholderData(this.#d?.state.data, this.#d)
              : e.placeholderData),
        c !== void 0 && ((v = "success"), (o = A(i?.data, c, e)), (R = !0));
    }
    if (e.select && o !== void 0 && !F)
      if (i && o === l?.data && e.select === this.#v) o = this.#l;
      else
        try {
          (this.#v = e.select),
            (o = e.select(o)),
            (o = A(i?.data, o, e)),
            (this.#l = o),
            (this.#i = null);
        } catch (c) {
          this.#i = c;
        }
    this.#i && ((y = this.#i), (o = this.#l), (D = Date.now()), (v = "error"));
    const I = a.fetchStatus === "fetching",
      T = v === "pending",
      w = v === "error",
      U = T && I,
      L = o !== void 0,
      p = {
        status: v,
        fetchStatus: a.fetchStatus,
        isPending: T,
        isSuccess: v === "success",
        isError: w,
        isInitialLoading: U,
        isLoading: U,
        data: o,
        dataUpdatedAt: a.dataUpdatedAt,
        error: y,
        errorUpdatedAt: D,
        failureCount: a.fetchFailureCount,
        failureReason: a.fetchFailureReason,
        errorUpdateCount: a.errorUpdateCount,
        isFetched: t.isFetched(),
        isFetchedAfterMount:
          a.dataUpdateCount > b.dataUpdateCount ||
          a.errorUpdateCount > b.errorUpdateCount,
        isFetching: I,
        isRefetching: I && !T,
        isLoadingError: w && !L,
        isPaused: a.fetchStatus === "paused",
        isPlaceholderData: R,
        isRefetchError: w && L,
        isStale: P(t, e),
        refetch: this.refetch,
        promise: this.#r,
        isEnabled: u(e.enabled, t) !== !1,
      };
    if (this.options.experimental_prefetchInRender) {
      const c = p.data !== void 0,
        m = p.status === "error" && !c,
        S = (E) => {
          m ? E.reject(p.error) : c && E.resolve(p.data);
        },
        k = () => {
          const E = (this.#r = p.promise = N());
          S(E);
        },
        O = this.#r;
      switch (O.status) {
        case "pending":
          t.queryHash === s.queryHash && S(O);
          break;
        case "fulfilled":
          (m || p.data !== O.value) && k();
          break;
        case "rejected":
          (!m || p.error !== O.reason) && k();
          break;
      }
    }
    return p;
  }
  updateResult() {
    const t = this.#e,
      e = this.createResult(this.#t, this.options);
    if (
      ((this.#a = this.#t.state),
      (this.#u = this.options),
      this.#a.data !== void 0 && (this.#d = this.#t),
      M(e, t))
    )
      return;
    this.#e = e;
    const s = () => {
      if (!t) return !0;
      const { notifyOnChangeProps: r } = this.options,
        i = typeof r == "function" ? r() : r;
      if (i === "all" || (!i && !this.#f.size)) return !0;
      const l = new Set(i ?? this.#f);
      return (
        this.options.throwOnError && l.add("error"),
        Object.keys(this.#e).some((n) => {
          const f = n;
          return this.#e[f] !== t[f] && l.has(f);
        })
      );
    };
    this.#E({ listeners: s() });
  }
  #O() {
    const t = this.#s.getQueryCache().build(this.#s, this.options);
    if (t === this.#t) return;
    const e = this.#t;
    (this.#t = t),
      (this.#p = t.state),
      this.hasListeners() && (e?.removeObserver(this), t.addObserver(this));
  }
  onQueryUpdate() {
    this.updateResult(), this.hasListeners() && this.#g();
  }
  #E(t) {
    W.batch(() => {
      t.listeners &&
        this.listeners.forEach((e) => {
          e(this.#e);
        }),
        this.#s
          .getQueryCache()
          .notify({ query: this.#t, type: "observerResultsUpdated" });
    });
  }
};
function tt(t, e) {
  return (
    u(e.enabled, t) !== !1 &&
    t.state.data === void 0 &&
    !(t.state.status === "error" && u(e.retryOnMount, t) === !1)
  );
}
function j(t, e) {
  return tt(t, e) || (t.state.data !== void 0 && x(t, e, e.refetchOnMount));
}
function x(t, e, s) {
  if (u(e.enabled, t) !== !1 && g(e.staleTime, t) !== "static") {
    const r = typeof s == "function" ? s(t) : s;
    return r === "always" || (r !== !1 && P(t, e));
  }
  return !1;
}
function z(t, e, s, r) {
  return (
    (t !== e || u(r.enabled, t) === !1) &&
    (!s.suspense || t.state.status !== "error") &&
    P(t, s)
  );
}
function P(t, e) {
  return u(e.enabled, t) !== !1 && t.isStaleByTime(g(e.staleTime, t));
}
function et(t, e) {
  return !M(t.getCurrentResult(), e);
}
var K = d.createContext(!1),
  st = () => d.useContext(K);
K.Provider;
function rt() {
  let t = !1;
  return {
    clearReset: () => {
      t = !1;
    },
    reset: () => {
      t = !0;
    },
    isReset: () => t,
  };
}
var it = d.createContext(rt()),
  nt = () => d.useContext(it),
  at = (t, e, s) => {
    const r =
      s?.state.error && typeof t.throwOnError == "function"
        ? V(t.throwOnError, [s.state.error, s])
        : t.throwOnError;
    (t.suspense || t.experimental_prefetchInRender || r) &&
      (e.isReset() || (t.retryOnMount = !1));
  },
  ot = (t) => {
    d.useEffect(() => {
      t.clearReset();
    }, [t]);
  },
  ht = ({
    result: t,
    errorResetBoundary: e,
    throwOnError: s,
    query: r,
    suspense: i,
  }) =>
    t.isError &&
    !e.isReset() &&
    !t.isFetching &&
    r &&
    ((i && t.data === void 0) || V(s, [t.error, r])),
  ct = (t, e) => e.state.data === void 0,
  ut = (t) => {
    if (t.suspense) {
      const s = (i) => (i === "static" ? i : Math.max(i ?? 1e3, 1e3)),
        r = t.staleTime;
      (t.staleTime = typeof r == "function" ? (...i) => s(r(...i)) : s(r)),
        typeof t.gcTime == "number" && (t.gcTime = Math.max(t.gcTime, 1e3));
    }
  },
  lt = (t, e) => t.isLoading && t.isFetching && !e,
  dt = (t, e) => t?.suspense && e.isPending,
  H = (t, e, s) =>
    e.fetchOptimistic(t).catch(() => {
      s.clearReset();
    });
function ft(t, e, s) {
  const r = st(),
    i = nt(),
    l = Z(),
    n = l.defaultQueryOptions(t);
  l.getDefaultOptions().queries?._experimental_beforeQuery?.(n);
  const f = l.getQueryCache().get(n.queryHash);
  (n._optimisticResults = r ? "isRestoring" : "optimistic"),
    ut(n),
    at(n, i, f),
    ot(i);
  const b = !l.getQueryCache().get(n.queryHash),
    [h] = d.useState(() => new e(l, n)),
    a = h.getOptimisticResult(n),
    R = !r && t.subscribed !== !1;
  if (
    (d.useSyncExternalStore(
      d.useCallback(
        (o) => {
          const y = R ? h.subscribe(W.batchCalls(o)) : Q;
          return h.updateResult(), y;
        },
        [h, R]
      ),
      () => h.getCurrentResult(),
      () => h.getCurrentResult()
    ),
    d.useEffect(() => {
      h.setOptions(n);
    }, [n, h]),
    dt(n, a))
  )
    throw H(n, h, i);
  if (
    ht({
      result: a,
      errorResetBoundary: i,
      throwOnError: n.throwOnError,
      query: f,
      suspense: n.suspense,
    })
  )
    throw a.error;
  return (
    l.getDefaultOptions().queries?._experimental_afterQuery?.(n, a),
    n.experimental_prefetchInRender &&
      !_.isServer() &&
      lt(a, r) &&
      (b ? H(n, h, i) : f?.promise)?.catch(Q).finally(() => {
        h.updateResult();
      }),
    n.notifyOnChangeProps ? a : h.trackResult(a)
  );
}
function Rt(t, e) {
  return ft(
    {
      ...t,
      enabled: !0,
      suspense: !0,
      throwOnError: ct,
      placeholderData: void 0,
    },
    q
  );
}
const pt = [["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]],
  mt = $("loader-circle", pt);
export { mt as L, Rt as u };
